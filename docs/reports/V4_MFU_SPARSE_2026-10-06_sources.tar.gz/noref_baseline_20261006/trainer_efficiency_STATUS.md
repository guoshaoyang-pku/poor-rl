# Trainer 效率审计

CPU只读完成，原始数据与runtime未改。对应冻结recipe的FP8/MLP/head实际覆写已核查。最明确的方向是减少head和投影反向的临时写回／累加，以及保持memory budget的子批次计划；当前数据不能把14.31% compute MFU全部归因于FP32 optimizer、权重刷新或真实GPU空闲。

## 已测与可证实开销

| 项目 | 已有证据 | 含义 |
|---|---|---|
| 真microbatch | MB1024/rank、GAS1；每rank32个G32 groups | 只减少optimizer／DDP边界，不代表一次1024分支compute |
| 计算拆分 | steps4–6日志subbatches/row=54、52、50；65536 padded-token budget | 每rank每步顺序执行约50个forward/backward图，某些group重复prefix |
| rank0 row布局 | row_imbalance=1.0381、1.0106、1.0260；pad_frac=4.65–4.82% | token负载已经较均衡，单纯消padding不足以补28.44%计算时间 |
| LM head FP32 dw buffer | [248320,1024]×4bytes=0.947265625GiB；每个subbatch一份zeros | rank0清零分配约47.36–51.15GiB/step；是累计分配量，不是峰值或测得HBM读写量 |
| head反向 | 相同单G32 trace，head scope按CUDA launch correlation归属2223 kernels /107.812491ms | FP8 GEMM720/64.620160ms；gradient量化20.034140ms；amax8.866991ms；FP32 add13.067687ms |
| head显式累加shape | dw225 add kernels/10.388362ms；dh224 add kernels/2.512924ms | GEMM已FP8、输出FP32，但新临时随后再add进buffer |
| master梯度／embedding | policy_backward全aten::add_ 31.803302ms；embedding大FP32 add4次2.790172ms | 包含activation及参数／head累加，不能都算optimizer成本 |
| dgrad输出cast | Linear/MLP反向FP32→BF16 copy11.527292ms | 同样是执行后的额外写回；保留FP32内部累加，可测kernel直接BF16输出 |
| weight缓存 | _weight_cache424 CPU调用，408 kernel合计1.623718ms；CPU inclusive33.801905ms含嵌套，self13.318930ms | 每step版本失效后首次刷新，之后命中；只此cache的GPU开销约0.165% policy kernel，不支持主瓶颈判断 |
| Adam | 同profile warmed CUDA-event中位6.429152ms；kernel5.321ms | 有同步计时，数量级小。E2E日志optimizer0.002秒不能拿来替代GPU耗时 |

以上trace含local BF16 reference；政策kernel总量986.200083ms，reference570.378863ms，两者已分开。head correlation统计用head CPU thread的cuda_runtime/cuda_driver correlation匹配kernel，避免混淆异线程CPU ancestry。单卡profile没有DDP，不能推断四rank通信耗时为零。

## 三个可实施优先级

### 1. Head FP32 GEMM epilogue累加与缓冲生命周期

实际matmul_prototype._fp8_backward每个token tile/vocab tile分别执行logits重算、gradient amax＋双布局量化、dgrad、wgrad，scaled_mm无C/beta/output buffer；dw/dh以 += 再跑FP32 add。可为同一量化输入增加支持FP32输出buffer的native epilogue，首次写beta0，之后beta1；让同一subbatch的tile按原顺序累加，先避免全vocab dw初始化和独立add。dgrad仍在所有vocab tile累计FP32，最后才一次转BF16；禁止逐vocab提前BF16累加。

进阶才把所有subbatch贡献累加到step级FP32 grad buffer。当前PyTorch autograd、tied embedding/head、DDP reducer都依赖AccumulateGrad；不能直接在custom backward写parameter.grad后返回None而假设DDP正确。先把同一head调用内部临时消掉，并保留返回FP32 dw；再用四rank＋tied weight＋GAS1 gate验证step buffer接线。每step显式清零一次且保持Adam动量与zero-grad语义。

可省的现有head显式add约1.31%政策kernel；再加其他grad/add/cast也不是28.44%。这项必须与flat-branch跳过、norm/conv/GDN重算或减少host launch开销组合。需要实际含kernel/epilogue/net时间，不能拿47–51GiB分配量直接折算吞吐。

### 2. 不改变forward规则的反向cast／scale融合

Linear _linear_backward和融合MLP dgrad均先scaled_mm FP32输出再.to(x_dtype)，11.527ms相关copy。可让nativeFP8 GEMM仍用FP32内部累加，直接输出BF16激活梯度；通过同batch模型gradient方向及FP32 master更新检查后再采纳。wgrad、master累加和Adam仍FP32。这不会给trainer额外forward精度。

融合MLP已用xs.amax()/hs.amax()，即forward row scales的max，避免额外扫BF16激活；Linear同理。进一步row quant kernel可同时写每CTA max，最后小规约得到同一global scale，使wgrad转置量化少一个reduction launch；不能改成另一scale粒度。当前模型_backward_所有 xs.amax/hs.amax的kernel成本应在新计时gate中区分，当前profile的单项只约1–2ms，不承诺大收益。

head _gradient_amax_no_entropy是单row max，每vocab tile一次global amax，再_gradient_quantize_dual，一共28.901131ms。它已经是融合实现，不能再声称head梯度仍BF16。可联动零gradient row压缩，沿原token tile保持hidden/gradient scale和scatter，不跨tile重算scale；否则更新规则改变。

### 3. 激活checkpoint与跨group布局：用已有反例限定搜索

auto公式128GiB/24层/full88/ckpt4.7/base16。32k→0层checkpoint；65,053/65,536→1层；80k→6层；98,304→10层；131,072→14层。单纯把subbatch翻倍，可能新增13层whole-layer forward重算，并提高prefix和branch图的activation footprint。

同固定G32实际去掉唯一1层checkpoint：1636.969971→1618.246704ms（**1.1438%**完整含local reference compute改善），peak111.577→115.978GiB。不是28%来源，当前β0没有reference，可能有不同显存余量，但实际长尾不应无条件禁用checkpoint。需要每subbatch记录tokens/ckpt layers/peak，以及首次optimizer states初始化后的显存。

更大MB并不自动合并投影。已有双G32完整projection合批GPU实验：6个atomic→3 waves，3858.317139→3857.812988ms（**0.0131%**），peak66.559→109.383GiB；forward LP相同，但全模型grad相对L2≈11.896%受已记录FA3重复噪声影响，非equivalence证明。它不是下一轮可重复包装的“大batch提速”。branch GEMM本身M约15,799–25,454，已经足够大；应优先合并小prefix／小维norm调用，或保持65k总wave budget的调度，保留每组独立GDN/cache/梯度量化scale。

## 同步／分配与目标

plan_groups源代码每sequence做nonzero、int(nz[0])、prompt.cpu().numpy().tobytes；MB1024每rank会重复扫描prompt。subbatch_logprobs为每completion建立arange和j[keep]，产生动态nonzero和cat。与collator在CPU保留段边界、prompt identity/hash和completion长度接线，可避免GPU→host往返；每组确认hash相等且slot覆盖恰好一次，不能凭group_id盲共享prefix。CPU-gap agent另有完整gap归属，此处仅提供调用点。

trace的1022 aten::item中960个是compiled head的double scalar（CPU读取，非GPU同步）；真正cudaStreamSynchronize201次总CPU69.703503ms、nonzero111次总CPU74.644756ms。不可把所有item都当GPU sync，也不可把这两个inclusive耗时简单相加。core图目前RLFORGE_FP8_GRAPHS=0，开启现有graph_replay会每次copy inputs（含weights）并clone outputs；不是免费graph优化，需静态bucket/capture及内存／更新时间gate。

同方法compute MFU14.311282%→20%，同useful work下需要143.466358s计算窗口降至102.659376s，即省**28.4436%、40.806983s**。当前单卡profile的完整FP8执行比useful多14.1607% FLOPs（padding、head重算、checkpoint等），kernel仍有conv、norm、GDN、quantization和launchgap。上面的单项没有已测1.3975×收益；不能宣称已经达到20%。

下一项最短GPU验证：先head epilogue内FP32 accumulate／dgrad直接BF16输出gate；同G32 fixture不改forward、scale或GSPO；记录compute CUDA events、梯度相对L2/cos、FP32 grad/Adam update。全零tile skip另作gate，之后集合四rankβ0测试。多group或larger-budget仅当这次memory/ckpt ledger证明净收益可期待时再测。

完整字段和源hash见trainer_efficiency_audit.json。无新增GPU或远端操作。
