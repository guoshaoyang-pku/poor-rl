"""Benchmark-only frozen-v2 head backward with finite, exact-zero gradient rows."""
from __future__ import annotations

import os

import torch
import torch.nn.functional as F

import matmul_prototype as base
import matmul_prototype_v2 as v2


def _fp8_backward(h, targets, log_z, ent, g, ge, fp8_cache, need_h, need_w,
                  ls, inv_t, *, graph=True, compact=True, audit=None):
    from rlforge import fast_logprob as flp
    from rlforge.fp8 import _quantize_tensor, _tensor_scale, forward_mm, quantize_rows, scaled_mm

    if ge is not None:
        return base._fp8_backward(h, targets, log_z, ent, g, ge, fp8_cache,
                                  need_h, need_w, ls, inv_t, graph=graph)
    if torch.cuda.is_current_stream_capturing():
        raise RuntimeError("Zero-row compaction requires host-visible dynamic row counts")
    wq, ws, backward_weights = fp8_cache
    n, hidden = h.shape
    vocab = wq.shape[0]
    if not (need_h or need_w):
        return None, None
    # Resolve every dynamic row count before enqueueing head GEMMs. A nonzero
    # inside the tile loop would wait for all preceding tile work on the stream.
    active_all = (g != 0).nonzero(as_tuple=False).flatten()
    tile_count = (n + flp.TOK_CHUNK - 1) // flp.TOK_CHUNK
    if active_all.numel() == n:
        if audit is None:
            return base._fp8_backward(h, targets, log_z, ent, g, ge, fp8_cache,
                                      need_h, need_w, ls, inv_t, graph=graph)
        counts = [min(flp.TOK_CHUNK, n - t0) for t0 in range(0, n, flp.TOK_CHUNK)]
    elif tile_count == 1:
        counts = [active_all.numel()]
    elif active_all.numel() == 0:
        counts = [0] * tile_count
    else:
        counts = torch.bincount(active_all // flp.TOK_CHUNK, minlength=tile_count).tolist()
    grad_h = torch.zeros(n, hidden, device=h.device, dtype=torch.float32) if need_h else None
    grad_w = torch.zeros(vocab, hidden, device=h.device, dtype=torch.float32) if need_w else None
    offset = 0
    for tile, t0 in enumerate(range(0, n, flp.TOK_CHUNK)):
        t1 = min(n, t0 + flp.TOK_CHUNK)
        hc, tg, gc = h[t0:t1], targets[t0:t1], g[t0:t1]
        active_count = counts[tile]
        active_start = offset
        offset += active_count
        record = dict(t0=t0, t1=t1, active_rows=active_count, skipped=active_count == 0,
                      compacted=False,
                      hidden_scale=None, gradient_scales=[])
        if audit is not None:
            audit.append(record)
        if active_count == 0:
            continue
        use_compact = compact and t1 - t0 >= 1024 and active_count * 2 <= t1 - t0
        record["compacted"] = use_compact
        active = active_all[active_start:offset] - t0 if use_compact else None
        # Retain the original forward GEMM shape: changing M can change logits,
        # hence the E5 gradient amax even with the same rowwise quantized inputs.
        hq, hs = quantize_rows(hc)
        htq = hts = None
        if need_w:
            pad = (-(t1 - t0)) % 16
            hp = F.pad(hc, (0, 0, 0, pad)) if pad else hc
            if use_compact:
                hts = _tensor_scale(hp, torch.finfo(torch.float8_e4m3fn).max)
                ha = hc.index_select(0, active)
                pad_active = (-active_count) % 16
                hap = F.pad(ha, (0, 0, 0, pad_active)) if pad_active else ha
                htq, _ = _quantize_tensor(hap, torch.float8_e4m3fn, transpose=True, scale=hts)
            else:
                htq, hts = _quantize_tensor(hp, torch.float8_e4m3fn, transpose=True)
            if audit is not None:
                record["hidden_scale"] = hts.detach().clone()
        ga = gc.index_select(0, active) if use_compact else gc
        za = log_z[t0:t1].index_select(0, active) if use_compact else log_z[t0:t1]
        ea = ent[t0:t1].index_select(0, active) if use_compact else ent[t0:t1]
        ta = tg.index_select(0, active) if use_compact else tg
        dh_active = torch.zeros(active_count, hidden, device=h.device, dtype=torch.float32) if (
            need_h and use_compact) else None
        for vi, v0 in enumerate(range(0, vocab, flp.VOCAB_CHUNK)):
            v1 = min(vocab, v0 + flp.VOCAB_CHUNK)
            full_logits = forward_mm(hq, wq[v0:v1], hs, ws[v0:v1])
            logits = full_logits.index_select(0, active) if use_compact else full_logits
            gq, gtq, gs = v2.quantized_gradient(logits, za, ga, None, ea, ta - v0, ls, inv_t)
            if audit is not None:
                record["gradient_scales"].append(gs.detach().clone())
            if need_h:
                wtq, wts = backward_weights[vi]
                contribution = scaled_mm(gq, wtq, gs, wts, out_dtype=torch.float32)
                if use_compact:
                    dh_active += contribution
                else:
                    grad_h[t0:t1] += contribution
            if need_w:
                grad_w[v0:v1] += scaled_mm(gtq, htq, gs, hts, out_dtype=torch.float32)
        if need_h and use_compact:
            grad_h[t0:t1].index_copy_(0, active, dh_active)
    return grad_h, grad_w


def install_for_benchmark(policy, ref=None, *, compact=True):
    from rlforge import fast_logprob as flp

    if os.environ.get("RLFORGE_FP8_HEAD_GRAPH", "0") == "1":
        raise ValueError("Zero-row prototype requires RLFORGE_FP8_HEAD_GRAPH=0")
    if base.quantized_gradient is not v2.quantized_gradient or flp._fp8_backward is not base._fp8_backward:
        raise RuntimeError("Install after the frozen matmul_prototype_v2 head recipe")
    original = flp._fp8_backward

    def backward(*args, **kwargs):
        return _fp8_backward(*args, **kwargs, compact=compact)

    flp._fp8_backward = backward

    def restore():
        flp._fp8_backward = original

    return restore
