"""Stream a Kineto trace into GPU intervals and small diagnostic aggregates."""
import argparse
from array import array
from collections import Counter, defaultdict
import gzip
import hashlib
import itertools
import json
import math
from pathlib import Path
import re


def trace_events(path, chunk_chars=1024 * 1024, max_value_chars=64 * 1024 * 1024):
    decoder = json.JSONDecoder()
    opener = gzip.open if str(path).endswith(".gz") else open
    with opener(path, "rt", encoding="utf-8") as source:
        buffer, pos, eof = "", 0, False

        def fill():
            nonlocal buffer, pos, eof
            text = source.read(chunk_chars)
            buffer, pos = buffer[pos:] + text, 0
            eof = not text

        def peek():
            nonlocal pos
            while True:
                while pos < len(buffer) and buffer[pos].isspace():
                    pos += 1
                if pos < len(buffer):
                    return buffer[pos]
                if eof:
                    return ""
                fill()

        def expect(char):
            nonlocal pos
            found = peek()
            if found != char:
                raise ValueError(f"Expected {char!r}, found {found!r} in trace JSON")
            pos += 1

        def value():
            nonlocal pos
            peek()
            while True:
                try:
                    item, end = decoder.raw_decode(buffer, pos)
                    if isinstance(item, (int, float)) and not isinstance(item, bool) and not eof:
                        if end == len(buffer) or buffer[end] not in " \t\r\n,]}":
                            fill()
                            continue
                    pos = end
                    return item
                except json.JSONDecodeError:
                    if eof:
                        raise
                    if len(buffer) - pos >= max_value_chars:
                        raise ValueError("Trace event/header exceeds streaming value limit")
                    fill()

        expect("{")
        found_events = False
        while peek() != "}":
            key = value()
            expect(":")
            if key == "traceEvents":
                if found_events:
                    raise ValueError("Duplicate traceEvents array")
                found_events = True
                expect("[")
                while peek() != "]":
                    event = value()
                    if isinstance(event, dict):
                        yield event
                    else:
                        raise ValueError("traceEvents entry is not an object")
                    if peek() == "]":
                        break
                    expect(",")
                expect("]")
            else:
                value()
            if peek() == "}":
                break
            expect(",")
        expect("}")
        if peek():
            raise ValueError("Trailing non-whitespace after trace JSON")
        if not found_events:
            raise ValueError("traceEvents array missing")


def union_intervals(arrays):
    starts = sorted(x for values in arrays for x in itertools.islice(values, 0, None, 2))
    ends = sorted(x for values in arrays for x in itertools.islice(values, 1, None, 2))
    result = array("d")
    i = j = active = 0
    while i < len(starts) or j < len(ends):
        if i < len(starts) and (j == len(ends) or starts[i] <= ends[j]):
            if active == 0:
                begin = starts[i]
            active += 1
            i += 1
        else:
            active -= 1
            if active == 0:
                result.extend((begin, ends[j]))
            j += 1
    return result


def pairs(values):
    return zip(itertools.islice(values, 0, None, 2), itertools.islice(values, 1, None, 2))


def duration_us(values):
    return sum(end - start for start, end in pairs(values))


def intersection(left, right):
    output = array("d")
    i = j = 0
    while i < len(left) and j < len(right):
        start, end = max(left[i], right[j]), min(left[i + 1], right[j + 1])
        if end > start:
            output.extend((start, end))
        if left[i + 1] <= right[j + 1]:
            i += 2
        else:
            j += 2
    return output


def operation(name):
    normalized = re.sub(r"[^a-z0-9]", "", name.lower())
    for match, label in (("allreduce", "all_reduce"), ("broadcast", "broadcast"),
                         ("allgather", "all_gather"), ("reducescatter", "reduce_scatter"),
                         ("alltoall", "all_to_all"), ("sendrecv", "send_recv")):
        if match in normalized:
            return label
    return "unknown"


def kernel_category(name):
    low = name.lower()
    if "nccl" in low:
        return "NCCL"
    if any(x in low for x in ("fp8", "float8", "e4m3", "e5m2")):
        return "FP8 GEMM or fused FP8"
    if any(x in low for x in ("flash", "fmha")):
        return "Attention"
    if any(x in low for x in ("gated_delta", "gateddelt", "chunk_delta", "wy_repr")):
        return "GDN"
    if any(x in low for x in ("quant", "amax")):
        return "Quantization/reduction"
    if "gemm" in low or "matmul" in low:
        return "Other GEMM"
    if any(x in low for x in ("conv", "silu")):
        return "Convolution/SiLU"
    if "norm" in low:
        return "Norm"
    if any(x in low for x in ("copy", "cast", "cat")):
        return "Copy/cast"
    if any(x in low for x in ("elementwise", "reduce", "reduction", "triton_poi", "triton_red")):
        return "Elementwise/reduction"
    return "Unclassified"


def collective_payload(args):
    selected = {key: value for key, value in args.items() if any(
        word in key.lower() for word in ("dtype", "type", "nelem", "numel", "byte",
                                         "collective", "group size", "input dims"))}
    dtype = next((value for key, value in args.items()
                  if "dtype" in key.lower() and isinstance(value, str)), None)
    if dtype is None:
        types = args.get("Input type", [])
        if isinstance(types, list) and types and isinstance(types[0], str):
            dtype = types[0]
    normalized = re.sub(r"[^a-z0-9]", "", (dtype or "").lower()).removeprefix("c10")
    widths = {"float": 4, "float32": 4, "f32": 4, "double": 8, "float64": 8,
              "bfloat16": 2, "bf16": 2, "half": 2, "float16": 2, "f16": 2,
              "longint": 8, "long": 8, "int64": 8, "int": 4, "int32": 4,
              "bool": 1, "uint8": 1, "int8": 1, "float8e4m3fn": 1, "float8e5m2": 1}
    byte_fields, elements = {}, {}
    for key, value in args.items():
        if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(value):
            continue
        if value < 0:
            continue
        low = key.lower()
        if "byte" in low and not any(x in low for x in ("bandwidth", "estimate", "shared memory")):
            byte_fields[key] = value
        if "nelem" in low or "numel" in low:
            elements[key] = value
    derived = {key: value * widths[normalized] for key, value in elements.items()} if normalized in widths else {}
    return dict(dtype=dtype, explicit_byte_fields=byte_fields, recorded_element_counts=elements,
                bytes_from_recorded_count_and_dtype=derived, selected_args=selected)


def summarize(trace, metadata):
    counts, phases = Counter(), defaultdict(list)
    kernel_names, categories, scalar, sync, memory, collectives = (defaultdict(lambda: [0, 0.0]) for _ in range(6))
    devices = defaultdict(lambda: defaultdict(lambda: array("d")))
    cpu_payloads = defaultdict(lambda: dict(
        count=0, host_duration_sum_us=0.0, samples=[], dtypes=Counter(),
        explicit_byte_field_sums=Counter(), recorded_element_count_sums=Counter(),
        bytes_from_recorded_count_and_dtype_sums=Counter(), records_with_byte_fields=0,
        records_with_derived_bytes=0))
    payload_samples = defaultdict(list)
    memory_bytes = Counter()
    n_events = n_kernels = interval_count = 0
    for event in trace_events(trace):
        n_events += 1
        cat, name = str(event.get("cat", "uncategorized")), str(event.get("name", ""))
        counts[cat] += 1
        if event.get("ph") != "X":
            continue
        start, duration = event.get("ts"), event.get("dur")
        if not all(isinstance(x, (int, float)) and math.isfinite(x) for x in (start, duration)) or duration < 0:
            continue
        args = event.get("args", {})
        args = args if isinstance(args, dict) else {}
        low = name.lower()
        if name.startswith("v4trace/"):
            phases[name].append(dict(ts_us=start, end_us=start + duration, host_duration_us=duration,
                                     pid=event.get("pid"), tid=event.get("tid")))
        if cat in ("kernel", "gpu_memcpy", "gpu_memset"):
            device = str(args.get("device", event.get("pid", "unknown")))
            kind = "nccl" if cat == "kernel" and "nccl" in low else "non_nccl" if cat == "kernel" else cat
            if duration > 0:
                devices[device][kind].extend((start, start + duration))
                interval_count += 1
            key = cat + ": " + name
            if cat == "kernel":
                n_kernels += 1
                kernel_names[name][0] += 1
                kernel_names[name][1] += duration
                category = kernel_category(name)
                categories[category][0] += 1
                categories[category][1] += duration
                if kind == "nccl":
                    collectives[name][0] += 1
                    collectives[name][1] += duration
                    if len(payload_samples[name]) < 3:
                        payload_samples[name].append(collective_payload(args))
            else:
                memory[key][0] += 1
                memory[key][1] += duration
                byte_count = args.get("bytes")
                if isinstance(byte_count, (int, float)) and math.isfinite(byte_count) and byte_count >= 0:
                    memory_bytes[key] += byte_count
        if cat == "cpu_op" and name in ("aten::item", "aten::_local_scalar_dense", "aten::is_nonzero"):
            scalar[name][0] += 1
            scalar[name][1] += duration
        if cat in ("cuda_runtime", "cuda_driver", "cpu_op") and any(x in low for x in ("synchronize", "c10d::wait", "processgroupnccl::wait")):
            sync[name][0] += 1
            sync[name][1] += duration
        if cat in ("cpu_op", "user_annotation") and ("c10d" in low or "nccl" in low):
            key = cat + ": " + name
            entry = cpu_payloads[key]
            entry["count"] += 1
            entry["host_duration_sum_us"] += duration
            payload = collective_payload(args)
            entry["dtypes"][payload["dtype"] or "unknown"] += 1
            entry["explicit_byte_field_sums"].update(payload["explicit_byte_fields"])
            entry["recorded_element_count_sums"].update(payload["recorded_element_counts"])
            entry["bytes_from_recorded_count_and_dtype_sums"].update(payload["bytes_from_recorded_count_and_dtype"])
            entry["records_with_byte_fields"] += bool(payload["explicit_byte_fields"])
            entry["records_with_derived_bytes"] += bool(payload["bytes_from_recorded_count_and_dtype"])
            if len(entry["samples"]) < 8:
                entry["samples"].append(payload)

    def ranked(stats, limit=None):
        result = [dict(name=name, count=value[0], duration_sum_ms=value[1] / 1000)
                  for name, value in sorted(stats.items(), key=lambda item: item[1][1], reverse=True)]
        return result if limit is None else result[:limit]

    scope_unions = {name: union_intervals([array("d", itertools.chain.from_iterable(
        (row["ts_us"], row["end_us"]) for row in values))]) for name, values in phases.items()}
    device_results = []
    for device, raw in sorted(devices.items()):
        nccl = union_intervals([raw["nccl"]])
        non_nccl = union_intervals([raw["non_nccl"]])
        kernels = union_intervals([nccl, non_nccl])
        memory_union = union_intervals([raw["gpu_memcpy"], raw["gpu_memset"]])
        activity = union_intervals([kernels, memory_union])
        row = dict(device=device, kernel_union_ms=duration_us(kernels) / 1000,
                   nccl_union_ms=duration_us(nccl) / 1000, non_nccl_union_ms=duration_us(non_nccl) / 1000,
                   nccl_non_nccl_overlap_ms=duration_us(intersection(nccl, non_nccl)) / 1000,
                   all_gpu_activity_union_ms=duration_us(activity) / 1000,
                   activity_span_ms=(activity[-1] - activity[0]) / 1000 if activity else 0, scopes={})
        for name, scope in scope_unions.items():
            gpu = intersection(activity, scope)
            compute = intersection(non_nccl, scope)
            comm = intersection(nccl, scope)
            overlap = intersection(compute, comm)
            host = duration_us(scope)
            tail = array("d")
            if compute and comm and scope:
                tail = intersection(comm, array("d", (compute[-1], scope[-1])))
            row["scopes"][name] = dict(
                host_union_ms=host / 1000, all_gpu_activity_union_ms=duration_us(gpu) / 1000,
                temporal_gpu_busy_pct=100 * duration_us(gpu) / host if host else None,
                non_nccl_kernel_union_ms=duration_us(compute) / 1000, nccl_union_ms=duration_us(comm) / 1000,
                nccl_non_nccl_overlap_ms=duration_us(overlap) / 1000,
                nccl_without_non_nccl_ms=(duration_us(comm) - duration_us(overlap)) / 1000,
                nccl_after_last_non_nccl_ms=duration_us(tail) / 1000 if compute else None)
        device_results.append(row)

    return dict(
        schema=1, scope="One profiled step; temporal intervals, not production throughput or wire-only NCCL cost",
        event_count=n_events, kernel_count=n_kernels, event_counts=dict(counts),
        packed_gpu_intervals=interval_count, packed_interval_bytes=interval_count * 16,
        kernel_duration_sum_ms=sum(value[1] for value in kernel_names.values()) / 1000,
        top20_kernels=ranked(kernel_names, 20), kernel_categories_heuristic=ranked(categories),
        nccl_gpu_kernels=[dict(row, operation=operation(row["name"]),
                              dtype_symbol=(re.search(r"_(bf16|f16|f32|f64|u8|i8|i32|i64)(?:_|$)",
                                                      row["name"].lower()).group(1)
                                            if re.search(r"_(bf16|f16|f32|f64|u8|i8|i32|i64)(?:_|$)",
                                                         row["name"].lower()) else None),
                              payload_samples=payload_samples[row["name"]])
                          for row in ranked(collectives)],
        nccl_kernel_operation_counts=dict(Counter({op: sum(value[0] for name, value in collectives.items()
            if operation(name) == op) for op in {operation(name) for name in collectives}})),
        cpu_collectives=[dict(name=name, operation=operation(name), **entry) for name, entry in cpu_payloads.items()],
        scalar_host_calls=ranked(scalar), synchronization_host_calls=ranked(sync),
        gpu_memory_activities=[dict(row, recorded_bytes=memory_bytes.get(row["name"], 0))
                               for row in ranked(memory)],
        devices=device_results, scope_host_ranges=dict(phases),
        metadata=metadata,
        boundaries=[
            "Trace parsing stores no CPU DAG, CPU event list or tensor data; only aggregates and packed GPU intervals.",
            "Temporary interval sorting is O(number GPU intervals); raw events are decoded one at a time.",
            "GPU busy within CPU scope is timestamp clipping, not CUDA launch ancestry or unprofiled utilization.",
            "NCCL kernel duration includes rendezvous/resource waits and cannot be called wire transfer time.",
            "NCCL-only time/tail is temporal separation from non-NCCL kernels, not proven removable critical-path cost.",
            "CPU c10d and NCCL annotations can describe the same collective; layer counts and times are not additive.",
            "Byte fields are recorded arguments; derived bytes require recorded nelems and recognized dtype. Missing bytes stay unknown.",
            "Kernel category rules are name heuristics; fused kernels may span multiple operations.",
            "Profiler overhead/start/stop perturbs timing; exclude metadata throughput_excluded_steps from comparisons.",
        ])


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trace", required=True, type=Path)
    parser.add_argument("--metadata", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    metadata = json.loads(args.metadata.read_text())
    result = summarize(args.trace, metadata)
    result["sources_sha256"] = {str(path.resolve()): file_sha256(path)
                                for path in (args.trace, args.metadata, Path(__file__))}
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + chr(10))
    print(json.dumps(dict(output=str(args.output), event_count=result["event_count"],
                          kernel_count=result["kernel_count"], devices=result["devices"])))


if __name__ == "__main__":
    main()
