"""Isolated frozen-v2 FP8 head tile, including fresh-input graph replay costs."""
from __future__ import annotations

import torch

import matmul_prototype_v2 as v2
from rlforge.fp8 import forward_mm, scaled_mm


def eager_tile(inputs, *, need_h=True, need_w=True, ls=1.0, inv_t=1.0):
    hq, hs, wq, ws, log_z, g, ent, targets, wtq, wts, htq, hts = inputs
    logits = forward_mm(hq, wq, hs, ws)
    gq, gtq, gs = v2.quantized_gradient(logits, log_z, g, None, ent, targets, ls, inv_t)
    results = []
    if need_h:
        results.append(scaled_mm(gq, wtq, gs, wts, out_dtype=torch.float32))
    if need_w:
        results.append(scaled_mm(gtq, htq, gs, hts, out_dtype=torch.float32))
    return tuple(results)


class HeadTileGraph:
    def __init__(self, inputs, *, need_h=True, need_w=True, ls=1.0, inv_t=1.0,
                 max_bytes=768 * 2**20):
        if inputs[0].shape != (4096, 1024) or inputs[2].shape != (16384, 1024):
            raise ValueError("Diagnostic graph supports only M4096 V16384 H1024")
        if not (need_h or need_w):
            raise ValueError("At least one gradient output is required")
        if not all(x.is_cuda and x.device == inputs[0].device for x in inputs):
            raise ValueError("All graph inputs must share one CUDA device")
        self.options = dict(need_h=need_h, need_w=need_w, ls=float(ls), inv_t=float(inv_t))
        self.signature = tuple((x.shape, x.dtype, x.stride(), x.device) for x in inputs)
        before_allocated = torch.cuda.memory_allocated()
        before_reserved = torch.cuda.memory_reserved()
        self.inputs = tuple(x.detach().clone() for x in inputs)
        self.stream = torch.cuda.Stream(device=inputs[0].device)
        current = torch.cuda.current_stream(inputs[0].device)
        self.stream.wait_stream(current)
        with torch.cuda.stream(self.stream), torch.no_grad(), torch.autocast('cuda', enabled=False):
            for _ in range(2):
                outputs = eager_tile(self.inputs, **self.options)
                del outputs
        current.wait_stream(self.stream)
        self.graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(self.graph, stream=self.stream), torch.no_grad(), torch.autocast('cuda', enabled=False):
            self.outputs = eager_tile(self.inputs, **self.options)
        self.allocated_bytes = torch.cuda.memory_allocated() - before_allocated
        self.reserved_bytes = torch.cuda.memory_reserved() - before_reserved
        pool = torch.cuda.memory.memory_snapshot(mempool_id=self.graph.pool(), include_traces=False)
        self.pool_reserved_bytes = sum(segment['total_size'] for segment in pool)
        self.static_input_bytes = sum(x.numel() * x.element_size() for x in self.inputs)
        self.bytes = self.pool_reserved_bytes + self.static_input_bytes
        if self.bytes > max_bytes:
            self.graph.reset()
            self.inputs = self.outputs = ()
            raise MemoryError(f"Head tile graph uses {self.bytes} bytes, limit {max_bytes}")

    def __call__(self, inputs):
        signature = tuple((x.shape, x.dtype, x.stride(), x.device) for x in inputs)
        if signature != self.signature:
            raise ValueError("Head tile graph input signature changed")
        for destination, source in zip(self.inputs, inputs):
            destination.copy_(source)
        self.graph.replay()
        return tuple(x.clone() for x in self.outputs)

    def close(self):
        self.graph.reset()
        self.inputs = self.outputs = ()
