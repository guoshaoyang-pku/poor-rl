"""One reserved H200: real head weights, synthetic finite activations and zero-row backward."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import statistics
import sys
import time


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_weight(checkpoint, vocab):
    from safetensors import safe_open
    import torch

    candidates = ("lm_head.weight", "model.language_model.lm_head.weight",
                  "model.language_model.embed_tokens.weight", "model.embed_tokens.weight")
    index = checkpoint / "model.safetensors.index.json"
    if index.exists():
        mapping = json.loads(index.read_text())["weight_map"]
        key = next((k for k in candidates if k in mapping), None)
        if key is None:
            raise KeyError("Checkpoint has no supported language head or tied embedding weight")
        paths = [checkpoint / mapping[key]]
    else:
        paths = sorted(checkpoint.glob("*.safetensors"))
    for path in paths:
        with safe_open(str(path), framework="pt", device="cpu") as handle:
            key = next((k for k in candidates if k in handle.keys()), None)
            if key is None:
                continue
            tensor = handle.get_slice(key)
            shape = tensor.get_shape()
            if shape[0] < vocab or shape[1] != 1024:
                raise ValueError(f"Expected real head H1024 and at least {vocab} rows, got {shape}")
            weight = tensor[:vocab, :].contiguous()
            return weight, dict(path=str(path), key=key, checkpoint_shape=shape,
                                selected_shape=list(weight.shape), selected_sha256=hashlib.sha256(
                                    weight.view(torch.uint8).numpy().tobytes()).hexdigest())
    raise FileNotFoundError("No supported language head checkpoint tensor")


def run(args):
    assigned = os.environ.get("CUDA_VISIBLE_DEVICES", "").split(",")
    if len(assigned) != 1 or not assigned[0].strip():
        raise ValueError("CUDA_VISIBLE_DEVICES must name exactly one root-reserved GPU")
    sys.path[:0] = [str(args.frozen / "code"), str(args.frozen)]
    os.environ.update(RLFORGE_FP8_GRAPHS="0", RLFORGE_FP8_HEAD_GRAPH="0")
    import torch
    import torch.nn.functional as F
    from rlforge import fast_logprob as flp, fp8
    import matmul_prototype as base
    import matmul_prototype_v2 as v2
    import head_zero_rows as candidate

    torch.set_num_threads(1)
    torch.manual_seed(19)
    if flp.TOK_CHUNK != 4096 or flp.VOCAB_CHUNK != 16384:
        raise ValueError("Gate requires original TOK_CHUNK4096 and VOCAB_CHUNK16384")
    if torch.cuda.get_device_capability()[0] < 9:
        raise RuntimeError("Native FP8 gate requires Hopper or newer")
    restore_v2 = v2.install_for_benchmark(None)
    baseline = flp._fp8_backward
    restore_candidate = candidate.install_for_benchmark(None)
    assert flp._fp8_backward is not baseline
    restore_candidate()
    assert flp._fp8_backward is baseline
    vocab = args.vocab_tiles * flp.VOCAB_CHUNK
    cpu_weight, weight_info = load_weight(args.checkpoint, vocab)
    if cpu_weight.dtype != torch.float32:
        raise ValueError("Gate requires the real FP32 master checkpoint weight")
    weight = cpu_weight.cuda()
    del cpu_weight
    weight._rlforge_fp8_head = True
    with torch.no_grad():
        cache = flp._fp8_head_cache(weight)
    wq, ws, backward_weights = cache

    def metrics(expected, actual):
        if expected is None:
            return dict(expected_none=True, actual_none=actual is None, passed=actual is None)
        if actual is None:
            return dict(expected_none=False, actual_none=True, passed=False)
        ef, af = expected.float(), actual.float()
        en, an = torch.linalg.vector_norm(ef), torch.linalg.vector_norm(af)
        error = torch.linalg.vector_norm(af - ef)
        relative = float(error / en.clamp_min(1e-30))
        cosine = (1.0 if float(an) == 0 else 0.0) if float(en) == 0 else float(
            F.cosine_similarity(ef.flatten(), af.flatten(), dim=0, eps=1e-30))
        finite = bool(torch.isfinite(actual).all())
        return dict(dtype=str(actual.dtype), finite=finite, exact=torch.equal(expected, actual),
                    relative_l2=relative, cosine=cosine, max_abs=float((af - ef).abs().max()),
                    passed=actual.dtype == torch.float32 and finite and relative <= args.relative_limit
                    and cosine >= args.cosine_limit)

    def time_pair(baseline_call, candidate_call):
        for _ in range(args.warmup):
            for fn in (baseline_call, candidate_call):
                value = fn()
                del value
        torch.cuda.synchronize()
        values = {"baseline": [], "candidate": []}
        for iteration in range(args.repeats):
            order = (("baseline", baseline_call), ("candidate", candidate_call))
            if iteration % 2:
                order = order[::-1]
            for name, fn in order:
                start, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
                wall = time.perf_counter()
                start.record()
                value = fn()
                end.record()
                end.synchronize()
                values[name].append(dict(cuda_event_ms=start.elapsed_time(end),
                                         wall_ms=(time.perf_counter() - wall) * 1000))
                del value
        median = {name: statistics.median(v["cuda_event_ms"] for v in samples)
                  for name, samples in values.items()}
        return dict(samples=values, cuda_event_median_ms=median,
                    baseline_over_candidate=median["baseline"] / median["candidate"])

    def scale_gate(h, targets, log_z, ent, g, audit):
        checks = []
        for record in audit:
            t0, t1 = record["t0"], record["t1"]
            if record["skipped"]:
                checks.append(dict(t0=t0, t1=t1, skipped=True, passed=True))
                continue
            expected_compacted = t1 - t0 >= 1024 and record["active_rows"] * 2 <= t1 - t0
            compaction_exact = record["compacted"] == expected_compacted
            hc = h[t0:t1]
            hq, hs = fp8.quantize_rows(hc)
            pad = (-(t1 - t0)) % 16
            hp = F.pad(hc, (0, 0, 0, pad)) if pad else hc
            expected_hs = fp8._tensor_scale(hp, 448.0)
            hidden_exact = torch.equal(expected_hs, record["hidden_scale"])
            gradients = []
            for vi, v0 in enumerate(range(0, vocab, flp.VOCAB_CHUNK)):
                logits = fp8.forward_mm(hq, wq[v0:v0 + flp.VOCAB_CHUNK], hs,
                                        ws[v0:v0 + flp.VOCAB_CHUNK])
                _, _, expected_gs = v2.quantized_gradient(
                    logits, log_z[t0:t1], g[t0:t1], None, ent[t0:t1],
                    targets[t0:t1] - v0, 1.0, 1.0)
                actual_gs = record["gradient_scales"][vi]
                gradients.append(dict(exact=torch.equal(expected_gs, actual_gs),
                                      baseline=float(expected_gs), candidate=float(actual_gs)))
            active = (g[t0:t1] != 0).nonzero(as_tuple=False).flatten()
            active_hs = fp8._tensor_scale(hc.index_select(0, active), 448.0)
            checks.append(dict(t0=t0, t1=t1, skipped=False, hidden_scale_exact=hidden_exact,
                               compacted=record["compacted"], compaction_threshold_exact=compaction_exact,
                               original_hidden_scale=float(expected_hs),
                               compact_recomputed_scale_forbidden=float(active_hs),
                               inactive_outlier_changes_hidden_scale=not torch.equal(expected_hs, active_hs),
                               per_vocab_gradient_scales=gradients,
                               passed=hidden_exact and compaction_exact and all(v["exact"] for v in gradients)))
        return checks

    cases = [("full", 4096, fraction) for fraction in (0.0, 0.5, 0.9, 1.0)]
    cases += [("partial", 4096 + args.partial_rows, fraction) for fraction in (0.0, 0.5, 0.9, 1.0)]
    cases.append(("zero_first_tile", 4096 + args.partial_rows, 4096 / (4096 + args.partial_rows)))
    records = []
    try:
        with torch.no_grad():
            for label, count, fraction in cases:
                h = torch.randn(count, 1024, device="cuda", dtype=torch.bfloat16) * 0.2
                targets = torch.randint(0, vocab, (count,), device="cuda")
                g = torch.randn(count, device="cuda", dtype=torch.float32) * 1e-4
                zero_count = int(round(count * fraction))
                if label == "zero_first_tile":
                    zeros = torch.arange(4096, device="cuda")
                elif zero_count:
                    zeros = torch.cat((torch.zeros(1, device="cuda", dtype=torch.long),
                                       torch.randperm(count - 1, device="cuda")[:zero_count - 1] + 1))
                else:
                    zeros = torch.empty(0, device="cuda", dtype=torch.long)
                g[zeros] = 0
                if zero_count:
                    h[0] *= 32
                log_z, _, ent = flp._stats(h, weight, targets, 1.0, 1.0, cache, graph=False)
                assert all(bool(torch.isfinite(x).all()) for x in (h, log_z, ent, g))
                row = dict(case=label,rows=count,vocab=vocab,hidden=1024,
                           exact_zero_rows=int((g == 0).sum()),zero_fraction=float((g == 0).float().mean()),
                           inactive_hidden_outlier=zero_count > 0,comparisons=[])
                for need_h, need_w in ((True, True), (True, False), (False, True), (False, False)):
                    inputs = (h, targets, log_z, ent, g, None, cache, need_h, need_w, 1.0, 1.0)
                    expected = baseline(*inputs)
                    audit = []
                    actual = candidate._fp8_backward(*inputs, audit=audit)
                    comparison = dict(need_h=need_h,need_w=need_w,
                                      dh=metrics(expected[0], actual[0]),dw=metrics(expected[1], actual[1]),
                                      inactive_dh_exact_zero=actual[0] is None or bool((actual[0][g == 0] == 0).all()))
                    if need_w:
                        comparison["scale_checks"] = scale_gate(h, targets, log_z, ent, g, audit)
                    comparison["passed"] = (comparison["dh"]["passed"] and comparison["dw"]["passed"]
                                              and comparison["inactive_dh_exact_zero"]
                                              and all(v["passed"] for v in comparison.get("scale_checks", [])))
                    if fraction == 0.0:
                        comparison["nozeros_exact_control"] = (
                            (not need_h or comparison["dh"]["exact"])
                            and (not need_w or comparison["dw"]["exact"]))
                        comparison["passed"] &= comparison["nozeros_exact_control"]
                    if need_h and need_w:
                        row["timing"] = time_pair(lambda: baseline(*inputs),
                                                  lambda: candidate._fp8_backward(*inputs))
                        skip_only = candidate._fp8_backward(*inputs, compact=False)
                        row["skip_only_control"] = dict(dh=metrics(expected[0], skip_only[0]),
                                                       dw=metrics(expected[1], skip_only[1]))
                        comparison["passed"] &= all(v["passed"] for v in row["skip_only_control"].values())
                        del skip_only
                    row["comparisons"].append(comparison)
                    del expected, actual
                if label == "full" and fraction in (0.5, 0.9):
                    row["outlier_scale_trap_passed"] = any(
                        v.get("inactive_outlier_changes_hidden_scale", False)
                        for check in row["comparisons"] for v in check.get("scale_checks", []))
                else:
                    row["outlier_scale_trap_passed"] = True
                row["passed"] = row["outlier_scale_trap_passed"] and all(v["passed"] for v in row["comparisons"])
                records.append(row)
                print(json.dumps({k: v for k, v in row.items() if k != "comparisons"}), flush=True)
                del h, targets, g, log_z, ent
    finally:
        restore_v2()
    return dict(scope="Isolated native FP8 head backward only; real first head vocab tiles, synthetic BF16 h; no optimizer/DDP/rollout or full-model claim",
                sources_sha256={"candidate": sha(Path(__file__).with_name("head_zero_rows.py")),
                                "gate": sha(__file__), "frozen_fp8": sha(args.frozen / "code/rlforge/fp8.py"),
                                "frozen_fast_logprob": sha(args.frozen / "code/rlforge/fast_logprob.py"),
                                "frozen_matmul": sha(args.frozen / "matmul_prototype.py"),
                                "frozen_matmul_v2": sha(args.frozen / "matmul_prototype_v2.py")},
                torch=torch.__version__,gpu=torch.cuda.get_device_name(),weight=weight_info,
                tolerances=dict(relative_l2=args.relative_limit,cosine=args.cosine_limit),
                controls=dict(install_restore=True,forward_unchanged=True,original_logit_replay_shape=True,
                              original_hidden_transpose_scale=True,per_vocab_gradient_scale_exact=True,
                              entropy_gradient=None,finite_inputs_required=True),
                memory_peak_allocated_gib=torch.cuda.max_memory_allocated() / 2**30,
                cases=records,all_passed=all(r["passed"] for r in records),
                boundary="Compaction changes GEMM contraction length/reduction order; gradient metrics determine acceptance. Selection/gather overhead is included. Full original FP8 logit replay is retained in partial tiles.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--frozen", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--vocab-tiles", type=int, choices=(1, 2), default=2)
    parser.add_argument("--partial-rows", type=int, default=17)
    parser.add_argument("--warmup", type=int, default=2)
    parser.add_argument("--repeats", type=int, default=5)
    parser.add_argument("--relative-limit", type=float, default=5e-4)
    parser.add_argument("--cosine-limit", type=float, default=0.999999)
    arguments = parser.parse_args()
    if arguments.output.exists():
        raise FileExistsError(arguments.output)
    if not 0 < arguments.partial_rows < 4096 or arguments.repeats < 1 or arguments.warmup < 0:
        parser.error("Use 1..4095 partial rows, positive repeats and nonnegative warmup")
    result = run(arguments)
    arguments.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(dict(all_passed=result["all_passed"], output=str(arguments.output))), flush=True)
    raise SystemExit(0 if result["all_passed"] else 1)
