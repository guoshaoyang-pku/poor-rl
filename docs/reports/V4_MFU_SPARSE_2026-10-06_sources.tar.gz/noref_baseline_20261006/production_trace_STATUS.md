# 四卡生产 trace 审核

已核对 4＋4、β=0、step4 的四 rank trace；保留原 GSPO＋Luna judge/reward。metadata、已保存源码 hash、kernel 总数／总时长、GPU 区间并集和 DDP bucket 总量全部一致。原始 trace 留在远端，本次仅读本地摘要。详细字段及来源 hash 见 [production_trace_review.json](production_trace_review.json)。

## 实际记录

| rank | 训练 host 秒 | 非 NCCL kernel 并集秒 | GPU 活动占训练区间 | fetch 中 NCCL 秒 | 指标 AllGather 秒 | final DDP host 秒 | profiler stop/export 秒 |
|---|---:|---:|---:|---:|---:|---:|---:|
| 0 | 66.638 | 44.776 | 72.8% | 0.001 | 3.0890 | 1.081 | 40.306 |
| 1 | 66.524 | 45.289 | 69.0% | 8.738 | 0.0001 | 1.097 | 40.559 |
| 2 | 66.493 | 45.057 | 76.9% | 8.765 | 0.0903 | 1.058 | 38.522 |
| 3 | 66.488 | 45.267 | 72.5% | 8.739 | 0.1016 | 1.053 | 40.498 |

GPU 活动包含 NCCL 等待，不能当作 SM 利用率或 MFU。训练区间约 15–21 秒空隙受到 profiler 扰动，stop/export 另有 38.52–40.56 秒。step4 不用于吞吐对照，也不能把空隙视为生产中可直接省掉的时间；trace arm 下一步的 rank0 指标还等待 2.106 秒，也不作为正常生产对照。

## 等待和传输

18 个 FP32 指标仅输入 72 bytes/rank、输出 288 bytes。各 rank 到达指标范围相差 **3.087 秒**，退出只差 **0.613 ms**；rank0 的 3.089 秒主要反映先到者等后到者。独立未 profile 的 4＋6 三步中，指标调用每步取最慢 rank 后合计只有 0.52688 秒。

其他 rank 的 batch broadcast 8.74–8.77 秒包含 rank0 队列／collator／ready 等待；rank0 在 fetch 范围内 NCCL 只有 1.24 ms。installed Accelerate 在本地 slice 前广播完整 batch，并在非 root 端先把完整临时张量送到 GPU。不能把等待 kernel 的长度当作 wire 传输时间。中间层 broadcast 也可能暴露 rank 到达不平衡，当前摘要未保留每次完整 payload，不能逐次归因。

第一条 int64 字段有 25,170,164 个元素／201,361,312 bytes。四个 int64＋两个 FP32 合计 **40 bytes/token slot**，完整矩形 batch 为 **1,006,806,560 bytes（约 1.007 GB）**，与每个 rank 的约 1.007 GB H2D 记录吻合。旧 comm_audit 的 44 bytes/token 是算术错误；4＋6 三步 67,333,290 个未共享输入 token 的最低字段体积应为 2.693 GB。理想平均分片为 251.7 MB/rank，净收益需独立计时。

摘要仅保留每种 NCCL kernel 前三个 payload，CPU c10d 没有 dtype/count，不能补造全部 bucket／broadcast 的 wire 字节数。Memcpy 的 recorded bytes 也不能直接换成真实 HBM 带宽。

## DDP、FP8 与 FP32

四个 rank 都只有 **61 个梯度 all-reduce／update**；GPU 的 63 次含 2 个 barrier。61 个实际 bucket 合计 **3,009,572,096 bytes FP32 梯度**，与 320 个主参数张量一致；cap 为 25 MiB，最大 embedding/head bucket 为 1,042,288,640 bytes。早期 56–60 个 local backward 没有 NCCL，最后恰好一次 DDP backward；GAS=1。

final DDP host 为 1.053–1.097 秒，同时包含 0.569–0.715 秒非 NCCL kernel；该范围内 NCCL 不与非 NCCL 重叠的部分为 0.050–0.360 秒。DDP logger 的通信事件跨度为 0.618–0.678 秒、overlap 为 0.361–0.613 秒；与 kernel 并集口径不同，也不是纯 wire 时间。`gradient_as_bucket_view=False` 和大 bucket 可检查，当前证据不支持它们解释约 13.4 秒／步缺口。

名字分类的“FP8”只有约 4.4 秒，漏掉了 `nvjet_sm90_*` 原生 FP8 backward。此前同 recipe 的 dtype／shape 记录已确认包括 head 的 E5M2×E4M3 dgrad/wgrad：188.423 T FLOPs；不能据新分类声称大部分 backward 还没 FP8。敏感算子、量化、FP32 梯度 add/cast、norm/conv/GDN 成本仍存在。独立单 G32 的 FP32 Adam 约 6.43 ms；完整 4＋6 weight sync 仅 0.263 秒／步（0.455%总墙钟）。

`aten::item` 约 2.1 万次、stream synchronize 约 4,200 次中包含 CPU 标量与 collective 等待；其 inclusive 区间嵌套，不能把它们相加或都算 GPU→host 往返。

## 三个优先级

1. **减少顺序子批次的提交与索引计划。** 真实 MB1024/rank、GAS1 仍有每步约 50 个 subbatch；profile step 为 57–61 次 backward、每 rank 108–114 万 kernel。先测固定 FP8 head tile graph，含输入拷贝／输出 clone，目标 tile ≥1.15×且固定真实 G32 净计算 ≥1.05×，再接 runtime；cache 初限 256 MiB，必要时 768 MiB 仅供诊断，Adam 后刷新权重及 scale。零行 head 的固定真实 token／权重 G32 fixture 只有 1.0018×，但 loss 为合成数据、没有生产 clip mask，尚不能据此否定生产 clip 稀疏收益；不采用。profile 空隙不作为兑现收益。

2. **降低 conv/norm/GDN、量化和反向写回。** 新 trace 量化约 5 秒、norm 2.9 秒、GDN 3.3 秒、copy/cast 2.6 秒／rank，都是扰动后的 kernel sum。旧单 G32 的 conv/SiLU＋norm＋GDN＋quant 共约 46.4% policy kernel。先对选定块争取 ≥25% 的净耗时下降、完整 G32 ≥10%；保留训练和 serving 的前向 scale、FP32 内部累加与主参数／Adam。native 2:4 sparse 对大多数真实 rowwise 形状更慢，不能以峰值宣传已获收益。

3. **减少 batch 准备和整份复制，再控制 rollout 等待。** 未 profile 的 collator 为 2.067 秒／步，先以 ready 固定 batch 测到 <1 秒、每 rank H2D 约 251.7 MB；保留字段 bits、样本顺序和 G32 隔离。collator 整段消失也最多 1.0371×。4＋6 adaptive 等待目标可设 <5%（现为 11.28%），同时保持 staleness/drop/judge 条件；目前 adaptive 实测只在 4＋4。

独立 4＋6 三步为 **151,401 token/s＝76.78×v1**，同方法 policy compute MFU proxy **14.31%**。100×v1＝197,200 token/s：同 token、其他等待不变，需要计算 **47.82→34.39 秒／步（下降 28.09%）**。MFU proxy 20% 对应 **34.22 秒／步（下降 28.44%）**。三个候选尚无合计兑现这一区间的实测结果；MFU 是四 trainer GPU 的 shape 估算，非整套训推实测 MFU。
