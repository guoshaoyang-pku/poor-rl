"""Capture one warmed optimizer step without changing training or collectives."""
import functools
import gzip
import hashlib
import inspect
import json
from pathlib import Path
import shutil
import sys
import time


def install(trainer, output, *, step=4):
    import torch

    output = Path(output)
    rank = int(trainer.accelerator.process_index)
    trace_path = output / f"train_trace_rank{rank}.json.gz"
    report_path = output / f"train_trace_rank{rank}.metadata.json"
    edits, profiler = [], None
    active, attempted, done, in_subbatch = False, False, False, 0
    local_backwards, final_backwards = 0, 0
    report = dict(
        schema=1, rank=rank, target_optimizer_step=step,
        profiler_flags=dict(record_shapes=False, with_stack=False, profile_memory=False),
        throughput_excluded_steps=[step],
        trace=str(trace_path), errors=[],
        boundaries=[
            "One step starts before get_batch_samples at global_step=target-1.",
            "Stop before native _log_step_metrics; start/stop cost belongs to the excluded step.",
            "Profiler can synchronize internally; observer adds no explicit CUDA sync or collective.",
            "Export/compression is deferred to train finally, outside optimizer-step timing.",
            "Host scopes are nested; kernel overlap and NCCL critical path require trace analysis.",
        ])

    def error(where, exc):
        report["errors"].append(dict(where=where, type=type(exc).__name__, message=str(exc)))

    def ddp_data():
        model = getattr(trainer, "model_wrapped", trainer.model)
        for _ in range(8):
            if isinstance(model, torch.nn.parallel.DistributedDataParallel):
                flags = {name: getattr(model, name, None) for name in (
                    "bucket_bytes_cap", "gradient_as_bucket_view", "broadcast_buffers",
                    "find_unused_parameters", "static_graph",
                    "require_backward_grad_sync", "require_forward_param_sync")}
                return dict(flags=flags, logging_data=model._get_ddp_logging_data())
            if not hasattr(model, "module"):
                break
            model = model.module
        return dict(ddp_found=False, model_type=type(model).__module__ + "." + type(model).__qualname__)

    def sources():
        found = {}
        candidates = [type(trainer), type(trainer.accelerator),
                      inspect.unwrap(trainer.compute_loss),
                      inspect.unwrap(trainer._compute_loss_subbatched)]
        candidates += [sys.modules[name] for name in (
            "accelerate.data_loader", "accelerate.accelerator", "transformers.trainer",
            "trl.experimental.async_grpo.async_grpo_trainer") if name in sys.modules]
        for value in candidates:
            try:
                path = inspect.getsourcefile(value)
                if path and Path(path).is_file():
                    found[str(Path(path).resolve())] = hashlib.sha256(Path(path).read_bytes()).hexdigest()
            except (OSError, TypeError) as exc:
                error("source_metadata", exc)
        path = Path(__file__).resolve()
        found[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
        return found

    def begin():
        nonlocal profiler, active, attempted
        if attempted or int(trainer.state.global_step) + 1 != step:
            return
        attempted = True
        report["start_global_step"] = int(trainer.state.global_step)
        report["start_monotonic_s"] = time.perf_counter()
        try:
            report["sources_sha256"] = sources()
            report["ddp_before"] = ddp_data()
            report["torch_version"] = torch.__version__
            profiler = torch.profiler.profile(
                activities=[torch.profiler.ProfilerActivity.CPU, torch.profiler.ProfilerActivity.CUDA],
                record_shapes=False, with_stack=False, profile_memory=False)
            profiler.start()
            active = True
        except Exception as exc:
            error("profiler_start", exc)

    def stop():
        nonlocal active
        if not active:
            return
        active = False
        started = time.perf_counter()
        try:
            profiler.stop()
            report["capture_stopped"] = True
            report["ddp_after"] = ddp_data()
        except Exception as exc:
            error("profiler_stop", exc)
        report["stop_global_step"] = int(trainer.state.global_step)
        report["stop_monotonic_s"] = time.perf_counter()
        report["stop_host_s"] = time.perf_counter() - started

    def replace(owner, name, replacement):
        existed = name in owner.__dict__
        edits.append((owner, name, existed, owner.__dict__.get(name)))
        setattr(owner, name, replacement)

    def wrap(owner, name, label, *, starts=False, subbatch=False, backward=False):
        original = getattr(owner, name)

        @functools.wraps(original)
        def observed(*args, **kwargs):
            nonlocal in_subbatch, local_backwards, final_backwards
            if starts:
                begin()
            if not active:
                return original(*args, **kwargs)
            scope = label
            if backward:
                if in_subbatch:
                    scope = "v4trace/backward/local_subbatch"
                    local_backwards += 1
                else:
                    scope = "v4trace/backward/final_ddp"
                    final_backwards += 1
            if subbatch:
                in_subbatch += 1
            try:
                with torch.profiler.record_function(scope):
                    return original(*args, **kwargs)
            finally:
                if subbatch:
                    in_subbatch -= 1

        replace(owner, name, observed)

    for name in ("get_batch_samples", "training_step", "_compute_loss_subbatched",
                 "_loss_metrics", "_clip_grad_norm", "_sync_weight"):
        if callable(getattr(trainer, name, None)):
            wrap(trainer, name, "v4trace/" + name, starts=name in ("get_batch_samples", "training_step"),
                 subbatch=name == "_compute_loss_subbatched")
    wrap(trainer.accelerator, "backward", "v4trace/backward", backward=True)

    native_log_step = trainer._log_step_metrics

    @functools.wraps(native_log_step)
    def log_step(*args, **kwargs):
        if active and int(trainer.state.global_step) >= step:
            stop()
        return native_log_step(*args, **kwargs)

    replace(trainer, "_log_step_metrics", log_step)
    replaced_callbacks = 0
    for callback in trainer.callback_handler.callbacks:
        if getattr(callback, "fn", None) == native_log_step:
            replace(callback, "fn", log_step)
            replaced_callbacks += 1
    report["log_step_callbacks_replaced"] = replaced_callbacks
    native_event = trainer.callback_handler.call_event

    @functools.wraps(native_event)
    def event(name, *args, **kwargs):
        value = native_event(name, *args, **kwargs)
        if name == "on_step_end" and active and int(trainer.state.global_step) >= step:
            stop()
            report["throughput_excluded_steps"] = [step, step + 1]
            report["stop_after_anchor_fallback"] = True
        return value

    replace(trainer.callback_handler, "call_event", event)

    def finish():
        nonlocal done
        if done:
            return
        done = True
        training_error = sys.exc_info()[0]
        report["training_exception"] = None if training_error is None else training_error.__name__
        stop()
        for owner, name, existed, previous in reversed(edits):
            try:
                if existed:
                    setattr(owner, name, previous)
                else:
                    delattr(owner, name)
            except Exception as exc:
                error("restore_" + name, exc)
        report.update(capture_attempted=attempted, local_subbatch_backwards=local_backwards,
                      final_ddp_backwards=final_backwards)
        raw_path = trace_path.with_suffix("")
        try:
            output.mkdir(parents=True, exist_ok=True)
            if report.get("capture_stopped"):
                profiler.export_chrome_trace(str(raw_path))
                with raw_path.open("rb") as source, gzip.open(trace_path, "wb", compresslevel=1) as target:
                    shutil.copyfileobj(source, target, length=1024 * 1024)
                report["trace_bytes"] = trace_path.stat().st_size
                raw_path.unlink()
        except Exception as exc:
            error("trace_export", exc)
        try:
            output.mkdir(parents=True, exist_ok=True)
            report_path.write_text(json.dumps(report, indent=2, default=str) + chr(10))
        except Exception as exc:
            print(json.dumps(dict(v4_trace_metadata_error=type(exc).__name__, rank=rank)), flush=True)

    return finish
