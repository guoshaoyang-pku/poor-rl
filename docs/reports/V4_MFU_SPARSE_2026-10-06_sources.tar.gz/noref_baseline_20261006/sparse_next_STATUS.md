# 零梯度反向跳过：下一步审查

CPU只读审查完成；不重复GPU实验，不改冻结输入、canonical或recipe。当前候选没有完整模型净收益，不能据此宣称20% compute MFU或100×v1已达到。

## 已测结果与分母

head_zero_rows_gate_v3的candidate257dbf99/gate12113143全部数值、scale、零行检查通过。独立M4096的50%/90%零行为1.023×/1.190×，M4113仅0.788×/0.755×。真实completion固定G32完整模型compute1046.930→1045.048ms（1.00180×），wall1058.335→1059.472ms（0.99893×）；其advantages/old logprobs是seed19合成、Adam lr=0，没有生产clip mask或实际g零行计数。等loss不证明非零LR更新或训推一致。

生产4+6、steps4–6的GSPO下侧flat5387、上侧flat1，共5388/12288=43.84765625%序列。这是surrogate对该序列logprob导数为零的比例；95.5729%的下界crossing忽略advantage符号，不能用来跳过。inactive completion-token比例应为Σinactive L_i/ΣL_i；decoder计算还含prompt tail、padding、共享prefix、checkpoint和不同层的成本。43.85%不是零token比例，也不是可省43.85% FLOPs。

native rollout源码async_rollout_worker.py:1023–1028按同group reward中心化生成advantage。完整、未drop且reward非统一的G32通常仍有正advantage兄弟，而本窗口上侧flat仅1条；不能仅凭全局flat比例期待大批整G32全零。全零advantage的uniform-reward组和长度拆分后的subbatch更值得计数。当前frac_reward_zero_std和group mask未保存，已有数据不能计算这些候选频率。

## 零梯度怎样传播

| 路径 | 可以跳过的边界 | 必须保留 |
|---|---|---|
| LM head | 完整TOK_CHUNK全零可跳反向；部分行压缩已测 | 完整原tile的hidden转置scale、原logits replay形状、vocab gradient scale和FP32 tile累加；不能跨tile重排 |
| RMS/QK/gated norm | 单token整channel upstream全零时，该行dx/dgate和dw贡献为零 | 其他active行的weight归约顺序；原FP32 norm参数梯度；每层host nonzero通常不值得 |
| Linear/融合MLP | 行内算子保持零行；整调用全零可省反向 | wgrad的原xs.amax/hs.amax，包括inactive hidden outlier；梯度量化原范围、FP32输出、相同GEMM归约 gate |
| causal conv | 整条branch的所有时间upstream全零，可省该branch贡献 | 活跃输出会传回前3个输入和共享prompt tail；单个输出token零不代表对应输入梯度零 |
| GDN与attention | 整条branch及其所有输出state无下游梯度才可跳 | 未来active token会传回早期state/K/V/token；attention的dK/dV不能按当前query零行直接删 |
| G32共享prefix | 本subbatch全部branch无loss梯度时，其prefix反向为零 | 任意active兄弟需要prefix的conv tail、GDN state、K/V梯度；所有group/state保持隔离 |

head返回的零hidden行经过cat/index scatter后仍是物化零Tensor；autograd不会自动把它视为None，norm/MLP/GDN反向仍执行。逐层扫描零行会增加选择、scatter和host同步。若按token从GDN内部删行，还会切断未来token到早期state的导数。整个branch虽然数学上独立，当前bucket却是一个[N,L,H] autograd输出；压缩其中部分branch必须改backward调度和scatter。缩小M/B、conv/norm的partial归约与GDN tiling也可能改变浮点结果，不能称逐位等价。

最小可行方案是trainer.py:606的**非末尾完整subbatch**：执行原完整forward、原loss和entropy诊断，确认所有sample的实际logprob导数为零后，保留loss.detach累计并跳过该次backward。它省整条head＋decoder＋checkpoint backward，无需删forward行或重算scale；该subbatch的prefix由自己单独前传（prefix_share.py:638），不切断另一个subbatch的active兄弟。β=0、无entropy/aux loss、finite输入/输出、严格clip边界与原autograd导数语义是前提；loss数值为0本身不构成条件。

首选host已知所有A==0的非末尾块，可在collator已有metadata判断，避免新增GPU→host判定；仍保留原量化forward。纯clip全零只能在当前forward取得rho后确认，逐块.item会强迫GPU完成前传，再由CPU启动反向。可以全GPU判定配合条件执行，但当前Python/torch.autograd路径没有现成无同步分支；不应先做复杂原型。

末尾仍执行原DDP model forward/backward，包括全零时，确保累计的.grad被归约。跳过早期零贡献不能令原本显式zero变成整step grad=None；需检查最终dense backward是否覆盖全部参数、tied embedding/head和各need_grad组合。FP32 master、FP32 Adam动量/weight decay、zero_grad和一次optimizer step完全按原语义；DDP仍一次reduce，loss分母/样本数/trained token计数/GSPO与Luna reward不变。

## 三个实际下一步

1. **先采真实mask账本，决定值不值得实现。** 沿原rho/advantage输出记录每rank/step的zero-A与signed-flat样本、真实completion长度、原subbatch/bucket边界、全零head tile数、全零非末尾subbatch数及active prefix组数；GPU汇总后在step结束一次传小结果。优先复用host segment/advantage信息。采当前mask而非前一step或rollout rho；不改变阈值。compute14.3113%→20%要求省28.4436%同工作量compute，100×v1要求E2E1.30250×；记录的可跳块必须先支持这个量级。无真实whole-block数量，先不再做sparse大E2E。

2. **仅在whole-block计数支持收益时，做非末尾subbatch跳过。** 先实现无新同步的全A==0子集，保留forward形状/scale/统计，最后DDP backward照旧；对真实同batch和非零LR比较全参数FP32.grad、Adam状态、tied weight更新及四rank.reduce。若clip-only块确实多，再测一次forward后判定同步的净收益。零损失、单层零行或抽样梯度不能替代这项gate；当前G32合成fixture不能用作生产mask收益证据。

3. **没有足够整块可跳时，投入dense FP8提交和写回，而非逐层压缩。** 下一项已有fixed head tile graph gate，先测输入刷新/输出clone/峰值全计入的净收益；随后测head FP32 C/beta epilogue，保持原token/vocab累加顺序并先只复用单head调用内部buffer，避免绕过autograd/DDP。旧同G32 head trace的显式FP32 add约13.0677ms/986.2001ms政策kernel≈1.33%，只能作为组合优化。rowwise同契约weight2:4已低于1×；scalar-contract down1.379×只是一块GEMM结果，且wgrad无W操作数，不能包装成整训练2×。

源定位：冻结trainer.py:515–608、prefix_share.py:136–151/182–248/586–673、fp8.py:268–314；frozen fusion_mlp_prototype.py:177–206、branch_conv_silu_fused_prototype.py:86–132、fusion_triton_prototype.py:58–112/141–171。SHA分别为106e2531、b4df9db9、0b0aea57、4eacb3b2、eac45e09、8c4bbd65。raw证据为head_zero_rows_gate_v3.json、results/head_zero_model_pair_v1/{base,zero}.json、clip_review.json、trainer_efficiency_audit.json；本note不改它们。
