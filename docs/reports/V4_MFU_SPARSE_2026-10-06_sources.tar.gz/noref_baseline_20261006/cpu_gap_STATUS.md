# CPU 提交与 GPU 空隙审计 — 2026-10-06

现有 trace 支持优先检查 **FP8 head／小算子的提交、G32 索引计划、collator 分配**。单卡探针的 policy 提交空隙明显，但带逐调用注释与 shape／JSON 记录；生产收益仍需一次低开销 trace。这里只解析本地冻结文件，没有 SSH、GPU 运行或主仓库改动。原始结果和哈希见 [cpu_gap_audit.json](cpu_gap_audit.json)。

## 记录的 GPU 时间

`root_current_recipe_trace6_v1` 是固定 G32、单 H200、FP8 policy＋本地 BF16 reference 的探针；真实 `v4_noref_dp6_static` 是 β=0、4＋6、没有 reference。trace 的区间并集可度量“记录到的 GPU 活动”，不能表示 SM occupancy 或整模型 MFU。

| 范围 | 内核累计 ms | GPU 活动并集 ms | GPU 活动跨度 ms | 跨度内空隙 ms | 活动占跨度 |
|---|---:|---:|---:|---:|---:|
| 全探针 | 1,566.203 | 1,578.128 | 2,079.787 | 501.659 | 75.9% |
| BF16 reference | 570.379 | 571.387 | 606.809 | 35.421 | 94.2% |
| policy forward | 297.717 | 298.074 | 549.623 | 251.548 | 54.2% |
| policy backward | 688.483 | 698.688 | 900.412 | 201.724 | 77.6% |
| 两个 policy 阶段合并 | 986.200 | 996.762 | 1,456.768 | 460.005 | 68.4% |

GPU 活动包括 kernel、memcpy、memset。合并 policy 跨度还包含前反向之间的间隔；单独 phase 由 correlation→CUDA 调用→CPU 注释时刻归属，不能与父级 `compute_loss` 相加。

30,894 个 GPU 空隙合计 501.659 ms，其中 7,941 个空隙的下一次 CUDA 调用在前一段 GPU 活动结束后才开始，合计 **466.250 ms**；按下一次提交归属，policy forward／backward 为 **248.033／184.624 ms**。≥100 µs 空隙合计 233.854 ms；只有 3 个超过 1 ms，合计 6.728 ms。主要是许多短提交间隔。

该 trace 的前反向 CPU 区间为 2,069.704 ms，另一次未 profile 的 CUDA-event compute 中位数为 1,636.970 ms。它们是不同迭代，且 trace 有逐调用形状记录，不能把 432.735 ms 差额或 501.659 ms 空隙投影为生产可省时间。

## 同步、标量读取和真实 host 记录

最大的 `cudaStreamSynchronize` 为 **66.939 ms**，发生在 reference 的 `aten::index→aten::nonzero`；其中 **65.442 ms 与 GPU 活动重叠，只有 1.497 ms 落在空隙**。201 次 stream sync 的 69.704 ms 中，66.001 ms 与 GPU 活动重叠。减少同步可以改变排队方式，现有数据不支持省掉这段 GPU 执行。

1,022 次 `aten::item` 合计 CPU 3.455 ms，其中 960 次输入为 double；真正 DtoH 记录共 201 次、0.475 ms，说明 `.item` 次数不能直接当成 CUDA 同步次数。`aten::empty` 为 15,402 次、67.316 ms CPU，落在 GPU 空隙中的部分为 23.062 ms；分配可检查，但不是全部约 502 ms 空隙的解释。上述 CPU inclusive 区间有嵌套，不能相加。

| 真实 4＋6，step 4–6 | rank 0 合计秒 | 说明 |
|---|---:|---|
| optimizer 墙钟窗口 | 173.501 | 与原始 step 记录一致 |
| `training_step` | 143.466 | inclusive host，含 GPU 执行／等待 |
| `accelerator.backward` | 91.805 | 嵌套在训练中，不能当作纯 CPU 成本 |
| `dispatcher.fetch_batches` | 28.712 | 包含队列阻塞、collator 和 dispatch |
| `collator.torch_call` | 6.201 | 每步 2.180／2.036／1.985；嵌套在 fetch |
| `_loss_metrics` | 0.0347 | 已有单次合并通信；还包含 clip 观察器 |
| optimizer host callback | 0.0064 | 未同步 timer，不能当作 CUDA Adam 时间 |

运行日志和源码哈希确认四个 rank 均启用了 `metrics_batch_prototype` 与 collator 张量化；`_loss_metrics` 的 8–9 次通信与逐项 `.item` 原版已被覆盖为 1 次 gather＋一次 `.cpu().tolist()`。其他三个 rank 的 metrics 合计为 0.403／0.483／0.348 秒，可能含 collective 等待。poslog 未启用，clip 观察器每次另做一次小结果 DtoH。真实 run 每 rank 每步有 48–56 次 backward，变长 subbatch／独立 G32 仍存在；host 文件不能给出生产 GPU 并集或空闲。

## 三个候选

1. **先试固定形状的 FP8 head 子图。** 冻结 `fast_logprob.py:86,130` 的 token／vocab 循环和 `fp8.py:70` 已有 graph hook，真实 run 两个 graph 开关均为 0。policy head forward 和 backward 注释内的 GPU 空隙为 **69.003＋46.215＝115.219 ms**；forward GEMM 共 1,004 次、32 个输入 shape／stride／dtype，最常见 head tile `[4096,1024]×[16384,1024]` 重复 420 次。先捕获这些固定 tile 的量化＋GEMM＋归约，测输入拷贝、输出 clone 与 Adam 后权重刷新。115.219 ms 与 policy 的 432.657 ms 延迟提交预算重叠，都是 profile 观察量。变长整步图需固定索引与分配后另验。

2. **把 G32 计划与完成 token 索引提前放在 host。** 冻结 `trainer.py:541` 做 GPU bool 压实和计划；匹配哈希的 `prefix_share.py:91,647` 有 `nonzero/tolist`、逐样本 prompt DtoH、每 branch 的 `j[keep]`、分配与 gather。探针 reference 之前整段 CPU 只有 **9.110 ms**；32 次 prompt DtoH 共 671,744 bytes，policy 内 32 次 `nonzero` 合计 1.976 ms、stream sync 0.485 ms。用已有 host rollout 数组生成并验证 segment／bucket／seq_id／completion slot，批量传整型映射，再用 gather/scatter；保持独立 G32、样本顺序和 FP32 归约。真实 β=0 计划耗时尚未分开记录，不能乘上 subbatch 数估算收益。

3. **继续量化 collator 的剩余分配与 token 迭代。** `collator_tensorize_prototype.py:53,66` 每 batch 仍新分配六个 dense NumPy buffer，用三次 `fromiter` 和逐样本 position／advantage 填充。真实阶段为 **6.201 秒/3步＝3.57%墙钟**，含嵌套 0.257 秒 metrics；即使整段消失，同窗口速度上限也只有 **1.0371×**。先对一个真实 ready 4,096 样本 batch 做 CPU profile，再考虑带生命周期约束的 buffer 复用／减少 padding 初始化。已启用张量化，不能重新把原始 `torch.tensor(list)` 替换收益计入。

源码路径均指冻结快照，完整绝对路径与 SHA256 已写入 JSON；以上七项 hash 对齐检查全部通过。

## 必要的下一次采样

现有证据足够排序，生产 gap 占比和候选收益需要新 trace。用相同冻结 β=0 配方，暖机至少三步后捕获 **相邻两次 optimizer update 的四个 policy rank**；保留现有 rollout、judge、G32、staleness、clip，采集 CPU＋CUDA kernel／copy／runtime＋NCCL，不新增 synchronize。

只加粗粒度范围：collator 分配／填充／metrics，fetch 中 queue wait 与 dispatch／broadcast／H2D，host plan、branch gather、policy fwd/bwd、head、实际 metrics／clip 观察器、grad clip、Adam／cache refresh、weight sync。第一次设 `record_shapes=False, with_stack=False, profile_memory=False`，用 host 计划保留 shape／group ledger；只在需要时另抓局部 shape trace。候选对比用同一实际 token／plan 的暖 CUDA events，先过零更新和真实 Adam 后的 logprob／FP32 gradient gate，再检查 optimizer 墙钟。
