"""Single H200 gate for a bounded FP8 head tile graph; not full-model evidence."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import statistics
import sys
import time


parser = argparse.ArgumentParser()
parser.add_argument('--frozen', type=Path, required=True)
parser.add_argument('--checkpoint', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--repeats', type=int, default=15)
args = parser.parse_args()
assert len(os.environ.get('CUDA_VISIBLE_DEVICES', '').split(',')) == 1
assert os.environ.get('CUDA_VISIBLE_DEVICES')
assert not args.output.exists()
sys.path[:0] = [str(args.frozen / 'code'), str(args.frozen)]
os.environ.update(RLFORGE_FP8_GRAPHS='0', RLFORGE_FP8_HEAD_GRAPH='0')
import torch
import torch.nn.functional as F
from head_zero_rows_gate import load_weight
from head_tile_graph import eager_tile, HeadTileGraph
from rlforge import fast_logprob as flp, fp8

torch.set_num_threads(1)
torch.manual_seed(19)
assert torch.cuda.get_device_capability()[0] == 9
cpu_weight, weight_info = load_weight(args.checkpoint, 16384)
assert cpu_weight.dtype == torch.float32
weight = cpu_weight.cuda()
del cpu_weight
weight._rlforge_fp8_head = True


def make_inputs(version):
    with torch.no_grad():
        if version:
            weight.add_(torch.randn_like(weight) * 0.001)
        cache = flp._fp8_head_cache(weight)
        wq, ws, backward_weights = cache
        h = torch.randn(4096, 1024, device='cuda', dtype=torch.bfloat16) * (0.2 + version * 0.07)
        hq, hs = fp8.quantize_rows(h)
        htq, hts = fp8._quantize_tensor(h, torch.float8_e4m3fn, transpose=True)
        targets = torch.randint(0, 16384, (4096,), device='cuda')
        logits = fp8.forward_mm(hq, wq, hs, ws).float()
        z = torch.logsumexp(logits, dim=-1)
        ent = -(torch.softmax(logits, dim=-1) * (logits - z[:, None])).sum(-1)
        del logits
        g = torch.randn(4096, device='cuda') * (1e-4 * (version + 1))
        if version:
            g[::3] = 0
        wtq, wts = backward_weights[0]
        return (hq, hs, wq, ws, z, g, ent, targets, wtq, wts, htq, hts)


def compare(expected, actual):
    records = []
    for e, a in zip(expected, actual):
        ef, af = e.float().flatten(), a.float().flatten()
        relative = float(torch.linalg.vector_norm(af - ef) / torch.linalg.vector_norm(ef).clamp_min(1e-30))
        cosine = float(F.cosine_similarity(ef, af, dim=0))
        finite = bool(torch.isfinite(a).all())
        records.append(dict(exact=torch.equal(e, a), relative_l2=relative, cosine=cosine,
                            dtype=str(a.dtype), finite=finite,
                            passed=finite and a.dtype == torch.float32 and relative <= 1e-5 and cosine >= 0.99999))
    return records


def measure(eager, replay):
    for _ in range(3):
        eager()
        replay()
    torch.cuda.synchronize()
    samples = {'eager': [], 'graph': []}
    for i in range(args.repeats):
        pairs = [('eager', eager), ('graph', replay)]
        if i % 2:
            pairs.reverse()
        for name, fn in pairs:
            start, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
            wall = time.perf_counter()
            start.record()
            output = fn()
            end.record()
            end.synchronize()
            samples[name].append(dict(cuda_ms=start.elapsed_time(end), wall_ms=(time.perf_counter()-wall)*1000))
            del output
    medians = {k: statistics.median(x['cuda_ms'] for x in v) for k,v in samples.items()}
    return dict(samples=samples, median_cuda_ms=medians, speed=medians['eager']/medians['graph'])


records = []
with torch.no_grad(), torch.autocast('cuda', enabled=False):
    for need_h, need_w in ((True, True), (True, False), (False, True)):
        inputs = make_inputs(0)
        graph = HeadTileGraph(inputs, need_h=need_h, need_w=need_w)
        options = dict(need_h=need_h, need_w=need_w)
        control = compare(eager_tile(inputs, **options), graph(inputs))
        original_output = graph(inputs)
        saved = tuple(x.clone() for x in original_output)
        fresh = make_inputs(1)
        freshness = compare(eager_tile(fresh, **options), graph(fresh))
        alias_safe = all(torch.equal(x, y) for x,y in zip(original_output,saved))
        timing = measure(lambda: eager_tile(fresh, **options), lambda: graph(fresh))
        records.append(dict(need_h=need_h, need_w=need_w, control=control, fresh_inputs=freshness,
                            old_outputs_not_aliased=alias_safe, graph_allocated_mib=graph.allocated_bytes/2**20,
                            process_reserved_delta_mib=graph.reserved_bytes/2**20,
                            graph_pool_reserved_mib=graph.pool_reserved_bytes/2**20,
                            static_inputs_mib=graph.static_input_bytes/2**20, graph_accounted_mib=graph.bytes/2**20,
                            timing=timing, passed=alias_safe and all(x['passed'] for x in control+freshness)))
        del inputs, fresh, original_output, saved
        graph.close()
        del graph
        torch.cuda.empty_cache()

result = dict(scope='M4096 V16384 H1024 head backward tile; real checkpoint weights, synthetic activations; copies and output clones included; no full model, DDP, rollout or optimizer',
              torch=torch.__version__, gpu=torch.cuda.get_device_name(), weight=weight_info,
              source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(__file__), Path(__file__).with_name('head_tile_graph.py'))},
              quantization='Original frozen v2 E4 forward/E5 backward rules; FP32 GEMM outputs',
              cases=records, all_passed=all(x['passed'] for x in records))
args.output.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result), flush=True)
raise SystemExit(0 if result['all_passed'] else 1)
