# Sparsity / low-MFU analysis

Saved machine-readable evidence: `sparse_mfu_analysis.json`. CPU-only; no GPU/SSH or runtime/repository edits. Numbers use completed 4+6 beta0 steps4–6 and the existing current-recipe fixed-G32 trace.

## Why GEMM utilization and policy MFU differ

Native FP8 GEMMs execute 315.1306TFLOPs in245.733ms:1282.4TFLOP/s,64.80% of assumed1979TFLOP/s H200 denseFP8 peak. Policy compute MFU14.31% uses useful contractions, excludes padding/recomputation, and divides by host training-step wall on four trainer GPUs. This remains a shape-based MFU estimate. The two percentages have different scopes.

The actual saved trace partitions policy forward/backward into986.200ms of kernels (19,168 kernels). The separate570.379ms localBF16 reference scope is excluded here. It is absent from the beta0 run.

| Exclusive policy category | Kernel ms | Policy kernel share |
|---|---:|---:|
| FP8 GEMM | 245.733 | **24.92%** |
| GDN | 134.501 | 13.64% |
| Elementwise/reduction | 100.041 | 10.14% |
| Quantization | 81.739 | 8.29% |
| FlashAttention | 79.109 | 8.02% |
| Copy/cast/cat | 47.978 | 4.86% |
| Small BF16 GEMM | 5.819 | .59% |
| Fused kernels under parser Unmatched | 291.273 | 29.53% |

“Unmatched” is a naming/classification limitation, not evidence of CPU idle time. Launch owners identify159.978ms fused conv/SiLU (16.22% of policy),81.107ms fused norm (8.22%),39.381ms fusedMLP (3.99%),8.867ms head pointwise (.90%). Listed owners cover99.48% of the unmatched time. Inclusive scopes must not be added to this exclusive table.

FP32 optimizer kernels take5.321ms in a separate optimizer phase in this fixed-G32 trace. This is not evidence that FP32 masterAdam dominates full training. Production callback timing is unsynchronized; actual four-rank DDP/reduction cost needs its own measurement.

## Target and optimistic Amdahl scenarios

Current primary:26,268,362 trained completion tokens /173.50135s =151,401.49token/s =76.78×v1. Compute143.46636s; rollout wait19.56357s; sync.78969s; residual9.68173s. Target100×v1=197,200token/s permits133.20670s for this exact token workload: **save40.29464s (23.22% of whole wall)**.

With other times fixed, training compute must fall28.09% (1.3906× speedup), from47.8221s/step to **34.3906s/step**. With rollout waiting hypothetically eliminated, compute may instead be40.9118s/step (14.45% compute reduction). The earlier32.25s figure is not the correct requirement for these exact latest counts.

Using the saved policy kernel proportions as an optimistic proxy for production compute:

| Hypothesis, zero extra overhead | Projected total token/s | Versusv1 |
|---|---:|---:|
| Weight forward +forward replay GEMMs2× only | 158,237 | 80.24× |
| Every FP8 GEMM2× | 168,790 | **85.59×** |
| Every FP8 GEMM costs zero | 190,691 | 96.70× |
| Eliminate rollout wait only | 170,643 | 86.53× |
| Every FP8 GEMM2× +zero rollout wait | 193,059 | 97.90× |

Even nominal sparse peak3958TFLOP/s for every FP8 contraction (3.086× current measured GEMM throughput, unrealistically broad coverage) projects175,901token/s /89.20× with waiting fixed. Therefore sparseGEMM alone is not sufficient in this transferred-profile scenario. With allGEMMs2× +zero wait, another2.857s/3steps must be saved, before accounting for sparsity overhead. If waiting stays fixed, a2× accelerated component must cover56.17% of compute, versus current FP8 kernel share24.92%.

Same-method computeMFU20% requires compute102.65938s instead of143.46636s (28.44% less;1.3975× speedup). With other time fixed this yields197,961token/s /100.39×v1. Thus MFU20% and100×v1 are approximately the same performance target for this fixed workload.

These are counterfactual planning calculations. Single-G32 kernel sums are not the latest four-rank critical path. Faster training can expose more rollout waiting. Masking, sparse compression, transpose packing, quantization/cache refresh and synchronization are not free; actual savings will be smaller unless another bottleneck also improves.

## Actual shapes and sparsity coverage

The118-row shape ledger contains forward projections with tokenM2560/15799/21240/25454, hidden1024, output widths512/2048/4096/6144/7168, and down projectionsK2048/3584. Head tiles are(M,N,K)=(4096,16384,1024), tailM904, final vocabulary tileN2560. Headdgrad=(4096,1024,16384); headwgrad=(16384,1024,4096).

Executed FP8 work315.1306T versus useful276.0411T:14.16% extra, including32.4193T backward forward replay; bucket padding alone is3.548%. There is188.4228T scaled-mm backward work already in nativeFP8. Scope must distinguish forward/replay, dgrad andwgrad.

A2:4 mask on the weight can accelerate forward only with actual sparse dispatch. Dgrad additionally needs transpose-compatible sparsity; forward row2:4 does not guarantee transpose2:4. Wgrad multiplies gradient and activation tensors, not the sparse weight, so weight pruning does not automatically halve wgrad. Returning a masked gradient after dense wgrad does not save GEMM work. FP32 master/Adam can remain, but mask refresh/compression should be cached per optimizer update and reflected in serving. Pruning changes policy numerics; this analysis makes no dense-policy quality equivalence claim.

Priorities supported by this evidence: measure4rank launch/communication critical path; reduce fused conv/norm/GDN and quantization costs; use sparse kernels only where the real shape/backend achieves savings after compression. Shared masks/scales on trainer+rollout remain necessary when numerical alignment is restored.
