"""Cached cuSPARSELt diagnostic with scalar scale fused before BF16 output."""
import ctypes as ct
import importlib.metadata

import torch


class ScalarSparsePlan:
    def __init__(self, packed, dense, alpha):
        files = importlib.metadata.distribution('nvidia-cusparselt-cu13')
        library = next(files.locate_file(p) for p in files.files if str(p).endswith('libcusparseLt.so.0'))
        self.lib = ct.CDLL(str(library))
        self.buffers = []
        for name in ['handle', 'sparse', 'dense', 'result', 'matmul', 'algorithm', 'plan']:
            storage = ct.create_string_buffer(512+15)
            self.buffers.append(storage)
            setattr(self, name, ct.c_void_p((ct.addressof(storage)+15)//16*16))
        self.check('cusparseLtInit', self.handle)
        rows, inner = dense.shape
        channels = packed.shape[0]
        self.output = torch.empty(rows, channels, device=dense.device, dtype=torch.bfloat16)
        self.packed, self.input = packed, dense
        self.alpha, self.beta = ct.c_float(alpha), ct.c_float(0)
        self.streams = (ct.c_void_p*1)(torch.cuda.current_stream().cuda_stream)
        self.check('cusparseLtStructuredDescriptorInit', self.handle, self.sparse,
                   ct.c_int64(channels), ct.c_int64(inner), ct.c_int64(inner), ct.c_uint32(16),
                   ct.c_int(28), ct.c_int(2), ct.c_int(0))
        self.check('cusparseLtDenseDescriptorInit', self.handle, self.dense,
                   ct.c_int64(rows), ct.c_int64(inner), ct.c_int64(inner), ct.c_uint32(16), ct.c_int(28), ct.c_int(2))
        self.check('cusparseLtDenseDescriptorInit', self.handle, self.result,
                   ct.c_int64(channels), ct.c_int64(rows), ct.c_int64(channels), ct.c_uint32(16), ct.c_int(14), ct.c_int(1))
        self.check('cusparseLtMatmulDescriptorInit', self.handle, self.matmul, ct.c_int(0), ct.c_int(1),
                   self.sparse, self.dense, self.result, self.result, ct.c_int(2))
        self.check('cusparseLtMatmulAlgSelectionInit', self.handle, self.algorithm, self.matmul, ct.c_int(0))
        self.check('cusparseLtMatmulPlanInit', self.handle, self.plan, self.matmul, self.algorithm)
        workspace_bytes = ct.c_size_t()
        self.check('cusparseLtMatmulGetWorkspace', self.handle, self.plan, ct.byref(workspace_bytes))
        self.workspace = torch.empty(max(1, workspace_bytes.value), device=dense.device, dtype=torch.uint8)
        self.run(search=True)
        self.check('cusparseLtMatmulGetWorkspace', self.handle, self.plan, ct.byref(workspace_bytes))
        if workspace_bytes.value > self.workspace.numel():
            self.workspace = torch.empty(workspace_bytes.value, device=dense.device, dtype=torch.uint8)
        self.workspace_bytes = workspace_bytes.value

    def check(self, function, *args):
        status = getattr(self.lib, function)(*args)
        if status:
            error = self.lib.cusparseLtGetErrorString
            error.restype = ct.c_char_p
            raise RuntimeError(function+': '+error(ct.c_int(status)).decode())

    def run(self, search=False):
        self.streams[0] = torch.cuda.current_stream().cuda_stream
        self.check('cusparseLtMatmulSearch' if search else 'cusparseLtMatmul', self.handle, self.plan,
                   ct.byref(self.alpha), ct.c_void_p(self.packed.data_ptr()), ct.c_void_p(self.input.data_ptr()),
                   ct.byref(self.beta), ct.c_void_p(self.output.data_ptr()), ct.c_void_p(self.output.data_ptr()),
                   ct.c_void_p(self.workspace.data_ptr()), self.streams, ct.c_int32(1))
        return self.output

    def close(self):
        self.check('cusparseLtMatmulPlanDestroy', self.plan)
        self.check('cusparseLtMatmulAlgSelectionDestroy', self.algorithm)
        for descriptor in [self.sparse, self.dense, self.result]:
            self.check('cusparseLtMatDescriptorDestroy', descriptor)
        self.check('cusparseLtDestroy', self.handle)
