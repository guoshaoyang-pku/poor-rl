"""Bounded H200 2:4 FP8 probes using v4 shapes and checkpoint weights."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import statistics
import time

import torch
import triton
import triton.language as tl
from safetensors import safe_open

from rlforge.fp8 import forward_mm, quantize_rows


@triton.jit
def scale_result(R, WS, XS, Y, M: tl.constexpr, N: tl.constexpr,
                 R_ROW: tl.constexpr, R_COL: tl.constexpr,
                 W_SCALED: tl.constexpr, BLOCK: tl.constexpr):
    offsets = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    valid = offsets < M * N
    rows, cols = offsets // N, offsets % N
    values = tl.load(R + rows * R_ROW + cols * R_COL, valid, 0).to(tl.float32)
    if W_SCALED:
        values *= tl.load(XS + rows, valid, 0)
    else:
        values *= tl.load(XS + rows, valid, 0) * tl.load(WS + cols, valid, 0)
    tl.store(Y + offsets, values, valid)


def bench(fn, repetitions=12):
    for _ in range(3):
        fn()
    torch.cuda.synchronize()
    values = []
    for _ in range(repetitions):
        start, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
        start.record()
        result = fn()
        end.record()
        end.synchronize()
        values.append(start.elapsed_time(end))
    return dict(median_ms=statistics.median(values), min_ms=min(values), max_ms=max(values))


def graph_bench(fn):
    for _ in range(3):
        fn()
    torch.cuda.synchronize()
    graph = torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph):
        value = fn()
    timing = bench(graph.replay, repetitions=20)
    return dict(timing=timing, capture_supported=True)


def prune(weight):
    blocks = weight.reshape(weight.shape[0], -1, 4)
    indices = blocks.abs().topk(2, dim=-1).indices
    mask = torch.zeros_like(blocks, dtype=torch.bool).scatter_(-1, indices, True)
    return (blocks * mask).reshape_as(weight), mask.reshape_as(weight)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    torch.manual_seed(0)
    model = args.checkpoint / 'model.safetensors'
    output = dict(scope='Single H200 FP8 2:4 kernel feasibility, not whole RL or training-quality evidence',
                  started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  torch=torch.__version__, cuda=torch.version.cuda,
                  gpu=torch.cuda.get_device_name(),
                  script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  source_fp8_sha256=hashlib.sha256(Path(__import__('rlforge.fp8', fromlist=['x']).__file__).read_bytes()).hexdigest(),
                  checkpoint_sha256=hashlib.sha256(model.read_bytes()).hexdigest(),
                  scale_contract='Same rowwise quantized W and X; compare full search configuration, result layouts and vector alpha',
                  search_api_doc=torch._C._cusparselt.mm_search.__doc__,
                  shapes=[], weight_audits=[])
    with safe_open(model, framework='pt', device='cpu') as file:
        specs = [('gate_up', ['model.language_model.layers.0.mlp.gate_proj.weight', 'model.language_model.layers.0.mlp.up_proj.weight'], [32, 2048, 16384]),
                 ('mlp_down', ['model.language_model.layers.0.mlp.down_proj.weight'], [2048, 16384]),
                 ('head_tile', ['model.language_model.embed_tokens.weight'], [2048, 4096])]
        for name, keys, batches in specs:
            tensors = [file.get_tensor(key) for key in keys]
            weight = torch.cat(tensors, dim=0) if len(tensors) > 1 else tensors[0]
            if name == 'head_tile':
                weight = weight[:16384]
            weight = weight.cuda().float().contiguous()
            sparse_weight, mask = prune(weight)
            kept_energy = (sparse_weight.square().sum() / weight.square().sum()).item()
            transposed_counts = mask.t().contiguous().reshape(mask.shape[1], -1, 4).sum(-1)
            output['weight_audits'].append(dict(name=name, shape=list(weight.shape), kept_l2_energy_fraction=kept_energy,
                transpose_fraction_blocks_with_at_most_two_kept=(transposed_counts <= 2).float().mean().item(),
                transpose_fraction_blocks_exactly_two_kept=(transposed_counts == 2).float().mean().item()))
            wq, ws = quantize_rows(sparse_weight)
            original_q, original_s = quantize_rows(weight)
            packed = torch._cslt_compress(wq)
            compression = bench(lambda: torch._cslt_compress(wq))
            pruning = bench(lambda: prune(weight))
            for m in batches:
                x = torch.randn(m, weight.shape[1], device='cuda', dtype=torch.bfloat16)
                xq, xs = quantize_rows(x)
                row = dict(name=name, M=m, N=weight.shape[0], K=weight.shape[1],
                    pruning=pruning, compression=compression,
                    input_kind='Synthetic BF16 activations with actual v4 dimensions; checkpoint weights real',
                    original_dense=bench(lambda: forward_mm(xq, original_q, xs, original_s)),
                    masked_dense=bench(lambda: forward_mm(xq, wq, xs, ws)),
                    quantize_activation=bench(lambda: quantize_rows(x)))
                row['masked_dense_graph'] = graph_bench(lambda: forward_mm(xq, wq, xs, ws))
                row['variants'] = []
                for dtype in [torch.float32, torch.bfloat16]:
                    for transpose in [True, False]:
                        for contiguous_b in [False, True]:
                            vector_alpha = False
                            dense_b = xq.t().contiguous() if contiguous_b else xq.t()
                            variant = dict(dtype=str(dtype), transpose_result=transpose, contiguous_b=contiguous_b)
                            try:
                                alpha = ws.flatten() if vector_alpha else None
                                search_begin = time.monotonic()
                                algo, split_k, split_mode, max_algo = torch._C._cusparselt.mm_search(
                                    packed, dense_b, None, alpha, dtype, transpose)
                                variant.update(search_s=time.monotonic()-search_begin,
                                    algorithm=algo, split_k=split_k, split_k_mode=split_mode, max_algorithm=max_algo)
                                def raw_mm():
                                    return torch._cslt_sparse_mm(packed, dense_b, alpha=alpha, out_dtype=dtype,
                                        transpose_result=transpose, alg_id=algo, split_k=split_k, split_k_mode=split_mode)
                                raw = raw_mm()
                                strides = raw.stride() if transpose else tuple(reversed(raw.stride()))
                                variant.update(raw_shape=list(raw.shape), raw_strides=list(raw.stride()))
                                result = torch.empty(m, weight.shape[0], dtype=torch.bfloat16, device='cuda')
                                def sparse():
                                    raw = raw_mm()
                                    scale_result[(triton.cdiv(m * weight.shape[0], 1024),)](
                                        raw, ws, xs, result, m, weight.shape[0], *strides, vector_alpha, 1024)
                                    return result
                                actual = sparse()
                                reference = forward_mm(xq, wq, xs, ws)
                                delta = actual.float() - reference.float()
                                variant.update(timing=bench(sparse), raw_gemm_graph=graph_bench(raw_mm),
                                    exact_bf16_fraction=(actual == reference).float().mean().item(),
                                    relative_l2_error=(delta.square().sum() / reference.float().square().sum()).sqrt().item(),
                                    max_abs_error=delta.abs().max().item())
                                variant['cuda_graph'] = graph_bench(sparse)
                                variant['speed_vs_masked_dense_graph'] = (row['masked_dense_graph']['timing']['median_ms'] /
                                    variant['cuda_graph']['timing']['median_ms'])
                            except Exception as error:
                                variant['error'] = type(error).__name__+': '+str(error)[:500]
                            row['variants'].append(variant)
                # A separate tensorwise contract tests a fused scalar epilogue.
                # It is not numerically interchangeable with v4 rowwise forward.
                ws_scalar = (sparse_weight.abs().max() / 448).clamp_min(1/(448*512))
                xs_scalar = (x.float().abs().max() / 448).clamp_min(1/(448*512))
                scalar_wq = (sparse_weight / ws_scalar).clamp(-448, 448).to(torch.float8_e4m3fn)
                scalar_xq = (x.float() / xs_scalar).clamp(-448, 448).to(torch.float8_e4m3fn)
                scalar_packed = torch._cslt_compress(scalar_wq)
                scalar_alpha = (ws_scalar * xs_scalar).cpu()
                scalar_reference = forward_mm(scalar_xq, scalar_wq, xs_scalar, ws_scalar)
                scalar_dense = graph_bench(lambda: forward_mm(scalar_xq, scalar_wq, xs_scalar, ws_scalar))
                row['scalar_contract_diagnostic'] = []
                variant = dict(contract='Tensorwise FP8 with cached plan and fused scalar scale; changed quantization diagnostic')
                scalar_plan = None
                try:
                    from sparse_cached_plan import ScalarSparsePlan
                    scalar_plan = ScalarSparsePlan(scalar_packed, scalar_xq, float(scalar_alpha))
                    actual = scalar_plan.run()
                    delta = actual.float()-scalar_reference.float()
                    variant.update(workspace_bytes=scalar_plan.workspace_bytes,
                        dense_graph=scalar_dense,sparse_graph=graph_bench(scalar_plan.run),
                        sparse_eager=bench(scalar_plan.run),
                        relative_l2_error=(delta.square().sum()/scalar_reference.float().square().sum()).sqrt().item(),
                        exact_bf16_fraction=(actual==scalar_reference).float().mean().item())
                    variant['speed'] = scalar_dense['timing']['median_ms']/variant['sparse_graph']['timing']['median_ms']
                    if name=='gate_up' and m==16384:
                        with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,torch.profiler.ProfilerActivity.CUDA]) as profiler:
                            for _ in range(3):
                                scalar_plan.run()
                            torch.cuda.synchronize()
                        variant['gpu_events'] = [dict(name=e.key,count=e.count,device_us=e.self_device_time_total)
                            for e in profiler.key_averages() if e.self_device_time_total>0]
                except Exception as error:
                    variant['error'] = type(error).__name__+': '+str(error)[:500]
                finally:
                    if scalar_plan is not None:
                        scalar_plan.close()
                row['scalar_contract_diagnostic'].append(variant)
                original = forward_mm(xq, original_q, xs, original_s)
                masked = forward_mm(xq, wq, xs, ws)
                row['pruning_output_relative_l2_error'] = ((original.float()-masked.float()).square().sum() / original.float().square().sum()).sqrt().item()
                output['shapes'].append(row)
                args.output.write_text(json.dumps(output, indent=2, allow_nan=False)+'\n')
                print(json.dumps(row), flush=True)
                del x, xq, xs, original, masked
            del weight, sparse_weight, mask, wq, ws, original_q, original_s, packed
            torch.cuda.empty_cache()
    output['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    args.output.write_text(json.dumps(output, indent=2, allow_nan=False)+'\n')


if __name__ == '__main__':
    main()
