"""Retain the matched forward and pack only small norm backward rows."""
import branch_conv_silu_fused_prototype as conv
import fusion_triton_prototype as norm
import packed_norm_prototype as packed


def install_for_benchmark(policy, ref=None):
    restore_conv = conv.install_for_benchmark(policy, ref=ref)
    original_gradient = norm._gradient

    def gradient(x, weight, inv, grad, mode, gate=None, need_weight=True):
        if x.is_cuda and x.shape[-1] <= 256:
            return packed._gradient(x, weight, inv, grad, mode, gate, need_weight)
        return original_gradient(x, weight, inv, grad, mode, gate, need_weight)

    norm._gradient = gradient

    def restore():
        norm._gradient = original_gradient
        restore_conv()

    return restore
