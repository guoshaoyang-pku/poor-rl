"""Preserve frozen reference request bytes while accelerating known ASCII payloads."""
import ast
import hashlib
import inspect
import json
import textwrap

import msgspec
import reference_ahead_v4


_encoder = msgspec.json.Encoder(order="deterministic")
_counts = {"fast": 0, "fallback": 0}
_original = reference_ahead_v4.prepare_compact


def _simple_metadata(value):
    if type(value) is int:
        return -(2**63) <= value < 2**63
    if type(value) is str:
        return value.isascii() and value.isalnum()
    if type(value) is list:
        return all(_simple_metadata(item) for item in value)
    if type(value) is dict:
        return all(type(key) is str and key.isascii() and
                   _simple_metadata(item) for key, item in value.items())
    return False


def canonical_bytes(body):
    if (body["temperature"] == 1.0 and
            all(type(body[key]) is str and body[key].isascii() and
                body[key].isalnum() for key in ("reference_sha256", "source_sha256"))
            and _simple_metadata(body["subbatch"])):
        try:
            encoded = _encoder.encode(body)
        except (TypeError, ValueError, OverflowError):
            pass
        else:
            _counts["fast"] += 1
            return encoded
    _counts["fallback"] += 1
    return json.dumps(body, sort_keys=True, separators=(",", ":")).encode()


def install():
    if reference_ahead_v4.prepare_compact is not _original:
        raise RuntimeError("Reference payload encoder already patched")
    source = textwrap.dedent(inspect.getsource(_original))
    tree = ast.parse(source)
    matches = [node for node in ast.walk(tree) if isinstance(node, ast.Assign) and
               len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and
               node.targets[0].id == "canonical"]
    if len(matches) != 1 or ast.unparse(matches[0].value) != (
            "json.dumps(body, sort_keys=True, separators=(',', ':')).encode()"):
        raise ValueError("Frozen reference canonical encoding changed")
    matches[0].value = ast.parse("canonical_bytes(body)", mode="eval").body
    ast.fix_missing_locations(tree)
    namespace = dict(_original.__globals__, canonical_bytes=canonical_bytes)
    exec(compile(tree, __file__, "exec"), namespace)
    patched = namespace[_original.__name__]
    reference_ahead_v4.prepare_compact = patched

    def restore():
        reference_ahead_v4.prepare_compact = _original

    return restore


def stats():
    return dict(_counts, original_source_sha256=hashlib.sha256(
        inspect.getsource(_original).encode()).hexdigest())
