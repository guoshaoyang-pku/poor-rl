"""Bounded host critical-path timings around unchanged native engine calls."""
import functools
import hashlib
import inspect
import os
import time

STATE = None
INSTALLED = False
NATIVE_GET_OUTPUT_SHA256 = '9d124e34b69a82109eb70285b81cb6bef30fabfe084e9ddd7b517e8dadedf58f'


def snapshot():
    return {'scope': 'Normal host wall diagnostic, inclusive intervals overlap GPU and each other; no synchronization or math changes',
            'pid': os.getpid(), 'state': STATE}


def arm(engine, calls=64):
    global STATE
    calls = int(calls)
    if not 1 <= calls <= 256:
        raise ValueError('Bounded 1-256 real engine iterations required')
    if STATE is not None and not STATE['complete']:
        raise RuntimeError('Existing host timing window still active')
    if not engine.scheduler.running:
        raise RuntimeError('Real active requests required')
    state = {'complete': False, 'limit': calls, 'calls': 0, 'rows': [],
             'events': [], 't0_ns': time.perf_counter_ns()}
    STATE = state
    originals = []

    def record(owner, name, label):
        native = getattr(owner, name)
        originals.append((owner, name, native))

        @functools.wraps(native)
        def timed(*args, **kwargs):
            begin = time.perf_counter_ns()
            try:
                return native(*args, **kwargs)
            finally:
                state['events'].append({'stage': label, 'begin_ms': (begin-state['t0_ns'])/1e6,
                                        'end_ms': (time.perf_counter_ns()-state['t0_ns'])/1e6})
        setattr(owner, name, timed)

    for owner, name, label in [
        (engine.scheduler, 'schedule', 'schedule'),
        (engine.scheduler, 'update_from_output', 'update_from_output'),
        (engine.model_executor, 'execute_model', 'execute_model_dispatch'),
        (engine.model_executor, 'sample_tokens', 'sample_tokens_dispatch'),
        (engine, '_process_input_queue', 'input_queue'),
        (engine, 'post_step', 'post_step'),
    ]:
        record(owner, name, label)
    original_step = engine.step_fn

    @functools.wraps(original_step)
    def step():
        begin = time.perf_counter_ns()
        running = len(engine.scheduler.running)
        queue = getattr(engine, 'batch_queue', None)
        try:
            return original_step()
        finally:
            end = time.perf_counter_ns()
            state['rows'].append({'begin_ms': (begin-state['t0_ns'])/1e6,
                                  'end_ms': (end-state['t0_ns'])/1e6,
                                  'running': running, 'queued_batches': 0 if queue is None else len(queue)})
            state['calls'] += 1
            if state['calls'] == calls:
                engine.step_fn = original_step
                for owner, name, native in originals:
                    setattr(owner, name, native)
                state['complete'] = True
    engine.step_fn = step
    return snapshot()


def install():
    global INSTALLED
    if INSTALLED:
        return
    from vllm.v1.engine.core import EngineCore
    from vllm.v1.worker.gpu.async_utils import AsyncOutput
    native_get = AsyncOutput.get_output
    assert hashlib.sha256(inspect.getsource(native_get).encode()).hexdigest() == NATIVE_GET_OUTPUT_SHA256
    native_rpc = EngineCore.collective_rpc

    @functools.wraps(native_get)
    def get_output(self):
        state = STATE
        if state is None or state['complete']:
            return native_get(self)
        begin = time.perf_counter_ns()
        try:
            return native_get(self)
        finally:
            state['events'].append({'stage': 'async_output_wait_and_materialize',
                                    'begin_ms': (begin-state['t0_ns'])/1e6,
                                    'end_ms': (time.perf_counter_ns()-state['t0_ns'])/1e6})

    @functools.wraps(native_rpc)
    def collective_rpc(self, method, timeout=None, args=(), kwargs=None):
        if method == 'sprint_host_timeline_arm':
            return [arm(self, args[0] if args else 64)]
        if method == 'sprint_host_timeline_stats':
            return [snapshot()]
        return native_rpc(self, method, timeout, args, kwargs)

    AsyncOutput.get_output = get_output
    EngineCore.collective_rpc = collective_rpc
    INSTALLED = True
