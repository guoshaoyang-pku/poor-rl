"""Native FP8 serving with one private control API client and frozen observers."""
import serving_dedicated_control as dedicated

dedicated.install()
import serve_control_observed_entry

if __name__ == '__main__':
    serve_control_observed_entry.serve_pause_observed_entry.serve_kv_bandwidth_entry.serve_kv_observed_entry.serve_driver.main()
