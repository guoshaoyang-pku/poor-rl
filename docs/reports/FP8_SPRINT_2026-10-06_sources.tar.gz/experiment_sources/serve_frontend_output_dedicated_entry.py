"""Exact full completion CPU frontend on the isolated per-request serving recipe."""
import serve_output_request_dedicated_entry
import serving_completion_json_v2_prototype as encoding
import serving_flat_logprobs_prototype as completion_logprobs

encoding.install()
encoding.toggle(True)
completion_logprobs.install()
completion_logprobs.toggle(True)

if __name__ == "__main__":
    import serve_cpu_dedicated_entry
    serve_cpu_dedicated_entry.serve_dedicated_control_entry.serve_control_observed_entry.serve_pause_observed_entry.serve_kv_bandwidth_entry.serve_kv_observed_entry.serve_driver.main()
