"""Isolated stride-aware Triton RMS/gated RMS/QK norm candidate.

Uses the frozen fusion_prototype for GDN gate preparation and SwiGLU. Norm
weight gradients remain FP32 without the previous final BF16 rounding.
Forward reductions and scalar math can round differently from the canonical
trainer. GPU timing and whole-model/decode gates must establish actual benefit.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from types import MethodType

import torch
import fusion_prototype as base

try:
    import triton
    import triton.language as tl
except ImportError:
    triton = tl = None


if triton is not None:
    @triton.jit
    def _row_offset(row, N1, N2, S0, S1, S2):
        return (row // (N1 * N2)) * S0 + ((row // N2) % N1) * S1 + (row % N2) * S2

    @triton.jit
    def _norm_fwd(X, Z, W, Y, Inv, N1, N2,
                  XS0, XS1, XS2, XSC, ZS0, ZS1, ZS2, ZSC,
                  C: tl.constexpr, EPS: tl.constexpr, MODE: tl.constexpr,
                  BLOCK: tl.constexpr):
        row = tl.program_id(0)
        col = tl.arange(0, BLOCK)
        xoff = _row_offset(row, N1, N2, XS0, XS1, XS2)
        x = tl.load(X + xoff + col * XSC, col < C, other=0).to(tl.float32)
        var = tl.sum(x * x, 0)
        if MODE != 0:
            var = var / C
        inv = tl.rsqrt(var + EPS)
        y = x * inv
        if MODE != 0:
            w = tl.load(W + col, col < C, other=0).to(X.dtype.element_ty).to(tl.float32)
            if MODE == 1:
                w = 1.0 + w
            y = y * w
        if MODE == 2:
            zoff = _row_offset(row, N1, N2, ZS0, ZS1, ZS2)
            z = tl.load(Z + zoff + col * ZSC, col < C, other=0).to(tl.float32)
            y = y * z * tl.sigmoid(z)
        tl.store(Y + row * C + col, y, col < C)
        tl.store(Inv + row, inv)

    @triton.jit
    def _norm_bwd(X, Z, W, Inv, DY, DX, DZ, N1, N2,
                  XS0, XS1, XS2, XSC, ZS0, ZS1, ZS2, ZSC,
                  DS0, DS1, DS2, DSC, C: tl.constexpr, MODE: tl.constexpr,
                  BLOCK: tl.constexpr):
        row = tl.program_id(0)
        col = tl.arange(0, BLOCK)
        xoff = _row_offset(row, N1, N2, XS0, XS1, XS2)
        doff = _row_offset(row, N1, N2, DS0, DS1, DS2)
        x = tl.load(X + xoff + col * XSC, col < C, other=0).to(tl.float32)
        dy = tl.load(DY + doff + col * DSC, col < C, other=0).to(tl.float32)
        inv = tl.load(Inv + row)
        gn = dy
        if MODE != 0:
            w = tl.load(W + col, col < C, other=0).to(X.dtype.element_ty).to(tl.float32)
            if MODE == 1:
                w = 1.0 + w
            gn = gn * w
        if MODE == 2:
            zoff = _row_offset(row, N1, N2, ZS0, ZS1, ZS2)
            z = tl.load(Z + zoff + col * ZSC, col < C, other=0).to(tl.float32)
            sigmoid = tl.sigmoid(z)
            gn = gn * z * sigmoid
            dz = dy * x * inv * w * sigmoid * (1.0 + z * (1.0 - sigmoid))
            tl.store(DZ + row * C + col, dz, col < C)
        projection = tl.sum(gn * x, 0)
        if MODE != 0:
            projection = projection / C
        dx = inv * (gn - x * inv * inv * projection)
        tl.store(DX + row * C + col, dx, col < C)

    @triton.jit
    def _norm_dw(X, Z, Inv, DY, Partial, Rows, N1, N2,
                 XS0, XS1, XS2, XSC, ZS0, ZS1, ZS2, ZSC,
                 DS0, DS1, DS2, DSC, C: tl.constexpr, GATED: tl.constexpr,
                 RB: tl.constexpr, CB: tl.constexpr):
        group = tl.program_id(0)
        rows = group * RB + tl.arange(0, RB)
        cols = tl.program_id(1) * CB + tl.arange(0, CB)
        xoff = _row_offset(rows, N1, N2, XS0, XS1, XS2)
        doff = _row_offset(rows, N1, N2, DS0, DS1, DS2)
        valid = (rows[:, None] < Rows) & (cols[None, :] < C)
        x = tl.load(X + xoff[:, None] + cols[None, :] * XSC, valid, other=0).to(tl.float32)
        dy = tl.load(DY + doff[:, None] + cols[None, :] * DSC, valid, other=0).to(tl.float32)
        inv = tl.load(Inv + rows, rows < Rows, other=0)
        value = dy * x * inv[:, None]
        if GATED:
            zoff = _row_offset(rows, N1, N2, ZS0, ZS1, ZS2)
            z = tl.load(Z + zoff[:, None] + cols[None, :] * ZSC, valid, other=0).to(tl.float32)
            value = value * z * tl.sigmoid(z)
        partial = tl.sum(value, 0)
        tl.store(Partial + group * C + cols, partial, cols < C)


def _layout(x):
    if not 2 <= x.ndim <= 4:
        raise ValueError(f"norm requires rank 2..4, got {x.ndim}")
    leading = (1,) * (4 - x.ndim) + tuple(x.shape[:-1])
    strides = (0,) * (4 - x.ndim) + tuple(x.stride()[:-1])
    return leading, (*strides, x.stride(-1))


def _value(x, weight, eps, mode, gate=None):
    if not x.is_cuda:
        if mode == 0:
            inv = torch.rsqrt(x.float().square().sum(-1, keepdim=True) + eps)
            return (x.float() * inv).to(x.dtype), inv
        if mode == 1:
            return base._rms_fwd(x, weight, eps)
        return base._gated_fwd(x, gate, weight, eps)
    if triton is None:
        raise RuntimeError("CUDA norm candidate requires the existing Triton runtime")
    dims, xs = _layout(x)
    zs = _layout(gate)[1] if gate is not None else (0, 0, 0, 0)
    rows, width = x.numel() // x.shape[-1], x.shape[-1]
    out = torch.empty(x.shape, dtype=x.dtype, device=x.device)
    inv = torch.empty(rows, dtype=torch.float32, device=x.device)
    block = triton.next_power_of_2(width)
    _norm_fwd[(rows,)](x, gate if gate is not None else x, weight if weight is not None else x,
                        out, inv, dims[1], dims[2], *xs, *zs, C=width, EPS=eps, MODE=mode,
                        BLOCK=block, num_warps=4 if block <= 2048 else 8, enable_fp_fusion=True)
    return out, inv


def _gradient(x, weight, inv, grad, mode, gate=None, need_weight=True):
    if not x.is_cuda:
        if mode == 0:
            return base._l2_bwd(x, inv, grad), None, None
        if mode == 1:
            dx, dw = base._rms_bwd(x, weight, inv, grad)
            dw = (grad.float() * x.float() * inv).sum(tuple(range(x.ndim - 1))).to(weight.dtype)
            return dx, None, dw
        dx, dz, _ = base._gated_bwd(x, gate, weight, inv, grad)
        dw = (grad.float() * x.float() * inv * torch.nn.functional.silu(gate.float())).sum(tuple(range(x.ndim - 1)))
        return dx, dz, dw.to(weight.dtype)
    dims, xs = _layout(x)
    zs = _layout(gate)[1] if gate is not None else (0, 0, 0, 0)
    ds = _layout(grad)[1]
    rows, width = x.numel() // x.shape[-1], x.shape[-1]
    dx = torch.empty(x.shape, dtype=x.dtype, device=x.device)
    dz = torch.empty(gate.shape, dtype=gate.dtype, device=gate.device) if gate is not None else None
    block = triton.next_power_of_2(width)
    _norm_bwd[(rows,)](x, gate if gate is not None else x, weight if weight is not None else x,
                        inv, grad, dx, dz if dz is not None else dx, dims[1], dims[2], *xs, *zs, *ds,
                        C=width, MODE=mode, BLOCK=block, num_warps=4 if block <= 2048 else 8)
    dw = None
    if mode != 0 and need_weight:
        row_block, col_block = 128, 32
        groups = triton.cdiv(rows, row_block)
        partial = torch.empty((groups, width), dtype=torch.float32, device=x.device)
        _norm_dw[(groups, triton.cdiv(width, col_block))](
            x, gate if gate is not None else x, inv, grad, partial, rows, dims[1], dims[2],
            *xs, *zs, *ds, C=width, GATED=mode == 2, RB=row_block, CB=col_block, num_warps=8)
        dw = partial.sum(0).to(weight.dtype)
    return dx, dz, dw


class _Norm(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, weight, gate, eps, mode):
        ctx.set_materialize_grads(False)
        out, inv = _value(x, weight, eps, mode, gate)
        ctx.mode = mode
        ctx.save_for_backward(x, weight, gate, inv)
        return out

    @staticmethod
    def backward(ctx, grad):
        if grad is None:
            return None, None, None, None, None
        x, weight, gate, inv = ctx.saved_tensors
        dx, dz, dw = _gradient(x, weight, inv, grad, ctx.mode, gate, ctx.needs_input_grad[1])
        return (dx if ctx.needs_input_grad[0] else None, dw if ctx.needs_input_grad[1] else None,
                dz if ctx.needs_input_grad[2] else None, None, None)


def _prepare(q, k, b, a, a_log, dt_bias):
    q = _Norm.apply(q, None, None, 1e-6, 0)
    k = _Norm.apply(k, None, None, 1e-6, 0)
    beta, gate = base._call("beta_gate", base._beta_gate, b, a, a_log, dt_bias)
    return q, k, beta, gate


def _rms_forward(self, x):
    return _Norm.apply(x, self.weight, None, self.eps, 1)


def _gated_forward(self, x, gate):
    return _Norm.apply(x, self.weight, gate, self.variance_epsilon, 2)


def install_for_benchmark(policy, ref=None):
    from transformers.models.qwen3_5 import modeling_qwen3_5 as mq
    from rlforge import fp8_alignment as alignment

    restore_base = base.install_for_benchmark(policy, ref=ref)
    for module in policy.modules():
        if isinstance(module, mq.Qwen3_5RMSNorm):
            module.forward = MethodType(_rms_forward, module)
        elif isinstance(module, mq.Qwen3_5RMSNormGated):
            module.forward = MethodType(_gated_forward, module)
    alignment._gdn_prepare = _prepare
    return restore_base


def gate(device):
    torch.manual_seed(19)
    rows = []
    for dtype in (torch.float32, torch.bfloat16):
        for mode in (0, 1, 2):
            for layout in ("contiguous", "sliced", "transposed"):
                source = torch.randn(2, 7, 3, 34, device=device, dtype=dtype)
                x = source[..., :17] if layout == "sliced" else source[..., :17].clone().contiguous()
                if layout == "transposed":
                    x = x.transpose(1, 2)
                x = x.detach().requires_grad_()
                z = torch.randn_like(source)[..., 1:18]
                if layout == "transposed":
                    z = z.transpose(1, 2)
                z = z.detach().requires_grad_()
                w = torch.randn(17, device=device, dtype=torch.float32).requires_grad_()
                if mode == 0:
                    y = _Norm.apply(x, None, None, 1e-6, mode)
                    expected = (x.float() * torch.rsqrt(x.float().square().sum(-1, keepdim=True) + 1e-6)).to(dtype)
                    params = x,
                elif mode == 1:
                    y = _Norm.apply(x, w, None, 1e-6, mode)
                    expected = base._rms_fwd(x, w, 1e-6)[0]
                    params = x, w
                else:
                    y = _Norm.apply(x, w, z, 1e-6, mode)
                    expected = base._gated_fwd(x, z, w, 1e-6)[0]
                    params = x, w, z
                upstream = torch.randn_like(y)
                actual = torch.autograd.grad(y, params, upstream, retain_graph=True)
                reference = torch.autograd.grad(expected, params, upstream)
                tolerance = (3e-5, 3e-5) if dtype == torch.float32 else (0.025, 0.035)
                torch.testing.assert_close(y, expected, rtol=tolerance[0], atol=tolerance[1])
                for index, (value, baseline) in enumerate(zip(actual, reference)):
                    if index == 1 and mode != 0:
                        _, inv = _value(x.detach(), w.detach(), 1e-6, mode, z.detach() if mode == 2 else None)
                        if device.type == "cuda":
                            inv = inv.reshape(*x.shape[:-1], 1)
                        baseline = (upstream.float() * x.float() * inv)
                        if mode == 2:
                            baseline = baseline * torch.nn.functional.silu(z.float())
                        baseline = baseline.sum(tuple(range(x.ndim - 1)))
                    torch.testing.assert_close(value, baseline, rtol=tolerance[0], atol=tolerance[1])
                    assert bool(torch.isfinite(value).all())
                rows.append({"mode": mode, "dtype": str(dtype), "layout": layout,
                             "forward_close": True, "gradient_close": True,
                             "parameter_gradient_fp32": mode == 0 or actual[1].dtype == torch.float32})
    return {"scope": "norm primitive analytic/stride gates; changed rounding allowed",
            "device": str(device), "rows": rows, "gpu_tested": device.type == "cuda",
            "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "base_sha256": hashlib.sha256(Path(base.__file__).read_bytes()).hexdigest()}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--cpu-gate", action="store_true")
    parser.add_argument("--gpu-gate", action="store_true")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    torch.set_num_threads(1)
    result = gate(torch.device("cuda" if args.gpu_gate else "cpu"))
    Path(args.output).write_text(json.dumps(result, indent=2))
    print(json.dumps({"gates": len(result["rows"]), "gpu_tested": result["gpu_tested"],
                      "source_sha256": result["source_sha256"]}), flush=True)
