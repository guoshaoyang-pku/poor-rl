"""Exact-token BF16 reference client and process-local subbatch trainer patch."""
from __future__ import annotations

import ast
import hashlib
import inspect
import json
import math
import textwrap
import threading
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from types import MethodType


SCHEMA = "rlforge-bf16-reference-v1"
MAX_BODY = 64 * 2**20


def request_hash(body):
    fields = {k: v for k, v in body.items() if k != "request_sha256"}
    return hashlib.sha256(json.dumps(fields, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def validate_payload(body):
    if body.get("schema") != SCHEMA or body.get("precision") != "BF16":
        raise ValueError("Only the frozen BF16 reference contract is supported")
    if body.get("request_sha256") != request_hash(body):
        raise ValueError("Reference request fingerprint mismatch")
    if not isinstance(body.get("temperature"), (int, float)) or not math.isfinite(body["temperature"]) or body["temperature"] <= 0:
        raise ValueError("Reference temperature must be finite and positive")
    if not body.get("reference_sha256") or not body.get("source_sha256"):
        raise ValueError("Reference and source fingerprints are required")
    ids, mask, sb = body["input_ids"], body["completion_mask"], body["subbatch"]
    if len(ids) != len(mask) or not ids or any(m not in (0, 1) for m in mask):
        raise ValueError("Token IDs and binary completion mask must have equal positive length")
    if any(not isinstance(t, int) or t < 0 for t in ids):
        raise ValueError("Token IDs must be nonnegative integers")
    prefix, first = int(sb["P"]), int(sb["a0"])
    if prefix < 0 or first < 0 or first + prefix >= len(ids):
        raise ValueError("Invalid shared-prefix range")
    slots = []
    for bucket in sb["buckets"]:
        if not bucket:
            raise ValueError("Empty branch bucket")
        maximum_length = bucket[0][1] - bucket[0][0] - prefix
        for a, e in bucket:
            if not 0 <= a <= a + prefix < e <= len(ids):
                raise ValueError("Invalid segment range")
            if prefix and ids[a:a + prefix] != ids[first:first + prefix]:
                raise ValueError("Branches do not share the declared prompt prefix")
            if e - a - prefix > maximum_length:
                raise ValueError("Bucket first branch is not the padded maximum")
            slots.extend(t - 1 for t in range(a + prefix + 1, e) if mask[t])
    if len(slots) != len(set(slots)) or not slots:
        raise ValueError("Reference must score distinct completion slots")
    if body.get("expected_slots") != slots:
        raise ValueError("Completion-slot order mismatch")
    actual_padded = prefix + sum(len(bucket) * (bucket[0][1] - bucket[0][0] - prefix) for bucket in sb["buckets"])
    if sb.get("tokens") != actual_padded:
        raise ValueError("Subbatch padded-token declaration mismatch")
    return slots


def build_payload(ids, mask, sb, reference_sha256, source_sha256, temperature):
    body = {"schema": SCHEMA, "precision": "BF16", "reference_sha256": reference_sha256,
            "source_sha256": source_sha256, "temperature": float(temperature),
            "input_ids": ids, "completion_mask": mask, "subbatch": sb, "expected_slots": []}
    for bucket in sb["buckets"]:
        for a, e in bucket:
            body["expected_slots"].extend(t - 1 for t in range(a + sb["P"] + 1, e) if mask[t])
    body["request_sha256"] = request_hash(body)
    validate_payload(body)
    return body


class ReferenceClient:
    def __init__(self, endpoints, *, reference_sha256, source_sha256, temperature=1.0, timeout=300):
        self.endpoints = [s.rstrip("/") for s in endpoints]
        if not self.endpoints:
            raise ValueError("At least one reference endpoint is required")
        self.reference_sha256 = reference_sha256
        self.source_sha256 = source_sha256
        self.temperature = float(temperature)
        self.timeout = timeout
        self.executor = ThreadPoolExecutor(max_workers=len(endpoints) * 2)
        self.pending = {}
        self.lock = threading.Lock()
        self.next_endpoint = 0
        self.active_identity = None
        self.active_tensors = None
        self.failure = None
        self.closed = False
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        self.stats = {"requests": 0, "completion_tokens": 0, "worker_compute_ms": 0.0,
                      "network_roundtrip_s": 0.0, "trainer_wait_s": 0.0}
        for endpoint in self.endpoints:
            with self.opener.open(endpoint + "/health", timeout=timeout) as response:
                health = json.load(response)
            for key, expected in [("schema", SCHEMA), ("precision", "BF16"),
                                  ("reference_sha256", reference_sha256), ("source_sha256", source_sha256),
                                  ("temperature", self.temperature)]:
                if health.get(key) != expected:
                    raise ValueError("Reference health contract mismatch: " + key)

    def _send(self, endpoint, body):
        start = time.perf_counter()
        data = json.dumps(body, separators=(",", ":")).encode()
        request = urllib.request.Request(endpoint + "/score", data=data,
                                         headers={"Content-Type": "application/json"}, method="POST")
        with self.opener.open(request, timeout=self.timeout) as response:
            result = json.load(response)
        for key in ["schema", "precision", "request_sha256", "reference_sha256", "source_sha256", "temperature"]:
            if result.get(key) != body[key]:
                raise ValueError("Reference response contract mismatch: " + key)
        if result.get("slots") != body["expected_slots"] or len(result["log_probs"]) != len(result["slots"]):
            raise ValueError("Reference returned incomplete or reordered completion scores")
        if not all(math.isfinite(value) for value in result["log_probs"]):
            raise ValueError("Nonfinite frozen reference logprob")
        with self.lock:
            self.stats["requests"] += 1
            self.stats["completion_tokens"] += len(result["slots"])
            self.stats["worker_compute_ms"] += result["compute_ms"]
            self.stats["network_roundtrip_s"] += time.perf_counter() - start
        return result

    def prefetch(self, input_ids, completion_mask, plan):
        ids = input_ids.detach().cpu()[0].tolist()
        mask = completion_mask.detach().cpu()[0].tolist()
        self.prefetch_lists(ids, mask, plan)
        self.active_identity = tuple((tensor.data_ptr(), tensor._version, tuple(tensor.shape), str(tensor.device))
                                     for tensor in [input_ids, completion_mask])
        self.active_tensors = (input_ids, completion_mask)

    def prefetch_lists(self, ids, mask, plan):
        bodies = [build_payload(ids, mask, sb, self.reference_sha256, self.source_sha256, self.temperature) for sb in plan]
        all_slots = [slot for body in bodies for slot in body["expected_slots"]]
        expected = [t - 1 for t in range(1, len(mask)) if mask[t]]
        if sorted(all_slots) != expected:
            raise ValueError("Prefetch plan does not score every new completion exactly once")
        if len({json.dumps(sb, sort_keys=True) for sb in plan}) != len(plan):
            raise ValueError("Duplicate reference subbatch plan")
        with self.lock:
            if self.failure is not None or self.closed:
                raise RuntimeError("Reference client failed or closed") from self.failure
            if self.pending:
                raise RuntimeError("Previous reference microbatch has unconsumed subbatches")
            for sb, body in zip(plan, bodies):
                key = json.dumps(sb, sort_keys=True)
                endpoint = self.endpoints[self.next_endpoint % len(self.endpoints)]
                self.next_endpoint += 1
                self.pending[key] = (body, self.executor.submit(self._send, endpoint, body))

    def __call__(self, *, prefix_share):
        import torch

        key = json.dumps(prefix_share["subbatch"], sort_keys=True)
        current_identity = tuple((tensor.data_ptr(), tensor._version, tuple(tensor.shape), str(tensor.device))
                                 for tensor in [prefix_share["input_ids"], prefix_share["completion_mask"]])
        if current_identity != self.active_identity:
            error = ValueError("Trainer reference call token/mask tensor changed after prefetch")
            self.cancel(error)
            raise error
        with self.lock:
            body, future = self.pending.pop(key)
        start = time.perf_counter()
        try:
            result = future.result(timeout=self.timeout)
        except BaseException as error:
            self.cancel(error)
            raise RuntimeError("Frozen reference scoring failed; policy update must stop") from error
        self.stats["trainer_wait_s"] += time.perf_counter() - start
        values = torch.tensor(result["log_probs"], device=prefix_share["input_ids"].device, dtype=torch.float32)
        if not bool(torch.isfinite(values).all()):
            raise ValueError("Nonfinite frozen reference logprob")
        return {"log_probs": values, "request_sha256": body["request_sha256"]}

    def finish(self):
        if self.pending:
            raise RuntimeError("Some new completions have not consumed reference scores")
        self.active_identity = None
        self.active_tensors = None

    def cancel(self, error):
        with self.lock:
            self.failure = error
            pending = [future for _body, future in self.pending.values()]
            self.pending.clear()
            self.active_identity = None
            self.active_tensors = None
        for future in pending:
            future.cancel()

    def close(self):
        self.closed = True
        self.executor.shutdown(wait=self.failure is None, cancel_futures=True)


def patched_subbatch_function(original):
    """Preserve the canonical loss AST and move reference retrieval behind policy forward."""
    source = textwrap.dedent(inspect.getsource(original))
    tree = ast.parse(source)
    function = tree.body[0]
    function.name = "_reference_prefetched_subbatch"
    changed_plan = changed_reference = 0
    for index, node in enumerate(function.body):
        if (isinstance(node, ast.Assign) and len(node.targets) == 1
                and isinstance(node.targets[0], ast.Name) and node.targets[0].id == "plan"):
            prefetch = ast.parse("self._ref_model.prefetch(input_ids, completion_mask, plan)").body[0]
            function.body.insert(index + 1, prefetch)
            changed_plan += 1
            break
    for node in function.body:
        if not isinstance(node, ast.For) or not isinstance(node.iter, ast.Call):
            continue
        ref_index = out_index = None
        for index, child in enumerate(node.body):
            if isinstance(child, ast.If) and ast.unparse(child.test) == "self._ref_model is not None":
                ref_index = index
            if (isinstance(child, ast.Assign) and len(child.targets) == 1
                    and isinstance(child.targets[0], ast.Name) and child.targets[0].id == "out"):
                out_index = index
        if ref_index is not None and out_index is not None:
            if ref_index >= out_index:
                raise ValueError("Canonical reference placement changed")
            reference = node.body.pop(ref_index)
            node.body.insert(out_index, reference)
            changed_reference += 1
    if changed_plan != 1 or changed_reference != 1:
        raise ValueError("Unexpected canonical trainer AST; no patch applied")
    ast.fix_missing_locations(tree)
    namespace = dict(original.__globals__)
    exec(compile(tree, "<reference_prefetch canonical loss AST>", "exec"), namespace)
    return namespace[function.name], hashlib.sha256(source.encode()).hexdigest()


def install_for_trainer(trainer, client, *, offload_local_reference=True):
    if not trainer._sb_tokens or not trainer._prefix_share or abs(trainer._kl_beta - 0.05) > 1e-12:
        raise ValueError("Prototype requires subbatched prefix-share GSPO and unchanged KL beta=.05")
    original_ref = trainer._ref_model
    original_method = trainer._compute_loss_subbatched
    patched, canonical_source_sha = patched_subbatch_function(original_method.__func__)
    reference_device = None
    if offload_local_reference and original_ref is not None and hasattr(original_ref, "to"):
        reference_device = original_ref.device
        original_ref.to("cpu")
    trainer._ref_model = client

    def run(self, model, inputs):
        try:
            result = patched(self, model, inputs)
            client.finish()
            return result
        except BaseException as error:
            client.cancel(error)
            raise

    trainer._compute_loss_subbatched = MethodType(run, trainer)
    trainer._reference_prefetch_source_sha256 = canonical_source_sha

    def restore(*, return_reference_to_gpu=True):
        if reference_device is not None and return_reference_to_gpu:
            original_ref.to(reference_device)
        trainer._ref_model = original_ref
        trainer._compute_loss_subbatched = original_method

    return restore
