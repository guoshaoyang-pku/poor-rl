"""Process-only no-op KV bookkeeping fast path for non-speculative decode."""
import os

_INSTALLED = False
_ENABLED = True
_COUNTS = {'allocate_fast': 0, 'allocate_fallback': 0,
           'cache_fast': 0, 'cache_fallback': 0}


def install():
    global _INSTALLED
    if _INSTALLED:
        return
    from vllm.v1.core.kv_cache_coordinator import HybridKVCacheCoordinator
    from vllm.v1.core.kv_cache_manager import KVCacheManager
    from vllm.v1.core.single_type_kv_cache_manager import (
        FullAttentionManager, MambaManager)
    from vllm.v1.kv_cache_interface import FullAttentionSpec
    from vllm.v1.request import RequestStatus

    original_allocate = KVCacheManager.allocate_slots
    original_cache = HybridKVCacheCoordinator.cache_blocks

    def cache_is_noop(coordinator, request, tokens):
        if request.num_computed_tokens < request.num_prompt_tokens:
            return False
        if coordinator.eagle_group_ids:
            return False
        aligned = (tokens if coordinator.enable_partial_hash_hits else
                   tokens // coordinator.scheduler_block_size * coordinator.scheduler_block_size)
        rid = request.request_id
        for manager in coordinator.single_type_managers:
            if not manager.enable_caching:
                continue
            if manager.use_eagle or manager.num_cached_block.get(rid, 0) < aligned // manager.block_size:
                return False
            if type(manager) is FullAttentionManager:
                if type(manager.kv_cache_spec) is not FullAttentionSpec:
                    return False
                # A larger attention block may need repeated partial-tail registration.
                if manager.block_size != manager.block_pool.hash_block_size:
                    return False
            elif type(manager) is MambaManager:
                if manager.mamba_cache_mode != 'align' or rid in manager._checkpoints:
                    return False
                prompt_boundary = request.num_prompt_tokens // manager.block_pool.hash_block_size * manager.block_pool.hash_block_size
                if aligned == prompt_boundary and aligned % manager.block_size:
                    return False
            else:
                return False
        return True

    def cache(self, request, num_computed_tokens):
        if _ENABLED and cache_is_noop(self, request, num_computed_tokens):
            _COUNTS['cache_fast'] += 1
            return
        _COUNTS['cache_fallback'] += 1
        return original_cache(self, request, num_computed_tokens)

    def allocate(self, request, num_new_tokens, num_new_computed_tokens=0,
                 new_computed_blocks=None, num_lookahead_tokens=0,
                 num_external_computed_tokens=0, delay_cache_blocks=False,
                 num_encoder_tokens=0, full_sequence_must_fit=False,
                 reserved_blocks=0, has_scheduled_reqs=True):
        coordinator = self.coordinator
        supported = (_ENABLED and type(coordinator) is HybridKVCacheCoordinator
                     and request.status == RequestStatus.RUNNING
                     and num_new_tokens == 1 and not num_new_computed_tokens
                     and new_computed_blocks is None and not num_lookahead_tokens
                     and not num_external_computed_tokens and not delay_cache_blocks
                     and not num_encoder_tokens and not full_sequence_must_fit
                     and not reserved_blocks
                     and request.num_computed_tokens >= request.num_prompt_tokens
                     and request.num_computed_tokens + 1 <= self.max_model_len
                     and not coordinator.eagle_group_ids)
        if supported:
            rid = request.request_id
            t = request.num_computed_tokens
            processed = max(0, t - request.num_in_flight_tokens)
            for manager in coordinator.single_type_managers:
                blocks = manager.req_to_blocks.get(rid)
                if not blocks or rid not in manager.num_cached_block or rid in manager._partial_hit_reqs:
                    supported = False
                    break
                required = (t + manager.block_size) // manager.block_size
                if type(manager) is FullAttentionManager:
                    if type(manager.kv_cache_spec) is not FullAttentionSpec or required > len(blocks):
                        supported = False
                        break
                elif type(manager) is MambaManager:
                    if (manager.mamba_cache_mode != 'align' or manager.num_speculative_blocks
                            or manager.use_eagle or rid not in manager._allocated_block_reqs
                            or rid in manager._checkpoints or required != len(blocks)):
                        supported = False
                        break
                    retired = min(max(0, processed - 1) // manager.block_size, len(blocks))
                    if retired > manager._num_retired_blocks.get(rid, 0):
                        supported = False
                        break
                    old_state = manager.last_state_block_idx.get(rid)
                    if (old_state is not None
                            and old_state < (processed + manager.block_size - 1) // manager.block_size - 1
                            and not blocks[old_state].is_null):
                        supported = False
                        break
                else:
                    supported = False
                    break
        if supported:
            _COUNTS['allocate_fast'] += 1
            if self.enable_caching:
                coordinator.cache_blocks(request, min(request.num_computed_tokens + 1, request.num_tokens))
            return self.empty_kv_cache_blocks
        _COUNTS['allocate_fallback'] += 1
        return original_allocate(
            self, request, num_new_tokens, num_new_computed_tokens,
            new_computed_blocks, num_lookahead_tokens,
            num_external_computed_tokens, delay_cache_blocks, num_encoder_tokens,
            full_sequence_must_fit, reserved_blocks, has_scheduled_reqs)

    KVCacheManager.allocate_slots = allocate
    HybridKVCacheCoordinator.cache_blocks = cache
    _INSTALLED = True


def toggle(enabled):
    global _ENABLED
    _ENABLED = enabled
    return stats()


def stats():
    return {'installed': _INSTALLED, 'enabled': _ENABLED, 'pid': os.getpid(),
            'counts': dict(_COUNTS),
            'boundary': 'Only existing-block non-speculative decode no-ops; native boundary/prefill/hit path retained'}
