"""Allocate rollout collator output buffers once and fill them without Python flattening."""
import ast
import inspect
import itertools
import math
import textwrap

import numpy as np
import torch

_COUNTS = dict(calls=0, rows=0, tokens=0, fallback=0)
_FIELDS = ('input_ids', 'attention_mask', 'completion_mask', 'old_log_probs', 'position_ids', 'advantages')
_DTYPES = {torch.int64: np.int64, torch.bool: np.bool_, torch.float32: np.float32, torch.float64: np.float64}


def supported(groups):
    valid = (str(torch.get_default_device()) == 'cpu' and
             torch.get_default_dtype() in (torch.float32, torch.float64) and
             bool(groups) and all(group for group in groups))
    if valid:
        for group in groups:
            for example in group:
                value = example['advantage']
                length = len(example['input_ids'])
                if len(example['completion_mask']) != length or len(example['old_log_probs']) != length:
                    valid = False
                    break
                if type(value) not in (int, float, bool):
                    valid = False
                    break
                if type(value) is int and not -(2**63) <= value < 2**63:
                    valid = False
                    break
                if type(value) is float and math.isfinite(value) and abs(value) > torch.finfo(torch.get_default_dtype()).max:
                    valid = False
                    break
            if not valid:
                break
    if not valid:
        _COUNTS['fallback'] += 1
    return valid


def advantage_dtype(group):
    dtype = None
    for example in group:
        value = example['advantage']
        current = torch.bool if type(value) is bool else torch.int64 if type(value) is int else torch.get_default_dtype()
        dtype = current if dtype is None else torch.promote_types(dtype, current)
    return dtype


def tensorize(groups, pad_token_id):
    lengths = [[len(example['input_ids']) for example in group] for group in groups]
    totals = [sum(row) for row in lengths]
    longest = max(totals)
    shape = (len(groups), longest)
    adv_dtypes = [advantage_dtype(group) for group in groups]
    ids = np.full(shape, pad_token_id, dtype=np.int64)
    attention = np.zeros(shape, dtype=np.int64)
    completion = np.zeros(shape, dtype=np.int64)
    old_lp = np.zeros(shape, dtype=np.float32)
    positions = np.zeros(shape, dtype=np.int64)
    advantages = np.zeros(shape, dtype=_DTYPES[adv_dtypes[0]])
    index = np.arange(max(max(row) for row in lengths), dtype=np.int64)
    for row, (group, seq_lengths, total) in enumerate(zip(groups, lengths, totals)):
        ids[row, :total] = np.fromiter(itertools.chain.from_iterable(e['input_ids'] for e in group), dtype=np.int64, count=total)
        attention[row, :total] = 1
        completion[row, :total] = np.fromiter(itertools.chain.from_iterable(e['completion_mask'] for e in group), dtype=np.int64, count=total)
        old_lp[row, :total] = np.fromiter(itertools.chain.from_iterable(e['old_log_probs'] for e in group), dtype=np.float32, count=total)
        offset = 0
        row_dtype = _DTYPES[adv_dtypes[row]]
        for example, length in zip(group, seq_lengths):
            positions[row, offset:offset+length] = index[:length]
            # Native torch.full rounds in each row's dtype before pad converts to row zero's dtype.
            value = example['advantage']
            source_dtype = np.bool_ if type(value) is bool else np.int64 if type(value) is int else _DTYPES[torch.get_default_dtype()]
            advantages[row, offset:offset+length] = row_dtype(source_dtype(value))
            offset += length
    _COUNTS['calls'] += 1
    _COUNTS['rows'] += len(groups)
    _COUNTS['tokens'] += sum(totals)
    return tuple(torch.from_numpy(array) for array in (ids, attention, completion, old_lp, positions, advantages))


def transform(source):
    tree = ast.parse(textwrap.dedent(source))
    method = tree.body[0]
    assert isinstance(method, ast.FunctionDef) and method.name == 'torch_call'
    body = method.body
    start = next(i for i, n in enumerate(body) if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Tuple) and tuple(t.id for t in n.targets[0].elts) == _FIELDS)
    end = next(i for i, n in enumerate(body) if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'advantages' and isinstance(n.value, ast.Call) and isinstance(n.value.func, ast.Name) and n.value.func.id == 'pad')
    original = body[start:end+1]
    replacement = ast.parse('input_ids, attention_mask, completion_mask, old_log_probs, position_ids, advantages = poor_rl_tensorize(groups, self.pad_token_id)').body
    choose = ast.If(test=ast.parse('poor_rl_tensorize_supported(groups)', mode='eval').body, body=replacement, orelse=original)
    body[start:end+1] = [choose]
    return ast.fix_missing_locations(tree)


def compile_method(native):
    namespace = dict(native.__globals__, poor_rl_tensorize=tensorize, poor_rl_tensorize_supported=supported)
    tree = transform(inspect.getsource(native))
    exec(compile(tree, '<poor-rl native collator tensorization>', 'exec'), namespace)
    return namespace['torch_call']


def install():
    from trl.experimental.async_grpo import async_grpo_trainer as native
    cls = native.DataCollatorForRollout
    if getattr(cls, '_poor_rl_tensorize_installed', False):
        return
    cls.torch_call = compile_method(cls.torch_call)
    cls._poor_rl_tensorize_installed = True


def stats():
    return dict(_COUNTS)
