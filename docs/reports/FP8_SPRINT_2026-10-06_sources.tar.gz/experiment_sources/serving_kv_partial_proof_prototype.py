"""Exact existing partial-prefix registry proof and one-pass KV no-op allocation."""
import os

import serving_kv_prototype as base

INSTALLED = False
ENABLED = True
COUNTS = {'fused_allocate': 0, 'fallback_allocate': 0, 'cache_fast': 0, 'cache_fallback': 0}


def install():
    global INSTALLED
    if INSTALLED:
        return
    base.install()
    from vllm.v1.core.kv_cache_coordinator import HybridKVCacheCoordinator
    from vllm.v1.core.kv_cache_manager import KVCacheManager
    from vllm.v1.core.single_type_kv_cache_manager import FullAttentionManager, MambaManager
    from vllm.v1.kv_cache_interface import FullAttentionSpec
    from vllm.v1.request import RequestStatus
    from vllm.v1.core.block_pool import make_block_hash_with_group_id
    original = KVCacheManager.allocate_slots
    original_cache = HybridKVCacheCoordinator.cache_blocks

    def full_partial_is_noop(manager, request, tokens):
        pool = manager.block_pool
        block_size = manager.block_size
        hash_size = pool.hash_block_size
        if block_size == hash_size:
            return True
        if block_size % hash_size:
            return False
        boundary = request.num_prompt_tokens // hash_size * hash_size
        if not boundary or boundary > tokens or boundary % block_size == 0:
            return True
        blocks = manager.req_to_blocks.get(request.request_id, ())
        index = boundary // block_size
        if index >= len(blocks):
            return True
        block = blocks[index]
        if block.is_null:
            return True
        hash_index = boundary // hash_size - 1
        if hash_index >= len(request.block_hashes):
            return False
        key = make_block_hash_with_group_id(request.block_hashes[hash_index], manager.kv_cache_group_id)
        # Native cache_partial_block/_insert_block_hash performs no mutation,
        # eviction or event when this same key already owns this exact block.
        return block.block_hash == key or pool.cached_block_hash_to_block.contain(key, block.block_id)

    def cache_noop(coordinator, request, tokens):
        if request.num_computed_tokens < request.num_prompt_tokens or coordinator.eagle_group_ids:
            return False
        aligned = (tokens if coordinator.enable_partial_hash_hits else
                   tokens // coordinator.scheduler_block_size * coordinator.scheduler_block_size)
        rid = request.request_id
        for manager in coordinator.single_type_managers:
            if not manager.enable_caching:
                continue
            if manager.use_eagle or manager.num_cached_block.get(rid, 0) < aligned // manager.block_size:
                return False
            if type(manager) is FullAttentionManager:
                if type(manager.kv_cache_spec) is not FullAttentionSpec or not full_partial_is_noop(manager, request, aligned):
                    return False
            elif type(manager) is MambaManager:
                if manager.mamba_cache_mode != 'align' or rid in manager._checkpoints:
                    return False
                boundary = request.num_prompt_tokens // manager.block_pool.hash_block_size * manager.block_pool.hash_block_size
                if aligned == boundary and aligned % manager.block_size:
                    return False
            else:
                return False
        return True

    def cache(self, request, num_computed_tokens):
        if ENABLED and base._ENABLED and cache_noop(self, request, num_computed_tokens):
            COUNTS['cache_fast'] += 1
            return
        COUNTS['cache_fallback'] += 1
        return original_cache(self, request, num_computed_tokens)

    def allocate(self, request, num_new_tokens, num_new_computed_tokens=0,
                 new_computed_blocks=None, num_lookahead_tokens=0,
                 num_external_computed_tokens=0, delay_cache_blocks=False,
                 num_encoder_tokens=0, full_sequence_must_fit=False,
                 reserved_blocks=0, has_scheduled_reqs=True):
        coordinator = self.coordinator
        supported = (ENABLED and base._ENABLED and self.enable_caching
                     and type(coordinator) is HybridKVCacheCoordinator
                     and request.status == RequestStatus.RUNNING
                     and num_new_tokens == 1 and not num_new_computed_tokens
                     and new_computed_blocks is None and not num_lookahead_tokens
                     and not num_external_computed_tokens and not delay_cache_blocks
                     and not num_encoder_tokens and not full_sequence_must_fit
                     and not reserved_blocks
                     and request.num_computed_tokens >= request.num_prompt_tokens
                     and request.num_computed_tokens + 1 <= self.max_model_len
                     and not coordinator.eagle_group_ids)
        if supported:
            rid = request.request_id
            t = request.num_computed_tokens
            processed = max(0, t - request.num_in_flight_tokens)
            cache_tokens = min(t + 1, len(request._all_token_ids))
            aligned = (cache_tokens if coordinator.enable_partial_hash_hits else
                       cache_tokens // coordinator.scheduler_block_size * coordinator.scheduler_block_size)
            for manager in coordinator.single_type_managers:
                blocks = manager.req_to_blocks.get(rid)
                cached = manager.num_cached_block.get(rid)
                if not blocks or cached is None or rid in manager._partial_hit_reqs:
                    supported = False
                    break
                required = (t + manager.block_size) // manager.block_size
                if manager.enable_caching and (manager.use_eagle or cached < aligned // manager.block_size):
                    supported = False
                    break
                if type(manager) is FullAttentionManager:
                    if (type(manager.kv_cache_spec) is not FullAttentionSpec
                            or required > len(blocks)
                            or manager.enable_caching and not full_partial_is_noop(manager, request, aligned)):
                        supported = False
                        break
                elif type(manager) is MambaManager:
                    if (manager.mamba_cache_mode != 'align' or manager.num_speculative_blocks
                            or manager.use_eagle or rid not in manager._allocated_block_reqs
                            or rid in manager._checkpoints or required != len(blocks)):
                        supported = False
                        break
                    retired = min(max(0, processed - 1) // manager.block_size, len(blocks))
                    if retired > manager._num_retired_blocks.get(rid, 0):
                        supported = False
                        break
                    old_state = manager.last_state_block_idx.get(rid)
                    if (old_state is not None
                            and old_state < (processed + manager.block_size - 1) // manager.block_size - 1
                            and not blocks[old_state].is_null):
                        supported = False
                        break
                    if manager.enable_caching:
                        prompt_boundary = (request.num_prompt_tokens // manager.block_pool.hash_block_size
                                           * manager.block_pool.hash_block_size)
                        if aligned == prompt_boundary and aligned % manager.block_size:
                            supported = False
                            break
                else:
                    supported = False
                    break
        if supported:
            COUNTS['fused_allocate'] += 1
            base._COUNTS['allocate_fast'] += 1
            base._COUNTS['cache_fast'] += 1
            return self.empty_kv_cache_blocks
        COUNTS['fallback_allocate'] += 1
        return original(self, request, num_new_tokens, num_new_computed_tokens,
                        new_computed_blocks, num_lookahead_tokens,
                        num_external_computed_tokens, delay_cache_blocks,
                        num_encoder_tokens, full_sequence_must_fit,
                        reserved_blocks, has_scheduled_reqs)

    KVCacheManager.allocate_slots = allocate
    HybridKVCacheCoordinator.cache_blocks = cache
    INSTALLED = True


def toggle(enabled):
    global ENABLED
    ENABLED = enabled
    return stats()


def stats():
    return {'pid': os.getpid(), 'installed': INSTALLED, 'enabled': ENABLED,
            'counts': dict(COUNTS), 'base': base.stats(),
            'boundary': 'Only native existing-key/exact-block partial registration no-ops; within-call allocation/cache proof, no cross-step memo'}
