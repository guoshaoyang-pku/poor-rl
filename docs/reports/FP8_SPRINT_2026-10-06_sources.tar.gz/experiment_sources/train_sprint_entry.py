"""Four-rank sprint entry with recorded actual microbatch and optional reference offload."""
import ast
import os
import runpy
from pathlib import Path


def install_microbatch():
    from trl.experimental.async_grpo import AsyncGRPOConfig

    original = AsyncGRPOConfig.__init__

    def initialize(self, *args, **kwargs):
        requested = int(os.environ.get("SPRINT_MICROBATCH", kwargs["per_device_train_batch_size"]))
        groups = int(kwargs["num_generations"])
        local_samples = kwargs["per_device_train_batch_size"] * kwargs["gradient_accumulation_steps"]
        if requested < groups or requested % groups or local_samples % requested:
            raise ValueError("Actual microbatch must contain whole groups and divide samples per update")
        kwargs["per_device_train_batch_size"] = requested
        kwargs["gradient_accumulation_steps"] = local_samples // requested
        original(self, *args, **kwargs)
        print("[sprint] actual_microbatch=" + str(requested) + " gas=" + str(local_samples // requested)
              + " samples_per_rank_update=" + str(local_samples), flush=True)

    AsyncGRPOConfig.__init__ = initialize


def main():
    path = Path(__file__).with_name("train_filestore.py")
    if os.environ.get("SCALE_TRAIN_CHILD") == "1":
        install_microbatch()
        if os.environ.get("SPRINT_CONTROL_OBSERVE") == "1":
            from trainer_control_observer import install
            install()
        if os.environ.get("RLFORGE_REFERENCE_ENDPOINTS"):
            if os.environ.get("RLFORGE_REFERENCE_MODE") in ("ahead", "ahead_v3", "ahead_v4"):
                entry = {"ahead": "train_reference_ahead_filestore.py",
                         "ahead_v3": "train_reference_ahead_v3_filestore.py",
                         "ahead_v4": "train_reference_ahead_v4_filestore.py"}[os.environ["RLFORGE_REFERENCE_MODE"]]
                runpy.run_path(str(Path(__file__).with_name(entry)),
                               run_name="__main__")
                return
            from train_reference_filestore import _install_train_hook
            _install_train_hook()
        runpy.run_path(str(path), run_name="__main__")
        return
    tree = ast.parse(path.read_text())
    namespace = {"__name__": "__main__", "__file__": str(Path(__file__)),
                 "__package__": None, "__builtins__": __builtins__}
    exec(compile(tree, str(path), "exec"), namespace)


if __name__ == "__main__":
    main()
