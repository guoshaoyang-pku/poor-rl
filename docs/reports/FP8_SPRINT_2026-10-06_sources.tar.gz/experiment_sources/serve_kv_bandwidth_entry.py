"""Long-context KV diagnostic with EngineCore-local context snapshots."""
import statistics

import serve_kv_observed_entry
from vllm.v1.engine.core import EngineCore

native_rpc = EngineCore.collective_rpc


def distribution(values):
    ordered = sorted(values)
    return ({'n': len(ordered), 'min': ordered[0],
             'p50': statistics.median(ordered),
             'p90': ordered[min(len(ordered)-1, int(.9*len(ordered)))],
             'max': ordered[-1], 'mean': statistics.mean(ordered)} if ordered else {'n': 0})


def collective_rpc(self, method, timeout=None, args=(), kwargs=None):
    if method == 'sprint_context_lengths':
        running = list(self.scheduler.running)
        return [{'scope': 'Actual EngineCore running requests at RPC snapshot',
                 'context_tokens': distribution([r.num_computed_tokens for r in running]),
                 'prompt_tokens': distribution([r.num_prompt_tokens for r in running]),
                 'completion_tokens': distribution([max(0, r.num_computed_tokens-r.num_prompt_tokens) for r in running])}]
    return native_rpc(self, method, timeout, args, kwargs)


EngineCore.collective_rpc = collective_rpc
if __name__ == '__main__':
    serve_kv_observed_entry.serve_driver.main()
