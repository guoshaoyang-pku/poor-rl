"""Reuse frozen reference FileStore entry with separate v4 client."""
import ast
import os
from pathlib import Path


if __name__ == "__main__":
    if os.environ.get("SCALE_TRAIN_CHILD") == "1":
        import reference_prefetch
        from reference_ahead_v4 import ReferenceAheadV4Client, install_for_trainer

        reference_prefetch.ReferenceClient = ReferenceAheadV4Client
        reference_prefetch.install_for_trainer = install_for_trainer
    path = Path(__file__).with_name("train_reference_filestore.py")
    tree = ast.parse(path.read_text())
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and node.value == "reference_prefetch.py":
            node.value = "reference_ahead_v4.py"
        if isinstance(node, ast.Try):
            for index, child in enumerate(node.body):
                if (isinstance(child, ast.Assign) and any(isinstance(t, ast.Subscript) and
                        isinstance(t.value, ast.Name) and t.value.id == "manifest" and
                        isinstance(t.slice, ast.Constant) and t.slice.value == "status" for t in child.targets) and
                        isinstance(child.value, ast.Constant) and child.value.value == "completed"):
                    node.body.insert(index, ast.parse("client.assert_drained()").body[0])
                    break
    ast.fix_missing_locations(tree)
    namespace = {"__name__": "__main__", "__file__": str(Path(__file__).resolve()),
                 "__package__": None, "__builtins__": __builtins__}
    exec(compile(tree, str(path), "exec"), namespace)
