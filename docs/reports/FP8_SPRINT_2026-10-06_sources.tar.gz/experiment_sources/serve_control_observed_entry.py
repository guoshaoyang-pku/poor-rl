"""Native serving with HTTP and engine pause observation."""
import serving_control_observer as control

control.install()
import serve_pause_observed_entry

if __name__ == '__main__':
    serve_pause_observed_entry.serve_kv_bandwidth_entry.serve_kv_observed_entry.serve_driver.main()
