"""Future launcher with EngineCore-local KV counters for multiprocess DP."""
import os

from rlforge.fp8_serving import register

register()
if os.environ.get('SPRINT_SERVE_KV') == '1':
    os.environ['RLFORGE_SPRINT_KV'] = '1'
    import serving_kv_prototype
    serving_kv_prototype.install()
    from vllm.v1.engine.core import EngineCore

    native_rpc = EngineCore.collective_rpc

    def collective_rpc(self, method, timeout=None, args=(), kwargs=None):
        if method == 'sprint_kv_engine_stats':
            state = serving_kv_prototype.stats()
            manager = self.scheduler.kv_cache_manager
            coordinator = manager.coordinator
            state.update(
                scope='EngineCore-local scheduler counters; no worker indirection',
                coordinator=type(coordinator).__name__,
                running=len(self.scheduler.running),
                scheduler_block_size=coordinator.scheduler_block_size,
                managers=[{'class': type(m).__name__, 'block_size': m.block_size,
                           'hash_block_size': m.block_pool.hash_block_size,
                           'cache_mode': getattr(m, 'mamba_cache_mode', None)}
                          for m in coordinator.single_type_managers])
            return [state]
        if method == 'sprint_kv_engine_toggle':
            return [serving_kv_prototype.toggle(args[0] == '1')]
        return native_rpc(self, method, timeout, args, kwargs)

    EngineCore.collective_rpc = collective_rpc

import serve_driver

if __name__ == '__main__':
    serve_driver.main()
