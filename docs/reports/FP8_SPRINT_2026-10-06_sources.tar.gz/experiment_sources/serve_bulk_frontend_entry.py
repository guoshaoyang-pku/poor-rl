"""Bulk native decode bookkeeping with the accepted full-output frontend."""
import os
import serve_frontend_output_dedicated_entry
import serving_bulk_decode_prototype as bulk
import serving_host_timeline_observer as host
from native_cohort_serving import install_inventory
from vllm.v1.engine.core import EngineCore

bulk.install()
bulk.toggle(os.environ.get('SPRINT_BULK_DECODE', '1') == '1')
host.install()
install_inventory()
native_rpc = EngineCore.collective_rpc


def collective_rpc(self, method, timeout=None, args=(), kwargs=None):
    if method == 'sprint_bulk_decode_stats':
        return [bulk.stats()]
    if method == 'sprint_bulk_decode_toggle':
        return [bulk.toggle(args[0] == '1')]
    return native_rpc(self, method, timeout, args, kwargs)


EngineCore.collective_rpc = collective_rpc
if __name__ == '__main__':
    import serve_cpu_dedicated_entry
    serve_cpu_dedicated_entry.serve_dedicated_control_entry.serve_control_observed_entry.serve_pause_observed_entry.serve_kv_bandwidth_entry.serve_kv_observed_entry.serve_driver.main()
