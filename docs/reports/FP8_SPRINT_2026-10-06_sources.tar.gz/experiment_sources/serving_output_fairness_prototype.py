"""Yield once per native engine output batch, including small ready batches."""
import ast
import hashlib
import inspect
import textwrap


def transform(source):
    tree = ast.parse(textwrap.dedent(source))
    method = tree.body[0]
    assert isinstance(method, ast.FunctionDef) and method.name == '_run_output_handler'
    handler = [n for n in ast.walk(method) if isinstance(n, ast.AsyncFunctionDef) and n.name == 'output_handler']
    assert len(handler) == 1
    loops = [n for n in ast.walk(handler[0]) if isinstance(n, ast.While)]
    assert len(loops) == 1
    loop = loops[0]
    assert isinstance(loop.test, ast.Constant) and loop.test.value is True
    assert any(isinstance(n, ast.Attribute) and n.attr == 'get_output_async' for n in ast.walk(loop))
    assert any(isinstance(n, ast.Attribute) and n.attr == 'process_outputs' for n in ast.walk(loop))
    loop.body.append(ast.parse('await asyncio.sleep(0)').body[0])
    return ast.fix_missing_locations(tree)


def install():
    import vllm.v1.engine.async_llm as native
    cls = native.AsyncLLM
    if getattr(cls, '_poor_rl_output_fairness_installed', False):
        return dict(already_installed=True)
    source = inspect.getsource(cls._run_output_handler)
    tree = transform(source)
    namespace = dict(vars(native))
    exec(compile(tree, '<poor-rl native output batch fairness>', 'exec'), namespace)
    cls._run_output_handler = namespace['_run_output_handler']
    cls._poor_rl_output_fairness_installed = True
    return dict(native_method_sha256=hashlib.sha256(source.encode()).hexdigest(),
                one_unconditional_yield_per_engine_output_batch=True)
