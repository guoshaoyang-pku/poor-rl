"""Reuse the validated host subbatch plan for the same unchanged policy batch."""
from __future__ import annotations

import ast
import copy
import hashlib
import inspect
import json
import textwrap
import time
from collections import deque
from types import MethodType

import reference_prefetch
from reference_ahead import tensor_identity
from reference_ahead_v3 import INPUT_NAMES
from reference_ahead_v4 import ReferenceAheadV4Client


def plan_bytes(plan):
    return json.dumps(plan, sort_keys=True, separators=(",", ":")).encode()


def owner_layout(owners):
    return tuple((str(t.dtype), tuple(t.stride()), t.storage_offset()) for t in owners)


def patched_cached_plan(original):
    tree = ast.parse(textwrap.dedent(inspect.getsource(reference_prefetch.patched_subbatch_function)))
    function = tree.body[0]
    function.name = "_patched_cached_plan"
    addition = ast.parse('''
expected = {
    'mask_bool': "inputs['attention_mask'].bool()",
    'input_ids': "inputs['input_ids'][mask_bool].unsqueeze(0)",
    'completion_mask': "inputs['completion_mask'][mask_bool].unsqueeze(0)",
    'position_ids': "inputs['position_ids'][mask_bool].unsqueeze(0)",
    'plan': 'plan_subbatches(input_ids, position_ids, completion_mask, self._sb_tokens)',
}
assignments = {node.targets[0].id: node for node in function.body
               if isinstance(node, ast.Assign) and len(node.targets) == 1
               and isinstance(node.targets[0], ast.Name)}
if any(name not in assignments or ast.unparse(assignments[name].value) != expression
       for name, expression in expected.items()):
    raise ValueError('Canonical packed selection or subbatch planning changed')
assignments['plan'].value = ast.parse(
    'self._ref_model.reuse_plan(inputs, input_ids, position_ids, completion_mask, self._sb_tokens)',
    mode='eval').body
''').body
    indices = [i for i, node in enumerate(function.body)
               if isinstance(node, ast.Assign) and len(node.targets) == 1
               and isinstance(node.targets[0], ast.Name) and node.targets[0].id == "function"]
    if len(indices) != 1:
        raise ValueError("Frozen reference AST transformer changed")
    function.body[indices[0] + 1:indices[0] + 1] = addition
    ast.fix_missing_locations(tree)
    namespace = dict(reference_prefetch.__dict__)
    exec(compile(tree, __file__, "exec"), namespace)
    return namespace[function.name](original)


class ReferenceAheadV5Client(ReferenceAheadV4Client):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.plan_cache = {}
        self.staging_budget = None
        self.reused_current = None
        self.stats.update(policy_plan_cached_batches=0, policy_plan_reuse_batches=0,
                          policy_plan_validation_ms=0.0, policy_plan_cache_bytes=0)

    def stage_inputs(self, inputs, budget):
        if self.staging_budget is not None:
            raise RuntimeError("Nested reference batch staging")
        self.staging_budget = int(budget)
        try:
            super().stage_inputs(inputs, budget)
        finally:
            self.staging_budget = None

    def stage_lists(self, ids, mask, plan, *, owners=()):
        identity = tensor_identity(owners)
        layout = owner_layout(owners) if owners else ()
        copied = copy.deepcopy(plan)
        fingerprint = hashlib.sha256(plan_bytes(copied)).hexdigest()
        super().stage_lists(ids, mask, plan, owners=owners)
        if owners:
            if tensor_identity(owners) != identity or owner_layout(owners) != layout:
                error = ValueError("Batch changed while caching the reference plan")
                self.cancel(error)
                raise error
            entry = dict(owners=tuple(owners), identity=identity, layout=layout, plan=copied,
                         sha256=fingerprint, budget=self.staging_budget, tokens=len(ids))
            with self.lock:
                self.plan_cache.setdefault(identity, deque()).append(entry)
                self.stats["policy_plan_cached_batches"] += 1
                self.stats["policy_plan_cache_bytes"] += len(plan_bytes(copied))

    def reuse_plan(self, inputs, input_ids, position_ids, completion_mask, budget):
        started = time.perf_counter()
        try:
            if self.bound is None or self.reused_current is not None:
                raise ValueError("Policy plan requires one fresh bound staged batch")
            owners = tuple(inputs[name] for name in INPUT_NAMES)
            bound_owners, identity = self.bound
            with self.lock:
                if self.failure is not None or self.closed:
                    raise RuntimeError("Reference plan client failed or closed") from self.failure
                queue = self.plan_cache.get(identity)
                staged = self.staged.get(identity)
                if not queue or not staged or len(queue) != len(staged):
                    raise ValueError("Missing or reordered staged policy plan")
                entry = queue[0]
            if (not all(a is b is c for a, b, c in zip(owners, bound_owners, entry["owners"]))
                    or tensor_identity(owners) != identity or owner_layout(owners) != entry["layout"]):
                raise ValueError("Original policy batch changed before plan reuse")
            if entry["budget"] is None or int(budget) != entry["budget"]:
                raise ValueError("Policy and staged reference subbatch budgets differ")
            packed = (input_ids, completion_mask, position_ids)
            if any(tuple(t.shape) != (1, entry["tokens"]) or t.device != owners[0].device for t in packed):
                raise ValueError("Canonical packed policy tensor shape or device differs")
            if hashlib.sha256(plan_bytes(entry["plan"])).hexdigest() != entry["sha256"]:
                raise ValueError("Cached canonical plan fingerprint changed")
            result = copy.deepcopy(entry["plan"])
            self.reused_current = (entry, packed, tensor_identity(packed))
            self.stats["policy_plan_reuse_batches"] += 1
            return result
        except BaseException as error:
            self.cancel(error)
            raise
        finally:
            self.stats["policy_plan_validation_ms"] += 1000 * (time.perf_counter() - started)

    def prefetch(self, input_ids, completion_mask, plan):
        if self.reused_current is None:
            if self.bound is not None:
                error = ValueError("Bound policy reference requires the validated cached plan")
                self.cancel(error)
                raise error
            return super().prefetch(input_ids, completion_mask, plan)
        try:
            entry, packed, identity = self.reused_current
            if (input_ids is not packed[0] or completion_mask is not packed[1]
                    or tensor_identity(packed) != identity
                    or hashlib.sha256(plan_bytes(plan)).hexdigest() != entry["sha256"]):
                raise ValueError("Reused packed policy tensors or plan changed before prefetch")
            super().prefetch(input_ids, completion_mask, plan)
            with self.lock:
                queue = self.plan_cache[entry["identity"]]
                if queue.popleft() is not entry:
                    raise ValueError("Cached policy plan consumption order differs")
                if not queue:
                    del self.plan_cache[entry["identity"]]
        except BaseException as error:
            self.cancel(error)
            raise

    def finish(self):
        super().finish()
        self.reused_current = None

    def cancel(self, error):
        self.plan_cache.clear()
        self.reused_current = None
        super().cancel(error)

    def assert_drained(self):
        super().assert_drained()
        if self.plan_cache or self.reused_current is not None:
            raise RuntimeError("A cached policy plan was not consumed")


def install_for_trainer(trainer, client, *, offload_local_reference=True):
    if not trainer._sb_tokens or not trainer._prefix_share or abs(trainer._kl_beta - 0.05) > 1e-12:
        raise ValueError("Cached-plan prototype requires existing prefix-share GSPO and KL=.05")
    original_ref = trainer._ref_model
    original_method = trainer._compute_loss_subbatched
    original_get = trainer.get_batch_samples
    patched, source_sha256 = patched_cached_plan(original_method.__func__)
    reference_device = None
    if offload_local_reference and original_ref is not None and hasattr(original_ref, "to"):
        reference_device = original_ref.device
        original_ref.to("cpu")
    trainer._ref_model = client

    def get_batch_samples(self, epoch_iterator, num_batches, device):
        def staged_iterator():
            for batch in epoch_iterator:
                client.stage_inputs(batch, self._sb_tokens)
                yield batch
        return original_get(staged_iterator(), num_batches, device)

    def run(self, model, inputs):
        client.bind_inputs(inputs)
        try:
            result = patched(self, model, inputs)
            client.finish()
            return result
        except BaseException as error:
            client.cancel(error)
            raise
        finally:
            client.bound = None

    trainer.get_batch_samples = MethodType(get_batch_samples, trainer)
    trainer._compute_loss_subbatched = MethodType(run, trainer)
    trainer._reference_ahead = True
    trainer._reference_prefetch_source_sha256 = source_sha256

    def restore(*, return_reference_to_gpu=True):
        trainer.get_batch_samples = original_get
        trainer._compute_loss_subbatched = original_method
        trainer._ref_model = original_ref
        trainer._reference_ahead = False
        if reference_device is not None and return_reference_to_gpu:
            original_ref.to(reference_device)

    return restore
