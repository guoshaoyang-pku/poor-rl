"""Process-only four-tap causal convolution with compact saved state.

Keeps BF16 tap-product boundaries, FP32 summation and FP32 master objects.
Recomputes preactivation for analytic backward instead of saving padded wide
FP32 intermediates. Native kernels and actual GSPO timing remain required.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import torch
import torch.nn.functional as F

try:
    import triton
    import triton.language as tl
except ImportError:
    triton = tl = None


if triton is not None:
    @triton.jit
    def _preactivation(X, W, Bias, b, t, c, mask, XS0, XS1, XS2,
                       HAS_BIAS: tl.constexpr):
        value = tl.full(t.shape, 0.0, tl.float32)
        for tap in tl.static_range(4):
            pos = t + tap - 3
            x = tl.load(X + b * XS0 + c * XS1 + pos * XS2, mask & (pos >= 0), other=0).to(tl.float32)
            w = tl.load(W + c * 4 + tap, mask, other=0).to(X.dtype.element_ty).to(tl.float32)
            product = (x * w).to(X.dtype.element_ty).to(tl.float32)
            value = value + product
        if HAS_BIAS:
            bias = tl.load(Bias + c, mask, other=0).to(X.dtype.element_ty).to(tl.float32)
            value = value + bias
        return value

    @triton.jit
    def _index(index, L, C: tl.constexpr, TIME_MAJOR: tl.constexpr):
        if TIME_MAJOR:
            return index // (C * L), (index // C) % L, index % C
        return index // (C * L), index % L, (index // L) % C

    @triton.jit(do_not_specialize=["N", "L"])
    def _forward_kernel(X, W, Bias, Y, N, L, C: tl.constexpr, XS0, XS1, XS2,
                        HAS_BIAS: tl.constexpr, SILU: tl.constexpr, TIME_MAJOR: tl.constexpr, BLOCK: tl.constexpr):
        index = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
        b, t, c = _index(index, L, C, TIME_MAJOR)
        value = _preactivation(X, W, Bias, b, t, c, index < N, XS0, XS1, XS2, HAS_BIAS)
        if SILU:
            value = value * tl.sigmoid(value)
        tl.store(Y + index, value, index < N)

    @triton.jit(do_not_specialize=["N", "L"])
    def _upstream_kernel(X, W, Bias, DY, G, N, L, C: tl.constexpr,
                         XS0, XS1, XS2, DS0, DS1, DS2,
                         HAS_BIAS: tl.constexpr, SILU: tl.constexpr, TIME_MAJOR: tl.constexpr, BLOCK: tl.constexpr):
        index = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
        b, t, c = _index(index, L, C, TIME_MAJOR)
        dy = tl.load(DY + b * DS0 + c * DS1 + t * DS2, index < N, other=0).to(tl.float32)
        if SILU:
            value = _preactivation(X, W, Bias, b, t, c, index < N, XS0, XS1, XS2, HAS_BIAS)
            sig = tl.sigmoid(value)
            dy = dy * sig * (1.0 + value * (1.0 - sig))
        tl.store(G + index, dy, index < N)

    @triton.jit(do_not_specialize=["N", "L"])
    def _dx_kernel(G, W, DX, N, L, C: tl.constexpr, XD: tl.constexpr, TIME_MAJOR: tl.constexpr, BLOCK: tl.constexpr):
        index = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
        b, t, c = _index(index, L, C, TIME_MAJOR)
        value = tl.full((BLOCK,), 0.0, tl.float32)
        for tap in tl.static_range(4):
            pos = t + 3 - tap
            offset = (b * L + pos) * C + c if TIME_MAJOR else (b * C + c) * L + pos
            grad = tl.load(G + offset, (index < N) & (pos < L), other=0).to(XD).to(tl.float32)
            weight = tl.load(W + c * 4 + tap, index < N, other=0).to(XD).to(tl.float32)
            value = value + grad * weight
        tl.store(DX + index, value, index < N)

    @triton.jit(do_not_specialize=["Rows", "L"])
    def _dw_kernel(X, G, PartialW, PartialB, Rows, L, C: tl.constexpr,
                   XS0, XS1, XS2, GS0, GS1, GS2, HAS_BIAS: tl.constexpr, RB: tl.constexpr, CB: tl.constexpr):
        group = tl.program_id(0)
        row = group * RB + tl.arange(0, RB)
        c = tl.program_id(1) * CB + tl.arange(0, CB)
        b, t = row // L, row % L
        valid = (row[:, None] < Rows) & (c[None, :] < C)
        upstream = tl.load(G + b[:, None] * GS0 + c[None, :] * GS1 + t[:, None] * GS2, valid, other=0)
        grad = upstream.to(X.dtype.element_ty).to(tl.float32)
        for tap in tl.static_range(4):
            pos = t + tap - 3
            x = tl.load(X + b[:, None] * XS0 + c[None, :] * XS1 + pos[:, None] * XS2,
                        valid & (pos[:, None] >= 0), other=0).to(tl.float32)
            partial = tl.sum(grad * x, 0)
            tl.store(PartialW + (group * C + c) * 4 + tap, partial, c < C)
        if HAS_BIAS:
            tl.store(PartialB + group * C + c, tl.sum(upstream, 0), c < C)


def _cpu_pre(x, weight, bias):
    padded = F.pad(x.float(), (3, 0))
    result = torch.zeros_like(x, dtype=torch.float32)
    wf = weight.to(x.dtype).float()
    for tap in range(4):
        result = result + (padded[..., tap:tap + x.shape[-1]] * wf[:, tap][None, :, None]).to(x.dtype).float()
    if bias is not None:
        result = result + bias.to(x.dtype).float()[None, :, None]
    return result


class _Conv(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, weight, bias, silu):
        ctx.set_materialize_grads(False)
        ctx.save_for_backward(x, weight, bias)
        ctx.silu = silu
        if not x.is_cuda:
            result = _cpu_pre(x, weight, bias)
            return (F.silu(result) if silu else result).to(x.dtype)
        if triton is None:
            raise RuntimeError("CUDA convolution requires the existing Triton runtime")
        batch, channels, length = x.shape
        time_major = x.stride(1) == 1
        out = (torch.empty((batch, length, channels), device=x.device, dtype=x.dtype).transpose(1, 2)
               if time_major else torch.empty_like(x, memory_format=torch.contiguous_format))
        _forward_kernel[(triton.cdiv(x.numel(), 256),)](
            x, weight, bias if bias is not None else x, out, x.numel(), length, channels, *x.stride(),
            bias is not None, silu, time_major, 256, enable_fp_fusion=False)
        return out

    @staticmethod
    def backward(ctx, grad):
        if grad is None:
            return None, None, None, None
        x, weight, bias = ctx.saved_tensors
        need_x, need_w, need_b = ctx.needs_input_grad[:3]
        dx = dw = db = None
        if not x.is_cuda:
            upstream = grad.float()
            if ctx.silu:
                pre = _cpu_pre(x, weight, bias)
                sig = pre.sigmoid()
                upstream = upstream * sig * (1 + pre * (1 - sig))
            g = upstream.to(x.dtype).float()
            length = x.shape[-1]
            if need_x:
                dx = torch.zeros_like(x, dtype=torch.float32)
                wf = weight.to(x.dtype).float()
                for tap in range(4):
                    delay = 3 - tap
                    if delay < length:
                        dx[..., :length - delay] += g[..., delay:] * wf[:, tap][None, :, None]
                dx = dx.to(x.dtype)
            if need_w:
                padded = F.pad(x.float(), (3, 0))
                dw = torch.stack([(g * padded[..., tap:tap + length]).sum((0, 2)) for tap in range(4)], -1)
                dw = dw.to(x.dtype).to(weight.dtype)
            if need_b:
                db = upstream.sum((0, 2)).to(x.dtype).to(bias.dtype)
            return dx, dw, db, None
        batch, channels, length = x.shape
        time_major = x.stride(1) == 1
        # Bias gradient needs the FP32 upstream before the tap-product BF16 cast.
        upstream = (torch.empty((batch, length, channels), device=x.device, dtype=torch.float32).transpose(1, 2)
                    if time_major else torch.empty(x.shape, device=x.device, dtype=torch.float32))
        _upstream_kernel[(triton.cdiv(x.numel(), 256),)](
            x, weight, bias if bias is not None else x, grad, upstream, x.numel(), length, channels,
            *x.stride(), *grad.stride(), bias is not None, ctx.silu, time_major, 256, enable_fp_fusion=False)
        if need_x:
            dx = torch.empty_like(upstream, dtype=x.dtype)
            _dx_kernel[(triton.cdiv(x.numel(), 256),)](
                upstream, weight, dx, x.numel(), length, channels, tl.bfloat16 if x.dtype == torch.bfloat16 else tl.float32,
                time_major, 256, enable_fp_fusion=False)
        if need_w or need_b:
            groups = triton.cdiv(batch * length, 128)
            partial_w = torch.empty((groups, channels, 4), device=x.device, dtype=torch.float32)
            partial_b = torch.empty((groups, channels), device=x.device, dtype=torch.float32) if need_b else partial_w
            _dw_kernel[(groups, triton.cdiv(channels, 16))](
                x, upstream, partial_w, partial_b, batch * length, length, channels, *x.stride(), *upstream.stride(),
                need_b, 128, 16, enable_fp_fusion=False)
            if need_w:
                dw = partial_w.sum(0).to(x.dtype).to(weight.dtype)
            if need_b:
                db = partial_b.sum(0).to(x.dtype).to(bias.dtype)
        return dx, dw, db, None


def causal_conv(x, weight, bias, activation):
    if weight.ndim != 2 or weight.shape != (x.shape[1], 4) or not weight.is_contiguous():
        raise ValueError("Convolution candidate requires contiguous four-tap weights")
    if x.dtype not in (torch.bfloat16, torch.float32) or activation not in (None, "silu", "swish"):
        raise ValueError("Convolution candidate requires BF16/FP32 and SiLU")
    return _Conv.apply(x, weight, bias, activation is not None)


def install_for_benchmark(policy, ref=None):
    from rlforge import fp8_alignment as alignment
    import fusion_mlp_prototype as mlp

    restore_mlp = mlp.install_for_benchmark(policy, ref=ref)
    original = alignment._causal_conv
    alignment._causal_conv = causal_conv

    def restore():
        alignment._causal_conv = original
        restore_mlp()

    return restore


def primitive_gate(device):
    torch.set_num_threads(1)
    torch.manual_seed(19)
    evidence = []
    for dtype in (torch.bfloat16, torch.float32):
        for batch, channels, length in ((1, 7, 1), (2, 16, 2), (3, 17, 8), (2, 32, 17)):
            for bias_enabled in (False, True):
                for silu in (False, True):
                    x = torch.randn(batch, length, channels, dtype=dtype, device=device).transpose(1, 2)
                    weight = torch.randn(channels, 4, device=device) * 0.2
                    bias = torch.randn(channels, device=device) * 0.1 if bias_enabled else None
                    grad = torch.randn_like(x) * 0.01
                    results = []
                    for fused in (False, True):
                        xx, ww = x.clone().requires_grad_(), weight.clone().requires_grad_()
                        bb = bias.clone().requires_grad_() if bias is not None else None
                        if fused:
                            out = causal_conv(xx, ww, bb, "silu" if silu else None)
                        else:
                            pre = _cpu_pre(xx, ww, bb)
                            out = (F.silu(pre) if silu else pre).to(dtype)
                        values = (xx, ww) if bb is None else (xx, ww, bb)
                        gradients = torch.autograd.grad(out, values, grad)
                        results.append((out, gradients))
                    forward_exact = torch.equal(results[0][0], results[1][0])
                    forward_error = float((results[0][0].float() - results[1][0].float()).abs().max())
                    if not silu:
                        assert forward_exact
                    else:
                        torch.testing.assert_close(results[0][0], results[1][0], rtol=0.01, atol=0.0003)
                    errors = []
                    for expected, actual in zip(results[0][1], results[1][1]):
                        errors.append(float((expected.float() - actual.float()).abs().max()))
                        torch.testing.assert_close(actual, expected, rtol=0.02 if dtype == torch.bfloat16 else 2e-5,
                                                   atol=0.0003 if dtype == torch.bfloat16 else 1e-7)
                    assert all(t.dtype == torch.float32 for t in results[1][1][1:])
                    evidence.append({"shape": list(x.shape), "dtype": str(dtype), "bias": bias_enabled,
                                     "silu": silu, "forward_exact": forward_exact, "forward_max_abs": forward_error, "gradient_max_abs": errors,
                                     "parameter_gradients_fp32": True})
    return {"scope": str(device) + " analytic backward against same tap-product rounding/autograd",
            "cases": evidence, "passed": len(evidence),
            "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--cpu-gate", action="store_true")
    parser.add_argument("--gpu-gate", action="store_true")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    if not args.cpu_gate and not args.gpu_gate:
        parser.error("Use --cpu-gate/--gpu-gate or import install_for_benchmark")
    result = primitive_gate(torch.device("cuda" if args.gpu_gate else "cpu"))
    Path(args.output).write_text(json.dumps(result, indent=2))
    print(json.dumps({"passed": result["passed"], "source_sha256": result["source_sha256"]}))
