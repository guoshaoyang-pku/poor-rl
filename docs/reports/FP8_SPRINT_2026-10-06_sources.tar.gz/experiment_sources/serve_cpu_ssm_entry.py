"""Future CPU scheduler/output plus low-precision recurrent-state experiment."""
import serving_decode_scheduler_prototype as decode
import serving_output_prototype as output
import serving_scheduler_prototype as scheduler

decode.install()
output.install()
scheduler.install()
decode.toggle(True)
output.toggle(True)
scheduler.toggle(True)
import serve_pause_observed_entry
from vllm.v1.engine.core import EngineCore

native_rpc = EngineCore.collective_rpc


def collective_rpc(self, method, timeout=None, args=(), kwargs=None):
    if method == 'sprint_combined_cpu_stats':
        return [{'scheduler': scheduler.stats(), 'decode': decode.stats(), 'output': output.stats()}]
    return native_rpc(self, method, timeout, args, kwargs)


EngineCore.collective_rpc = collective_rpc
if __name__ == '__main__':
    serve_pause_observed_entry.serve_kv_bandwidth_entry.serve_kv_observed_entry.serve_driver.main()
