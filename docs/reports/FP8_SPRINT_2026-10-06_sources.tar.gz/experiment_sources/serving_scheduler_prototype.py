"""Isolated empty-block conversion and coarse EngineCore wall attribution."""
import os
import time

_ENABLED = False
_INSTALLED = False
_COUNTS = {'empty_fast': 0, 'fallback': 0}
_TIMER = None


def install():
    global _INSTALLED
    if _INSTALLED:
        return
    from vllm.v1.core.kv_cache_manager import KVCacheBlocks, KVCacheManager
    native_init = KVCacheManager.__init__
    native_ids = KVCacheBlocks.get_block_ids

    def initialize(self, *args, **kwargs):
        native_init(self, *args, **kwargs)
        empty = self.empty_kv_cache_blocks
        empty._sprint_immutable_empty = empty.blocks

    def block_ids(self, allow_none=False, *, group_ids=None):
        if (_ENABLED and allow_none and group_ids is None
                and self.blocks is getattr(self, '_sprint_immutable_empty', None)):
            _COUNTS['empty_fast'] += 1
            return None
        _COUNTS['fallback'] += 1
        return native_ids(self, allow_none, group_ids=group_ids)

    KVCacheManager.__init__ = initialize
    KVCacheBlocks.get_block_ids = block_ids
    _INSTALLED = True


def stats():
    return {'pid': os.getpid(), 'enabled': _ENABLED, 'installed': _INSTALLED,
            'counts': dict(_COUNTS), 'timer': _TIMER,
            'scope': 'Coarse normal wall times, without cProfile; inclusive scopes overlap'}


def toggle(enabled):
    global _ENABLED
    _ENABLED = enabled
    return stats()


def arm(engine, calls=128):
    global _TIMER
    calls = int(calls)
    if not 1 <= calls <= 256:
        raise ValueError('Timer must be bounded to 1-256 EngineCore calls')
    if _TIMER and not _TIMER['complete']:
        raise RuntimeError('Timer already active')
    state = {'pid': os.getpid(), 'calls': 0, 'limit': calls, 'complete': False,
             'wall_ms': 0.0, 'running_per_call': [], 'stages': {}}
    _TIMER = state
    scheduler = engine.scheduler
    originals = {}

    def wrap(name):
        native = getattr(scheduler, name)
        originals[name] = native
        record = state['stages'][name] = {'calls': 0, 'wall_ms': 0.0}

        def timed(*args, **kwargs):
            started = time.perf_counter()
            try:
                return native(*args, **kwargs)
            finally:
                record['calls'] += 1
                record['wall_ms'] += (time.perf_counter() - started) * 1000
        setattr(scheduler, name, timed)

    for name in ['schedule', 'update_from_output', '_make_cached_request_data',
                 '_update_after_schedule']:
        wrap(name)
    original_step = engine.step_fn

    def step():
        started = time.perf_counter()
        state['running_per_call'].append(len(scheduler.running))
        try:
            return original_step()
        finally:
            state['calls'] += 1
            state['wall_ms'] += (time.perf_counter() - started) * 1000
            if state['calls'] == calls:
                engine.step_fn = original_step
                for name, native in originals.items():
                    setattr(scheduler, name, native)
                state['complete'] = True
    engine.step_fn = step
    return stats()
