"""Cost-aware frozen BF16 reference dispatch with compact, bound GAS metadata."""
from __future__ import annotations

import json
import math
import os
import time
import urllib.request
from collections import deque
from types import MethodType

from reference_ahead import tensor_identity
from reference_prefetch import ReferenceClient, build_payload
from reference_prefetch import install_for_trainer as install_microbatch_reference


INPUT_NAMES = ("input_ids", "completion_mask", "attention_mask", "position_ids")


def compact_payload(ids, mask, sb, reference_sha256, source_sha256, temperature):
    prefix = int(sb["P"])
    prompt = ids[sb["a0"]:sb["a0"] + prefix]
    compact_ids, compact_mask, buckets, global_slots = [], [], [], []
    for bucket in sb["buckets"]:
        new_bucket = []
        for start, end in bucket:
            if not 0 <= start <= start + prefix < end <= len(ids):
                raise ValueError("Invalid original branch range")
            if ids[start:start + prefix] != prompt:
                raise ValueError("Original branches have different prompt prefixes")
            offset = len(compact_ids)
            compact_ids.extend(ids[start:end])
            compact_mask.extend(mask[start:end])
            new_bucket.append([offset, len(compact_ids)])
            global_slots.extend(t - 1 for t in range(start + prefix + 1, end) if mask[t])
        buckets.append(new_bucket)
    compact_sb = dict(sb, a0=0, buckets=buckets)
    body = build_payload(compact_ids, compact_mask, compact_sb, reference_sha256, source_sha256, temperature)
    if len(global_slots) != len(body["expected_slots"]):
        raise ValueError("Compact reference changed completion-slot count")
    return body, global_slots


class ReferenceAheadV3Client(ReferenceClient):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.staged = {}
        self.staged_count = 0
        self.bound = None
        self.max_ahead = int(os.environ.get("RLFORGE_REFERENCE_AHEAD_BATCHES", "64"))
        self.endpoint_pending_tokens = [0] * len(self.endpoints)
        self.endpoint_offset = int(os.environ.get("LOCAL_RANK", "0")) % len(self.endpoints)
        self.stats.update(ahead_submitted_batches=0, ahead_consumed_batches=0, ahead_fallback_batches=0,
                          ahead_peak_batches=0, metadata_reuse_batches=0, stage_host_ms=0.0,
                          stage_payload_ms=0.0, stage_total_ms=0.0, request_bytes=0,
                          request_full_input_tokens=0, request_compact_input_tokens=0,
                          endpoint_requests=[0] * len(self.endpoints), endpoint_padded_tokens=[0] * len(self.endpoints))

    def _prepare(self, ids, mask, plan):
        started = time.perf_counter()
        prepared, all_slots = [], []
        keys = [json.dumps(sb, sort_keys=True) for sb in plan]
        if len(set(keys)) != len(keys):
            raise ValueError("Duplicate reference subbatch")
        for key, sb in zip(keys, plan):
            body, slots = compact_payload(ids, mask, sb, self.reference_sha256, self.source_sha256, self.temperature)
            data = json.dumps(body, separators=(",", ":")).encode()
            prepared.append((key, body, data, int(sb["tokens"])))
            all_slots.extend(slots)
            self.stats["request_full_input_tokens"] += len(ids)
            self.stats["request_compact_input_tokens"] += len(body["input_ids"])
            self.stats["request_bytes"] += len(data)
        if sorted(all_slots) != [t - 1 for t in range(1, len(mask)) if mask[t]]:
            raise ValueError("Reference must score every fresh completion exactly once")
        self.stats["stage_payload_ms"] += 1000 * (time.perf_counter() - started)
        return prepared

    def _send_prepared(self, index, body, data, cost):
        start = time.perf_counter()
        try:
            request = urllib.request.Request(self.endpoints[index] + "/score", data=data,
                                             headers={"Content-Type": "application/json"}, method="POST")
            with self.opener.open(request, timeout=self.timeout) as response:
                result = json.load(response)
            for key in ["schema", "precision", "request_sha256", "reference_sha256", "source_sha256", "temperature"]:
                if result.get(key) != body[key]:
                    raise ValueError("Reference response contract mismatch: " + key)
            if result.get("slots") != body["expected_slots"] or len(result["log_probs"]) != len(result["slots"]):
                raise ValueError("Reference returned incomplete or reordered compact scores")
            if not all(math.isfinite(value) for value in result["log_probs"]):
                raise ValueError("Nonfinite frozen reference logprob")
            with self.lock:
                self.stats["requests"] += 1
                self.stats["completion_tokens"] += len(result["slots"])
                self.stats["worker_compute_ms"] += result["compute_ms"]
                self.stats["network_roundtrip_s"] += time.perf_counter() - start
            return result
        finally:
            with self.lock:
                self.endpoint_pending_tokens[index] -= cost

    def _submit_locked(self, prepared):
        pending = {}
        for key, body, data, cost in prepared:
            index = min(range(len(self.endpoints)), key=lambda i: (
                self.endpoint_pending_tokens[i], (i - self.endpoint_offset) % len(self.endpoints)))
            self.endpoint_offset = (index + 1) % len(self.endpoints)
            self.endpoint_pending_tokens[index] += cost
            self.stats["endpoint_requests"][index] += 1
            self.stats["endpoint_padded_tokens"][index] += cost
            pending[key] = (body, self.executor.submit(self._send_prepared, index, body, data, cost))
        return pending

    def stage_lists(self, ids, mask, plan, *, owners=()):
        prepared = self._prepare(ids, mask, plan)
        identity = tensor_identity(owners)
        key = identity if owners else tuple(body["request_sha256"] for _, body, _, _ in prepared)
        with self.lock:
            if self.failure is not None or self.closed:
                raise RuntimeError("Reference client failed or closed") from self.failure
            if self.staged_count >= self.max_ahead:
                raise RuntimeError("Reference lookahead exceeds GAS batch capacity")
            pending = self._submit_locked(prepared)
            self.staged.setdefault(key, deque()).append((pending, tuple(owners), identity, tuple(pending)))
            self.staged_count += 1
            self.stats["ahead_submitted_batches"] += 1
            self.stats["ahead_peak_batches"] = max(self.stats["ahead_peak_batches"], self.staged_count)

    def stage_inputs(self, inputs, budget):
        import torch
        from rlforge.prefix_share import plan_subbatches

        started = time.perf_counter()
        owners = tuple(inputs[name] for name in INPUT_NAMES)
        mask = inputs["attention_mask"].bool()
        packed = torch.stack([inputs[name][mask].detach().long() for name in
                              ("input_ids", "completion_mask", "position_ids")]).cpu()
        self.stats["stage_host_ms"] += 1000 * (time.perf_counter() - started)
        ids, cm, pos = (packed[i:i + 1] for i in range(3))
        plan = plan_subbatches(ids, pos, cm, budget)
        self.stage_lists(ids[0].tolist(), cm[0].tolist(), plan, owners=owners)
        self.stats["stage_total_ms"] += 1000 * (time.perf_counter() - started)

    def bind_inputs(self, inputs):
        if self.bound is not None:
            raise RuntimeError("Reference inputs are already bound")
        owners = tuple(inputs[name] for name in INPUT_NAMES)
        identity = tensor_identity(owners)
        for queue in self.staged.values():
            for _pending, staged_owners, staged_identity, _keys in queue:
                if any(current is staged for current, staged in zip(owners, staged_owners)) and identity != staged_identity:
                    error = ValueError("Staged batch changed before canonical reference binding")
                    self.cancel(error)
                    raise error
        self.bound = (owners, identity)

    def prefetch(self, input_ids, completion_mask, plan):
        if self.bound is not None:
            owners, identity = self.bound
            if tensor_identity(owners) != identity:
                raise ValueError("Bound original batch changed before reference consumption")
            with self.lock:
                if self.failure is not None or self.closed or self.pending:
                    raise RuntimeError("Reference client failed, closed or has unconsumed scores") from self.failure
                queue = self.staged.get(identity)
                entry = queue.popleft() if queue else None
                if entry is not None:
                    self.staged_count -= 1
                    if not queue:
                        del self.staged[identity]
            if entry is not None:
                pending, staged_owners, staged_identity, keys = entry
                if tensor_identity(staged_owners) != staged_identity or keys != tuple(
                        json.dumps(sb, sort_keys=True) for sb in plan):
                    for _body, future in pending.values():
                        future.cancel()
                    raise ValueError("Staged batch changed or canonical subbatch plan differs")
                self.pending = pending
                self.active_identity = tensor_identity((input_ids, completion_mask))
                self.active_tensors = (input_ids, completion_mask)
                self.stats["ahead_consumed_batches"] += 1
                self.stats["metadata_reuse_batches"] += 1
                return
        self.stats["ahead_fallback_batches"] += 1
        ids = input_ids.detach().cpu()[0].tolist()
        mask = completion_mask.detach().cpu()[0].tolist()
        prepared = self._prepare(ids, mask, plan)
        with self.lock:
            if self.failure is not None or self.closed or self.pending:
                raise RuntimeError("Reference client failed, closed or has unconsumed scores") from self.failure
            self.pending = self._submit_locked(prepared)
        self.active_identity = tensor_identity((input_ids, completion_mask))
        self.active_tensors = (input_ids, completion_mask)

    def cancel(self, error):
        with self.lock:
            staged = [future for queue in self.staged.values() for pending, _owners, _identity, _keys in queue
                      for _body, future in pending.values()]
            self.staged.clear()
            self.staged_count = 0
            self.bound = None
        for future in staged:
            future.cancel()
        super().cancel(error)

    def assert_drained(self):
        if self.staged_count or self.pending or self.bound is not None:
            raise RuntimeError("Lookahead BF16 scores were not consumed by every staged batch")


def install_for_trainer(trainer, client, *, offload_local_reference=True):
    restore_microbatch = install_microbatch_reference(
        trainer, client, offload_local_reference=offload_local_reference)
    original_get = trainer.get_batch_samples
    reference_run = trainer._compute_loss_subbatched

    def get_batch_samples(self, epoch_iterator, num_batches, device):
        def staged_iterator():
            for batch in epoch_iterator:
                client.stage_inputs(batch, self._sb_tokens)
                yield batch

        return original_get(staged_iterator(), num_batches, device)

    def run(self, model, inputs):
        client.bind_inputs(inputs)
        try:
            return reference_run(model, inputs)
        finally:
            client.bound = None

    trainer.get_batch_samples = MethodType(get_batch_samples, trainer)
    trainer._compute_loss_subbatched = MethodType(run, trainer)
    trainer._reference_ahead = True

    def restore(*, return_reference_to_gpu=True):
        trainer.get_batch_samples = original_get
        trainer._reference_ahead = False
        restore_microbatch(return_reference_to_gpu=return_reference_to_gpu)

    return restore
