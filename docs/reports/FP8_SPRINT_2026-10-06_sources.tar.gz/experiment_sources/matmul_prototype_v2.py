"""Head-gradient fusion with an exact no-entropy row amax shortcut."""
from __future__ import annotations

import torch
import triton
import triton.language as tl

import matmul_prototype as base

_ORIGINAL_QUANTIZED_GRADIENT = base.quantized_gradient


@triton.jit
def _gradient_amax_no_entropy(L, Z, G, T, PARTIAL, N: tl.constexpr,
                              V: tl.constexpr, LS: tl.constexpr, IT: tl.constexpr,
                              BLOCK: tl.constexpr):
    row = tl.program_id(0)
    cols = tl.arange(0, BLOCK)
    target = tl.load(T + row)
    valid_target = (target >= 0) & (target < V)
    l = tl.load(L + row * V + cols, cols < V, other=0).to(tl.float32)
    x = (l * LS) * IT
    other_x = tl.where((cols < V) & (cols != target), x, float("-inf"))
    other_max = tl.max(other_x, 0)
    z = tl.load(Z + row)
    g = tl.load(G + row)
    p_other = tl.exp(other_max - z)
    other_gl = (((-g) * p_other) * IT) * LS
    target_l = tl.load(L + row * V + target, valid_target, other=0).to(tl.float32)
    target_x = (target_l * LS) * IT
    p_target = tl.exp(target_x - z)
    target_gl = (((-g) * p_target + g) * IT) * LS
    target_abs = tl.where(valid_target, tl.abs(target_gl), 0.0)
    amax = tl.maximum(tl.abs(other_gl), target_abs)
    tl.store(PARTIAL + row, amax)


def quantized_gradient(logits, log_z, g, ge, ent, local_targets, ls, inv_t):
    if ge is not None:
        return _ORIGINAL_QUANTIZED_GRADIENT(logits, log_z, g, ge, ent, local_targets, ls, inv_t)
    from rlforge.fp8 import _amax_scale_kernel

    n, vocab = logits.shape
    mp = (n + 15) // 16 * 16
    partial = torch.empty(n, device=logits.device, dtype=torch.float32)
    scale = torch.empty((), device=logits.device, dtype=torch.float32)
    q = torch.empty((mp, vocab), device=logits.device, dtype=torch.float8_e5m2)
    qt = torch.empty((vocab, mp), device=logits.device, dtype=torch.float8_e5m2)
    _gradient_amax_no_entropy[(n,)](
        logits, log_z, g, local_targets, partial, n, vocab, ls, inv_t,
        triton.next_power_of_2(vocab), num_warps=8, enable_fp_fusion=False)
    _amax_scale_kernel[(1,)](partial, scale, n, 57344.0, triton.next_power_of_2(n))
    base._gradient_quantize_dual[(triton.cdiv(mp, 32), triton.cdiv(vocab, 64))](
        logits, log_z, g, g, ent, local_targets, q, qt, scale, n, vocab, mp,
        ls, inv_t, False, 32, 64, enable_fp_fusion=False)
    return q[:n], qt, scale


def install_for_benchmark(policy, ref=None):
    original_gradient = base.quantized_gradient
    base.quantized_gradient = quantized_gradient
    restore_head = base.install_for_benchmark(policy, ref=ref)

    def restore():
        restore_head()
        base.quantized_gradient = original_gradient

    return restore
