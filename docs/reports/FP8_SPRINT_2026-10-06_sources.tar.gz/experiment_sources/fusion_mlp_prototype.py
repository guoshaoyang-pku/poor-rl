"""Process-only FP8 MLP fusion with FP32 master-weight gradients.

SwiGLU writes directly into down-projection FP8 activations. Backward derives
packed gate/up E5 gradients from down dgrad without BF16 gradient temporaries
or concatenation. Existing BF16 activation/gradient boundaries and scale scopes
are retained, but Triton scalar rounding still needs numerical/GPU gates.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from types import MethodType

import torch
import torch.nn.functional as F
import fusion_prototype as base

try:
    import triton
    import triton.language as tl
except ImportError:
    triton = tl = None


if triton is not None:
    @triton.jit
    def _silu_product(g, u):
        return (g * tl.sigmoid(g) * u).to(tl.bfloat16).to(tl.float32)

    @triton.jit
    def _silu_grad(g, u, dy):
        dy = dy.to(tl.bfloat16).to(tl.float32)
        sig = tl.sigmoid(g)
        dg = (dy * u * sig * (1.0 + g * (1.0 - sig))).to(tl.bfloat16).to(tl.float32)
        du = (dy * g * sig).to(tl.bfloat16).to(tl.float32)
        return dg, du

    @triton.jit
    def _swiglu_rows_kernel(P, Q, S, I: tl.constexpr, BLOCK: tl.constexpr):
        row = tl.program_id(0)
        col = tl.arange(0, BLOCK)
        g = tl.load(P + row * (2 * I) + col, col < I, other=0).to(tl.float32)
        u = tl.load(P + row * (2 * I) + I + col, col < I, other=0).to(tl.float32)
        h = _silu_product(g, u)
        scale = tl.maximum(tl.div_rn(tl.max(tl.abs(h), 0), 448.0), 1.0 / (448.0 * 512))
        q = tl.minimum(tl.maximum(tl.div_rn(h, scale), -448.0), 448.0)
        tl.store(Q + row * I + col, q, col < I)
        tl.store(S + row, scale)

    @triton.jit(do_not_specialize=["M", "MP"])
    def _swiglu_transpose_kernel(P, QT, S, M, MP, I: tl.constexpr,
                                 RB: tl.constexpr, CB: tl.constexpr):
        MP = tl.multiple_of(MP, 16)
        rows = tl.program_id(0) * RB + tl.arange(0, RB)
        cols = tl.program_id(1) * CB + tl.arange(0, CB)
        valid = (rows[:, None] < M) & (cols[None, :] < I)
        g = tl.load(P + rows[:, None] * (2 * I) + cols[None, :], valid, other=0).to(tl.float32)
        u = tl.load(P + rows[:, None] * (2 * I) + I + cols[None, :], valid, other=0).to(tl.float32)
        h = _silu_product(g, u)
        q = tl.minimum(tl.maximum(h / tl.load(S), -448.0), 448.0)
        tl.store(QT + cols[None, :] * MP + rows[:, None], q,
                 (rows[:, None] < MP) & (cols[None, :] < I))

    @triton.jit(do_not_specialize=["N"])
    def _swiglu_grad_amax_kernel(P, DY, Partial, N, I: tl.constexpr, BLOCK: tl.constexpr):
        index = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
        row, col = index // I, index % I
        g = tl.load(P + row * (2 * I) + col, index < N, other=0).to(tl.float32)
        u = tl.load(P + row * (2 * I) + I + col, index < N, other=0).to(tl.float32)
        dy = tl.load(DY + index, index < N, other=0).to(tl.float32)
        dg, du = _silu_grad(g, u, dy)
        amax = tl.max(tl.maximum(tl.abs(dg), tl.abs(du)), 0)
        tl.store(Partial + tl.program_id(0), amax)

    @triton.jit(do_not_specialize=["M", "MP"])
    def _swiglu_grad_dual_kernel(P, DY, Q, QT, S, M, MP, I: tl.constexpr,
                                 RB: tl.constexpr, CB: tl.constexpr):
        MP = tl.multiple_of(MP, 16)
        rows = tl.program_id(0) * RB + tl.arange(0, RB)
        cols = tl.program_id(1) * CB + tl.arange(0, CB)
        valid = (rows[:, None] < M) & (cols[None, :] < I)
        g = tl.load(P + rows[:, None] * (2 * I) + cols[None, :], valid, other=0).to(tl.float32)
        u = tl.load(P + rows[:, None] * (2 * I) + I + cols[None, :], valid, other=0).to(tl.float32)
        dy = tl.load(DY + rows[:, None] * I + cols[None, :], valid, other=0).to(tl.float32)
        dg, du = _silu_grad(g, u, dy)
        scale = tl.load(S)
        qg = tl.minimum(tl.maximum(dg / scale, -57344.0), 57344.0)
        qu = tl.minimum(tl.maximum(du / scale, -57344.0), 57344.0)
        store = (rows[:, None] < MP) & (cols[None, :] < I)
        tl.store(Q + rows[:, None] * (2 * I) + cols[None, :], qg, store)
        tl.store(Q + rows[:, None] * (2 * I) + I + cols[None, :], qu, store)
        # Keep the transpose conversion separate from the row FP8 conversion.
        qgt = tl.inline_asm_elementwise(
            "mov.b32 $0, $1;", constraints="=f,f", args=[tl.trans(qg)],
            dtype=tl.float32, is_pure=False, pack=1)
        qut = tl.inline_asm_elementwise(
            "mov.b32 $0, $1;", constraints="=f,f", args=[tl.trans(qu)],
            dtype=tl.float32, is_pure=False, pack=1)
        tl.store(QT + cols[:, None] * MP + rows[None, :], qgt, tl.trans(store))
        tl.store(QT + (cols[:, None] + I) * MP + rows[None, :], qut, tl.trans(store))


def _activation(packed):
    gate, up = packed.chunk(2, -1)
    return base._swiglu_fwd(gate, up)


def _row_quant(packed):
    from rlforge import fp8

    if not packed.is_cuda:
        return fp8.quantize_rows(_activation(packed))
    rows, width = packed.shape[0], packed.shape[1] // 2
    q = torch.empty((rows, width), device=packed.device, dtype=torch.float8_e4m3fn)
    scales = torch.empty((rows, 1), device=packed.device, dtype=torch.float32)
    block = triton.next_power_of_2(width)
    _swiglu_rows_kernel[(rows,)](packed, q, scales, width, block, num_warps=4 if block <= 4096 else 8,
                                enable_fp_fusion=False)
    return q, scales


def _transpose_quant(packed, scale):
    from rlforge import fp8

    rows, width = packed.shape[0], packed.shape[1] // 2
    padded = (rows + 15) // 16 * 16
    if not packed.is_cuda:
        value = F.pad(_activation(packed), (0, 0, 0, padded - rows))
        return fp8._quantize_tensor(value, torch.float8_e4m3fn, transpose=True, scale=scale)[0]
    qt = torch.empty((width, padded), device=packed.device, dtype=torch.float8_e4m3fn)
    _swiglu_transpose_kernel[(triton.cdiv(padded, 32), triton.cdiv(width, 64))](
        packed, qt, scale, rows, padded, width, 32, 64, enable_fp_fusion=False)
    return qt


def _grad_quant(packed, down_grad):
    from rlforge import fp8

    rows, width = packed.shape[0], packed.shape[1] // 2
    if not packed.is_cuda:
        gate, up = packed.chunk(2, -1)
        dg, du = base._swiglu_bwd(gate, up, down_grad.to(torch.bfloat16))
        return fp8._quantize_dual(torch.cat((dg, du), -1), torch.float8_e5m2)
    padded = (rows + 15) // 16 * 16
    partial_count = triton.cdiv(rows * width, 4096)
    partial = torch.empty(partial_count, device=packed.device, dtype=torch.float32)
    scale = torch.empty((), device=packed.device, dtype=torch.float32)
    _swiglu_grad_amax_kernel[(partial_count,)](packed, down_grad, partial, rows * width, width, 4096,
                                             enable_fp_fusion=False)
    fp8._amax_scale_kernel[(1,)](partial, scale, partial_count, 57344.0,
                                  triton.next_power_of_2(partial_count))
    q = torch.empty((padded, 2 * width), device=packed.device, dtype=torch.float8_e5m2)
    qt = torch.empty((2 * width, padded), device=packed.device, dtype=torch.float8_e5m2)
    _swiglu_grad_dual_kernel[(triton.cdiv(padded, 32), triton.cdiv(width, 64))](
        packed, down_grad, q, qt, scale, rows, padded, width, 32, 64, enable_fp_fusion=False)
    return q[:rows], qt, scale


class _MLP(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, gate_weight, up_weight, down_weight, gq, gs, gtq, gts, dq, ds, dtq, dts):
        from rlforge import fp8

        ctx.set_materialize_grads(False)
        xc = x.reshape(-1, x.shape[-1]).to(torch.bfloat16).contiguous()
        xq, xs = fp8.quantize_rows(xc)
        packed = fp8.forward_mm(xq, gq, xs, gs)
        hq, hs = _row_quant(packed)
        output = fp8.forward_mm(hq, dq, hs, ds)
        ctx.save_for_backward(xc, xs, packed, hs, gtq, gts, dtq, dts)
        ctx.shape, ctx.x_dtype, ctx.gate_rows = x.shape, x.dtype, gate_weight.shape[0]
        return output.reshape(*x.shape[:-1], down_weight.shape[0])

    @staticmethod
    def backward(ctx, grad):
        from rlforge import fp8

        if grad is None:
            return (None,) * 12
        xc, xs, packed, hs, gtq, gts, dtq, dts = ctx.saved_tensors
        need_x, need_gate, need_up, need_down = ctx.needs_input_grad[:4]
        g = grad.reshape(-1, grad.shape[-1]).contiguous()
        gq, gqt, gscale = fp8._quantize_dual(g, torch.float8_e5m2)
        dx = dwg = dwu = dwd = None
        if need_down:
            hscale = hs.amax()
            hqt = _transpose_quant(packed, hscale)
            dwd = fp8.scaled_mm(gqt, hqt, gscale, hscale, out_dtype=torch.float32)
        if need_x or need_gate or need_up:
            dh = fp8.scaled_mm(gq, dtq, gscale, dts, out_dtype=torch.float32)
            pgq, pgqt, pgscale = _grad_quant(packed, dh)
            if need_x:
                dx = fp8.scaled_mm(pgq, gtq, pgscale, gts, out_dtype=torch.float32)
                dx = dx.to(ctx.x_dtype).reshape(ctx.shape)
            if need_gate or need_up:
                pad = (-xc.shape[0]) % 16
                xp = F.pad(xc, (0, 0, 0, pad)) if pad else xc
                xscale = xs.amax()
                xqt, _ = fp8._quantize_tensor(xp, torch.float8_e4m3fn, transpose=True, scale=xscale)
                dw = fp8.scaled_mm(pgqt, xqt, pgscale, xscale, out_dtype=torch.float32)
                dwg = dw[:ctx.gate_rows] if need_gate else None
                dwu = dw[ctx.gate_rows:] if need_up else None
        return dx, dwg, dwu, dwd, None, None, None, None, None, None, None, None


def _mlp_forward(self, x):
    from rlforge import fp8

    return _MLP.apply(x, self.gate_proj.weight, self.up_proj.weight, self.down_proj.weight,
                      *fp8._gate_up_cache(self), *fp8._weight_cache(self.down_proj))


def install_for_benchmark(policy, ref=None):
    import fusion_triton_head_prototype as combined

    restore = combined.install_for_benchmark(policy, ref=ref)
    for module in policy.modules():
        if type(module).__name__ not in ("Qwen3_5MLP", "Qwen3_5MoeMLP"):
            continue
        if module.config.hidden_act != "silu":
            continue
        if any(getattr(module, name).bias is not None for name in ("gate_proj", "up_proj", "down_proj")):
            raise ValueError("MLP fusion candidate requires bias-free projections")
        module.forward = MethodType(_mlp_forward, module)
    return restore


def primitive_gate(device):
    from rlforge import fp8

    torch.manual_seed(19)
    rows = []
    for count, width in ((1, 32), (31, 128), (904, 3584)):
        packed = torch.randn(count, 2 * width, device=device, dtype=torch.bfloat16) * 0.3
        grad = torch.randn(count, width, device=device, dtype=torch.float32) * 0.01
        h = _activation(packed)
        expected_q, expected_s = fp8.quantize_rows(h)
        actual_q, actual_s = _row_quant(packed)
        a = actual_q.float() * actual_s
        b = expected_q.float() * expected_s
        torch.testing.assert_close(a, b, rtol=0.02, atol=0.004)
        padded = (count + 15) // 16 * 16
        expected_t, _ = fp8._quantize_tensor(F.pad(h, (0, 0, 0, padded - count)),
                                             torch.float8_e4m3fn, transpose=True, scale=expected_s.amax())
        actual_t = _transpose_quant(packed, actual_s.amax())
        torch.testing.assert_close(actual_t.float() * actual_s.amax(), expected_t.float() * expected_s.amax(),
                                   rtol=0.02, atol=0.004)
        assert bool((actual_t[:, count:].float() == 0).all())
        gate, up = packed.chunk(2, -1)
        dg, du = base._swiglu_bwd(gate, up, grad.to(torch.bfloat16))
        reference_gq, _, reference_gs = fp8._quantize_dual(torch.cat((dg, du), -1), torch.float8_e5m2)
        gq, gqt, gs = _grad_quant(packed, grad)
        relative_l2 = float(torch.linalg.vector_norm(gq.float() * gs - reference_gq.float() * reference_gs) /
                            torch.linalg.vector_norm(reference_gq.float() * reference_gs).clamp_min(1e-12))
        assert relative_l2 < 0.005
        assert torch.equal(gq.float(), gqt[:, :count].T.float())
        assert bool((gqt[:, count:].float() == 0).all())
        rows.append({"rows": count, "intermediate": width, "forward_quant_close": True,
                     "gradient_dequant_relative_l2": relative_l2, "gradient_transpose_exact": True,
                     "padded_transposes_zero": True})
    return rows


def autograd_gate(device):
    from rlforge import fp8

    forward_mm, scaled_mm = fp8.forward_mm, fp8.scaled_mm

    def software_mm(a, b, sa, sb, *, out_dtype=torch.bfloat16):
        result = (a.float() @ b.float().T) * sa
        return (result * (sb.T if sb.ndim == 2 else sb)).to(out_dtype)

    if device.type == "cpu":
        fp8.forward_mm = lambda a, b, sa, sb: software_mm(a, b, sa, sb)
        fp8.scaled_mm = software_mm
    evidence = []
    try:
        for count in (7, 31):
            torch.manual_seed(19)
            x = torch.randn(count, 32, device=device, dtype=torch.bfloat16)
            gate_weight, up_weight = torch.randn(64, 32, device=device) * 0.03, torch.randn(64, 32, device=device) * 0.03
            down_weight = torch.randn(32, 64, device=device) * 0.03
            upstream = torch.randn_like(x)
            arms = []
            for fused in (False, True):
                xx, gw, uw, dw = [t.detach().clone().requires_grad_() for t in (x, gate_weight, up_weight, down_weight)]
                gc, dc = torch.nn.Module(), torch.nn.Module()
                gc.gate_proj, gc.up_proj = torch.nn.Module(), torch.nn.Module()
                gc.gate_proj.weight, gc.up_proj.weight, dc.weight = gw, uw, dw
                caches = (*fp8._gate_up_cache(gc), *fp8._weight_cache(dc))
                if fused:
                    y = _MLP.apply(xx, gw, uw, dw, *caches)
                else:
                    packed = fp8._FP8GateUp.apply(xx, gw, uw, *caches[:4])
                    gate, up = packed.chunk(2, -1)
                    hidden = base._SwiGLU.apply(gate, up)
                    y = fp8._FP8Linear.apply(hidden, dw, None, *caches[4:])
                gradients = torch.autograd.grad(y, (xx, gw, uw, dw), upstream)
                arms.append((y.detach(), [g.detach() for g in gradients]))
                assert all(g.dtype == torch.float32 and bool(torch.isfinite(g).all()) for g in gradients[1:])
            torch.testing.assert_close(arms[0][0], arms[1][0], rtol=0.025, atol=0.001)
            metrics = []
            for expected, actual in zip(arms[0][1], arms[1][1]):
                relative = float(torch.linalg.vector_norm(actual.float() - expected.float()) /
                                 torch.linalg.vector_norm(expected.float()).clamp_min(1e-12))
                cosine = float(F.cosine_similarity(actual.float().flatten(), expected.float().flatten(), dim=0))
                assert relative < 0.01 and cosine > 0.9999
                metrics.append({"relative_l2": relative, "cosine": cosine, "exact": torch.equal(expected, actual)})
            evidence.append({"rows": count, "forward_exact": torch.equal(arms[0][0], arms[1][0]),
                             "gradients": metrics, "master_gradients_fp32": True})
    finally:
        fp8.forward_mm, fp8.scaled_mm = forward_mm, scaled_mm
    return evidence


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--cpu-gate", action="store_true")
    parser.add_argument("--gpu-gate", action="store_true")
    parser.add_argument("--code", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    import sys

    sys.path.insert(0, args.code)
    torch.set_num_threads(1)
    device = torch.device("cuda" if args.gpu_gate else "cpu")
    result = {"scope": "fused MLP quantization primitives; CPU autograd uses software GEMM",
              "gpu_tested": args.gpu_gate, "primitives": primitive_gate(device),
              "autograd": autograd_gate(device),
              "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    Path(args.output).write_text(json.dumps(result, indent=2))
    print(json.dumps(result), flush=True)
