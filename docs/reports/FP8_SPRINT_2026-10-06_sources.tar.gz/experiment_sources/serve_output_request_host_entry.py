"""Future per-request output candidate on frozen native host observation recipe."""
import serve_kv_partial_host_entry
import serving_output_request_prototype as loop
from vllm.v1.engine.core import EngineCore

loop.install()
native_rpc=EngineCore.collective_rpc


def collective_rpc(self,method,timeout=None,args=(),kwargs=None):
    if method=='sprint_output_request_stats':
        return [loop.stats()]
    if method=='sprint_output_request_toggle':
        return [loop.toggle(args[0]=='1')]
    return native_rpc(self,method,timeout,args,kwargs)


EngineCore.collective_rpc=collective_rpc
if __name__=='__main__':
    serve_kv_partial_host_entry.serve_host_timeline_entry.serve_cpu_ssm_entry.serve_pause_observed_entry.serve_kv_bandwidth_entry.serve_kv_observed_entry.serve_driver.main()
