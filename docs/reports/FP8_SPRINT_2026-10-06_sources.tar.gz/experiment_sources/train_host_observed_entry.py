"""Run the frozen sprint entry with optional per-rank host attribution."""
import ast
import hashlib
import json
import os
import runpy
from pathlib import Path


def install():
    from trl.experimental.async_grpo import AsyncGRPOTrainer
    from trainer_host_observer import install_for_trainer

    original_train = AsyncGRPOTrainer.train

    def train(self, *args, **kwargs):
        client = self._ref_model if hasattr(self._ref_model, "stats") else None
        output = Path(os.environ["SCALE_OUT"]) / ("host_rank" + os.environ.get("RANK", "0") + ".json")
        restore = install_for_trainer(self, client, output=output)
        print(json.dumps({"host_observer": {"event": "installed",
              "rank": int(os.environ.get("RANK", "0")),
              "trainer_class": type(self).__module__ + "." + type(self).__qualname__,
              "entry_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "reference_stats_attached": client is not None}}), flush=True)
        try:
            return original_train(self, *args, **kwargs)
        finally:
            restore()

    AsyncGRPOTrainer.train = train


def main():
    path = Path(__file__).with_name("train_sprint_entry.py")
    if os.environ.get("SCALE_TRAIN_CHILD") == "1":
        install()
        runpy.run_path(str(path), run_name="__main__")
        return
    tree = ast.parse(path.read_text())
    namespace = {"__name__": "__main__", "__file__": str(Path(__file__)),
                 "__package__": None, "__builtins__": __builtins__}
    exec(compile(tree, str(path), "exec"), namespace)


if __name__ == "__main__":
    main()
