"""Compose deferred infinite dispatch with the frozen exact cache/JSON entry."""
import ast
import hashlib
import json
import os
from pathlib import Path


def main():
    if __name__ == '__main__' and os.environ.get('SCALE_TRAIN_CHILD') == '1':
        import dispatcher_defer_prototype as dispatcher
        metadata = dispatcher.install()
        print(json.dumps(dict(deferred_dispatch=dict(event='installed', rank=int(os.environ.get('RANK', '0')),
              metadata=metadata, source_sha256=hashlib.sha256(Path(dispatcher.__file__).read_bytes()).hexdigest(),
              entry_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))), flush=True)
    path = Path(__file__).with_name('train_prompt_cache_json_host_entry.py')
    namespace = dict(__name__=__name__, __file__=str(Path(__file__)),
                     __package__=None, __builtins__=__builtins__)
    exec(compile(ast.parse(path.read_text()), str(path), 'exec'), namespace)


if __name__ in ('__main__', '__mp_main__'):
    main()
