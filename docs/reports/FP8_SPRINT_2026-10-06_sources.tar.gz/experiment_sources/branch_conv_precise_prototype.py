"""Compact native branch convolution reading the shared prompt tail directly.

Preserves eager FP32 SiLU and the connected prompt gradient. Avoids wide
tail concatenation, output slicing and the convolution-gradient layout copy.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from types import MethodType

import torch
import torch.nn.functional as F
import fusion_conv_prototype as compact
import fusion_conv_precise_prototype as precise

triton, tl = compact.triton, compact.tl


if triton is not None:
    @triton.jit(do_not_specialize=["N", "L"])
    def _forward_kernel(X, Tail, W, Bias, Pre, N, L, C: tl.constexpr,
                        XS0, XS1, XS2, TS0, TS1, TS2, SHARED: tl.constexpr,
                        HAS_BIAS: tl.constexpr, BLOCK: tl.constexpr):
        index = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
        b, t, c = compact._index(index, L, C, True)
        value = tl.full((BLOCK,), 0.0, tl.float32)
        for tap in tl.static_range(4):
            pos = t + tap - 3
            x = tl.load(X + b * XS0 + c * XS1 + pos * XS2, (index < N) & (pos >= 0), other=0).to(tl.float32)
            tail_batch = 0 if SHARED else b
            tail = tl.load(Tail + tail_batch * TS0 + c * TS1 + (pos + 3) * TS2,
                           (index < N) & (pos < 0), other=0).to(tl.float32)
            w = tl.load(W + c * 4 + tap, index < N, other=0).to(X.dtype.element_ty).to(tl.float32)
            value = value + ((x + tail) * w).to(X.dtype.element_ty).to(tl.float32)
        if HAS_BIAS:
            value = value + tl.load(Bias + c, index < N, other=0).to(X.dtype.element_ty).to(tl.float32)
        tl.store(Pre + index, value, index < N)

    @triton.jit(do_not_specialize=["Rows", "L"])
    def _dw_kernel(X, Tail, G, PartialW, PartialB, Rows, L, C: tl.constexpr,
                   XS0, XS1, XS2, TS0, TS1, TS2, SHARED: tl.constexpr,
                   HAS_BIAS: tl.constexpr, RB: tl.constexpr, CB: tl.constexpr):
        group = tl.program_id(0)
        row = group * RB + tl.arange(0, RB)
        c = tl.program_id(1) * CB + tl.arange(0, CB)
        b, t = row // L, row % L
        valid = (row[:, None] < Rows) & (c[None, :] < C)
        upstream = tl.load(G + row[:, None] * C + c[None, :], valid, other=0)
        grad = upstream.to(X.dtype.element_ty).to(tl.float32)
        for tap in tl.static_range(4):
            pos = t + tap - 3
            x = tl.load(X + b[:, None] * XS0 + c[None, :] * XS1 + pos[:, None] * XS2,
                        valid & (pos[:, None] >= 0), other=0).to(tl.float32)
            tail_batch = tl.full((RB,), 0, tl.int32) if SHARED else b
            tail = tl.load(Tail + tail_batch[:, None] * TS0 + c[None, :] * TS1 + (pos[:, None] + 3) * TS2,
                           valid & (pos[:, None] < 0), other=0).to(tl.float32)
            partial = tl.sum(grad * (x + tail), 0)
            tl.store(PartialW + (group * C + c) * 4 + tap, partial, c < C)
        if HAS_BIAS:
            tl.store(PartialB + group * C + c, tl.sum(upstream, 0), c < C)

    @triton.jit(do_not_specialize=["L"])
    def _dtail_kernel(G, W, DT, L, C: tl.constexpr, B: tl.constexpr,
                      SHARED: tl.constexpr, BB: tl.constexpr, CB: tl.constexpr):
        c = tl.program_id(0) * CB + tl.arange(0, CB)
        batch = tl.arange(0, BB) if SHARED else tl.full((1,), tl.program_id(1), tl.int32)
        valid = (batch[:, None] < B) & (c[None, :] < C)
        for tail_index in tl.static_range(3):
            value = tl.full((BB if SHARED else 1, CB), 0.0, tl.float32)
            for tap in tl.static_range(4):
                pos = tail_index - tap
                if pos >= 0:
                    grad = tl.load(G + (batch[:, None] * L + pos) * C + c[None, :],
                                   valid & (pos < L), other=0).to(tl.bfloat16).to(tl.float32)
                    weight = tl.load(W + c[None, :] * 4 + tap, c[None, :] < C, other=0).to(tl.bfloat16).to(tl.float32)
                    value = value + grad * weight
            value = value.to(tl.bfloat16).to(tl.float32)
            if SHARED:
                result = tl.sum(value, 0)
                tl.store(DT + c * 3 + tail_index, result, c < C)
            else:
                tl.store(DT + (batch[:, None] * C + c[None, :]) * 3 + tail_index, value, valid)


def _preactivation(x, tail, weight, bias):
    if not x.is_cuda:
        joined = torch.cat((tail.expand(x.shape[0], -1, -1), x), -1)
        return compact._cpu_pre(joined, weight, bias)[..., -x.shape[-1]:]
    batch, channels, length = x.shape
    pre = torch.empty((batch, length, channels), device=x.device, dtype=torch.float32).transpose(1, 2)
    _forward_kernel[(triton.cdiv(x.numel(), 256),)](
        x, tail, weight, bias if bias is not None else x, pre, x.numel(), length, channels,
        *x.stride(), *tail.stride(), tail.shape[0] == 1, bias is not None, 256, enable_fp_fusion=False)
    return pre


class _BranchConv(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, tail, weight, bias):
        ctx.set_materialize_grads(False)
        ctx.save_for_backward(x, tail, weight, bias)
        return F.silu(_preactivation(x, tail, weight, bias)).to(x.dtype)

    @staticmethod
    def backward(ctx, grad):
        if grad is None:
            return None, None, None, None
        x, tail, weight, bias = ctx.saved_tensors
        need_x, need_t, need_w, need_b = ctx.needs_input_grad
        upstream = torch.ops.aten.silu_backward(grad.float(), _preactivation(x, tail, weight, bias))
        batch, channels, length = x.shape
        dx = dt = dw = db = None
        if not x.is_cuda:
            g = upstream.to(x.dtype).float()
            wf = weight.to(x.dtype).float()
            if need_x:
                dx = torch.zeros_like(x, dtype=torch.float32)
                for tap in range(4):
                    delay = 3 - tap
                    if delay < length:
                        dx[..., :length - delay] += g[..., delay:] * wf[:, tap][None, :, None]
                dx = dx.to(x.dtype)
            if need_t:
                dt_full = torch.zeros(batch, channels, 3, dtype=torch.float32, device=x.device)
                for ti in range(3):
                    for tap in range(4):
                        pos = ti - tap
                        if 0 <= pos < length:
                            dt_full[..., ti] += g[..., pos] * wf[:, tap]
                dt_full = dt_full.to(tail.dtype)
                dt = dt_full.sum(0, keepdim=True) if tail.shape[0] == 1 else dt_full
            if need_w:
                joined = torch.cat((tail.expand(batch, -1, -1), x), -1).float()
                dw = torch.stack([(g * joined[..., tap:tap + length]).sum((0, 2)) for tap in range(4)], -1)
                dw = dw.to(x.dtype).to(weight.dtype)
            if need_b:
                db = upstream.sum((0, 2)).to(x.dtype).to(bias.dtype)
            return dx, dt, dw, db
        upstream = upstream.transpose(1, 2).contiguous().transpose(1, 2)
        if need_x:
            dx = torch.empty_like(upstream, dtype=x.dtype)
            compact._dx_kernel[(triton.cdiv(x.numel(), 256),)](
                upstream, weight, dx, x.numel(), length, channels, tl.bfloat16, True, 256, enable_fp_fusion=False)
        if need_t:
            dt = torch.empty_like(tail, memory_format=torch.contiguous_format)
            shared = tail.shape[0] == 1
            _dtail_kernel[(triton.cdiv(channels, 32), 1 if shared else batch)](
                upstream, weight, dt, length, channels, batch, shared, triton.next_power_of_2(batch) if shared else 1,
                32, enable_fp_fusion=False)
        if need_w or need_b:
            groups = triton.cdiv(batch * length, 128)
            partial_w = torch.empty((groups, channels, 4), device=x.device, dtype=torch.float32)
            partial_b = torch.empty((groups, channels), device=x.device, dtype=torch.float32) if need_b else partial_w
            _dw_kernel[(groups, triton.cdiv(channels, 16))](
                x, tail, upstream, partial_w, partial_b, batch * length, length, channels,
                *x.stride(), *tail.stride(), tail.shape[0] == 1, need_b, 128, 16, enable_fp_fusion=False)
            if need_w:
                dw = partial_w.sum(0).to(x.dtype).to(weight.dtype)
            if need_b:
                db = partial_b.sum(0).to(x.dtype).to(bias.dtype)
        return dx, dt, dw, db


def branch_conv(x, tail, weight, bias=None):
    if x.dtype != torch.bfloat16 or weight.shape != (x.shape[1], 4) or tail.shape[-2:] != (x.shape[1], 3):
        raise ValueError("Branch convolution requires BF16 and four taps")
    return _BranchConv.apply(x, tail, weight, bias)


def _forward(self, hidden_states, cache_params=None, attention_mask=None, **kwargs):
    from rlforge import fp8_alignment as alignment, prefix_share as ps
    from transformers.models.qwen3_5 import modeling_qwen3_5 as mq

    previous = cache_params is not None and cache_params.has_previous_state(self.layer_idx, state_idx=0)
    tail = getattr(cache_params, "conv_tail", None) if previous else None
    supported = (previous and hidden_states.shape[1] > 1 and self.conv_kernel_size == 4
                 and isinstance(tail, torch.Tensor) and tail.shape[-1] == 3
                 and hidden_states.dtype == torch.bfloat16
                 and self.activation in ("silu", "swish"))
    if not supported:
        return self._branch_conv_original(
            hidden_states, cache_params=cache_params, attention_mask=attention_mask, **kwargs)
    batch, length, _ = hidden_states.shape
    hidden_states = mq.apply_mask_to_padding_states(hidden_states, attention_mask)
    qkv = self.in_proj_qkv(hidden_states).transpose(1, 2)
    z = self.in_proj_z(hidden_states).reshape(batch, length, -1, self.head_v_dim)
    b, a = self.in_proj_b(hidden_states), self.in_proj_a(hidden_states)
    tail = tail.detach() if ps._DETACH else tail
    qkv = branch_conv(qkv, tail, self.conv1d.weight.squeeze(1), self.conv1d.bias).transpose(1, 2)
    q, k, v = qkv.split([self.key_dim, self.key_dim, self.value_dim], dim=-1)
    q, k = q.reshape(batch, length, -1, self.head_k_dim), k.reshape(batch, length, -1, self.head_k_dim)
    v = v.reshape(batch, length, -1, self.head_v_dim)
    q, k, beta, g = alignment._gdn_prepare(q, k, b, a, self.A_log, self.dt_bias)
    repeats = self.num_v_heads // self.num_k_heads
    if repeats > 1:
        q, k = q.repeat_interleave(repeats, dim=2), k.repeat_interleave(repeats, dim=2)
    state = cache_params.layers[self.layer_idx].recurrent_states[0]
    out, final = mq.torch_chunk_gated_delta_rule(
        q, k, v, g=g, beta=beta, initial_state=state, output_final_state=True,
        use_qk_l2norm_in_kernel=False, cu_seqlens=kwargs.pop("cu_seq_lens_q", None), **kwargs)
    cache_params.update_recurrent_state(final, self.layer_idx)
    out = self.norm(out.reshape(-1, self.head_v_dim), z.reshape(-1, self.head_v_dim))
    return self.out_proj(out.reshape(batch, length, -1))


def install_for_benchmark(policy, ref=None):
    from transformers.models.qwen3_5 import modeling_qwen3_5 as mq

    restore_precise = precise.install_for_benchmark(policy, ref=ref)
    originals = []
    for module in policy.modules():
        if isinstance(module, mq.Qwen3_5GatedDeltaNet):
            originals.append((module, module.forward))
            module._branch_conv_original = module.forward
            module.forward = MethodType(_forward, module)

    def restore():
        for module, original in originals:
            module.forward = original
            del module._branch_conv_original
        restore_precise()

    return restore


def primitive_gate(device):
    torch.manual_seed(19)
    evidence = []
    for batch, channels, length in ((1, 7, 1), (3, 16, 2), (13, 32, 17), (12, 6144, 1770)):
        for shared in (False, True):
            x = torch.randn(batch, length, channels, dtype=torch.bfloat16, device=device).transpose(1, 2)
            tail = torch.randn(1 if shared else batch, channels, 3, dtype=torch.bfloat16, device=device)
            weight = torch.randn(channels, 4, device=device) * 0.2
            upstream = torch.randn_like(x) * 0.01
            values = []
            for candidate in (False, True):
                xx, tt, ww = [t.clone().requires_grad_() for t in (x, tail, weight)]
                if candidate:
                    out = branch_conv(xx, tt, ww)
                else:
                    joined = torch.cat((tt.expand(batch, -1, -1), xx), -1)
                    out = F.silu(compact._cpu_pre(joined, ww, None))[..., -length:].to(x.dtype)
                grads = torch.autograd.grad(out, (xx, tt, ww), upstream)
                values.append((out.detach(), [g.detach() for g in grads]))
            assert torch.equal(values[0][0], values[1][0])
            errors = []
            for expected, actual in zip(values[0][1], values[1][1]):
                difference = actual.float() - expected.float()
                relative = float(difference.norm() / expected.float().norm().clamp_min(1e-12))
                errors.append({"exact": torch.equal(expected, actual), "relative_l2": relative,
                               "max_abs": float(difference.abs().max())})
                assert relative < 0.01
            assert values[1][1][-1].dtype == torch.float32
            evidence.append({"shape": list(x.shape), "shared_tail": shared, "forward_exact": True,
                             "gradients": errors, "master_gradient_fp32": True})
    return {"scope": str(device) + " separate-tail compact convolution against concat/eager FP32 SiLU",
            "cases": evidence, "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--gpu", action="store_true")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    result = primitive_gate(torch.device("cuda" if args.gpu else "cpu"))
    Path(args.output).write_text(json.dumps(result, indent=2))
    print(json.dumps({"passed": len(result["cases"]), "source_sha256": result["source_sha256"]}))
