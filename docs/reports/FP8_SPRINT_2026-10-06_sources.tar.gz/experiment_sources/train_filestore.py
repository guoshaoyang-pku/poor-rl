import os
import pathlib
import runpy
import subprocess
import sys
import time


if __name__ == "__main__":
    if os.environ.get("SCALE_TRAIN_CHILD") == "1":
        import torch.distributed as dist

        original_init = dist.init_process_group

        def init_process_group(*args, **kwargs):
            if not dist.is_initialized() and kwargs.get("store") is None:
                kwargs.pop("init_method", None)
                kwargs["store"] = dist.FileStore(os.environ["SCALE_DDP_STORE"], 4)
                kwargs["rank"] = int(os.environ["RANK"])
                kwargs["world_size"] = 4
            return original_init(*args, **kwargs)

        dist.init_process_group = init_process_group
        if os.environ.get("SPRINT_TRAIN_ARM", "strict") != "strict":
            from rlforge import fp8, fp8_alignment
            original_install = fp8.install
            def install(model, *args, **kwargs):
                installed = original_install(model, *args, **kwargs)
                prototypes = os.environ.get("SPRINT_TRAIN_PROTOTYPES", "")
                if prototypes:
                    fp8_alignment.install(model, gdn=True)
                else:
                    fp8_alignment.install(model, embedding=True, norm=False, gated_norm=False, gdn=False)
                if prototypes:
                    import importlib
                    for prototype in prototypes.split(","):
                        importlib.import_module(prototype).install_for_benchmark(model)
                return installed
            fp8.install = install
        runpy.run_module("rlforge.trainer", run_name="__main__")
    else:
        store = pathlib.Path(os.environ["SCALE_OUT"]) / "ddp.store"
        assert not store.exists()
        children = []
        for rank in range(4):
            env = dict(os.environ, RANK=str(rank), LOCAL_RANK=str(rank), WORLD_SIZE="4",
                       LOCAL_WORLD_SIZE="4", MASTER_ADDR="127.0.0.1", MASTER_PORT="29539",
                       SCALE_TRAIN_CHILD="1", SCALE_DDP_STORE=str(store))
            children.append(subprocess.Popen([sys.executable, __file__, *sys.argv[1:]], env=env))
        while any(child.poll() is None for child in children):
            failure = next((child.returncode for child in children
                            if child.returncode not in (None, 0)), None)
            if failure is not None:
                for child in children:
                    if child.poll() is None:
                        child.terminate()
                for child in children:
                    try:
                        child.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        child.kill()
                raise SystemExit(failure)
            time.sleep(1)
        statuses = [child.wait() for child in children]
        raise SystemExit(next((status for status in statuses if status), 0))
