"""Keep native trainer vetting and install exact prompt caching in the spawned rollout."""
import ast
import hashlib
import json
import os
from pathlib import Path


if __name__ == '__main__' and os.environ.get('SCALE_TRAIN_CHILD') == '1':
    from multiprocessing import spawn

    native_preparation_data = spawn.get_preparation_data

    def get_preparation_data(name):
        data = native_preparation_data(name)
        if name == 'grpo-rollout-worker-child':
            data.pop('init_main_from_name', None)
            data['init_main_from_path'] = str(Path(__file__).resolve())
        return data

    spawn.get_preparation_data = get_preparation_data


if __name__ == '__mp_main__':
    import rollout_prompt_cache_prototype as cache
    from trl.experimental.async_grpo import async_rollout_worker as native

    installed = cache.install()
    native_run = native._AsyncRolloutLoop.run

    def run(self):
        try:
            return native_run(self)
        finally:
            print(json.dumps(dict(prompt_cache=dict(
                event='final', pid=os.getpid(),
                counters=getattr(self, '_sprint_prompt_cache_stats', {}),
                remaining_groups=len(getattr(self, '_sprint_prompt_cache', {}))))), flush=True)

    native._AsyncRolloutLoop.run = run
    print(json.dumps(dict(prompt_cache=dict(
        event='spawn_child_installed', pid=os.getpid(), metadata=installed,
        source_sha256=hashlib.sha256(Path(cache.__file__).read_bytes()).hexdigest(),
        entry_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))), flush=True)


def main():
    path = Path(__file__).with_name('train_collator_host_entry.py')
    namespace = dict(__name__='__main__', __file__=str(Path(__file__)),
                     __package__=None, __builtins__=__builtins__)
    exec(compile(ast.parse(path.read_text()), str(path), 'exec'), namespace)


if __name__ == '__main__':
    main()
