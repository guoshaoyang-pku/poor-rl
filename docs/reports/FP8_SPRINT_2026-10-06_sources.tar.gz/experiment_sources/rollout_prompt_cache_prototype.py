"""Reuse exact first-turn prompt tokenization within one native rollout group."""
import ast
import copy
import hashlib
import inspect
import json
import textwrap
import time
from collections import OrderedDict


def initial_prompt_ids(loop, messages, rollout_tools, group_id, iteration_num, **kwargs):
    native = loop.tokenizer.apply_chat_template
    if iteration_num or rollout_tools or loop.environment_factories is not None:
        return native(messages, **kwargs)
    if not hasattr(loop, '_sprint_prompt_cache'):
        loop._sprint_prompt_cache = OrderedDict()
        loop._sprint_prompt_cache_stats = dict(hits=0, misses=0, native_ns=0,
                                             cached_ns=0, mismatches=0)
    cache = loop._sprint_prompt_cache
    stats = loop._sprint_prompt_cache_stats
    started = time.perf_counter_ns()
    previous = cache.get(group_id)
    if previous is not None and previous[0] == messages and previous[1] == kwargs:
        previous[3] += 1
        tokens = list(previous[2])
        stats['hits'] += 1
        stats['cached_ns'] += time.perf_counter_ns() - started
        if previous[3] == loop.num_generations:
            del cache[group_id]
        return tokens
    if previous is not None:
        stats['mismatches'] += 1
    tokens = native(messages, **kwargs)
    stats['native_ns'] += time.perf_counter_ns() - started
    stats['misses'] += 1
    if isinstance(tokens, list) and all(isinstance(x, int) for x in tokens):
        cache[group_id] = [copy.deepcopy(messages), copy.deepcopy(kwargs), list(tokens), 1]
        limit = max(16, 2 * loop.max_inflight_tasks // loop.num_generations)
        while len(cache) > limit:
            cache.popitem(last=False)
    return tokens


def transform(source):
    tree = ast.parse(textwrap.dedent(source))
    method = tree.body[0]
    assert isinstance(method, ast.AsyncFunctionDef) and method.name == '_generate_one'
    calls = [n for n in ast.walk(method) if isinstance(n, ast.Call)
             and isinstance(n.func, ast.Attribute) and n.func.attr == 'apply_chat_template']
    assert len(calls) == 1
    call = calls[0]
    assert ast.unparse(call.func) == 'self.tokenizer.apply_chat_template'
    assert len(call.args) == 1 and ast.unparse(call.args[0]) == 'messages'
    call.func = ast.Name(id='_sprint_initial_prompt_ids', ctx=ast.Load())
    call.args = [ast.Name(id=name, ctx=ast.Load())
                 for name in ['self', 'messages', 'tools', 'group_id', 'iteration_num']]
    return ast.fix_missing_locations(tree)


def install():
    from trl.experimental.async_grpo import async_rollout_worker as native
    cls = native._AsyncRolloutLoop
    if getattr(cls, '_sprint_prompt_cache_installed', False):
        return {'already_installed': True}
    source = inspect.getsource(cls._generate_one)
    namespace = dict(vars(native), _sprint_initial_prompt_ids=initial_prompt_ids)
    exec(compile(transform(source), '<poor-rl exact group prompt cache>', 'exec'), namespace)
    cls._generate_one = namespace['_generate_one']
    cls._sprint_prompt_cache_installed = True
    return {'native_method_sha256': hashlib.sha256(source.encode()).hexdigest(),
            'first_turn_only': True, 'tools_environments_native_fallback': True}


def cpu_gate():
    from types import SimpleNamespace

    class Tokenizer:
        calls = 0

        def apply_chat_template(self, messages, **kwargs):
            self.calls += 1
            return list(json.dumps([messages, kwargs], sort_keys=True).encode())

    tok = Tokenizer()
    loop = SimpleNamespace(tokenizer=tok, environment_factories=None, num_generations=32,
                           max_inflight_tasks=3072)
    kwargs = dict(return_dict=False, add_generation_prompt=True, tools=None, chat_template='v1')
    messages = [{'role': 'user', 'content': 'fixed prompt'}]
    expected = tok.apply_chat_template(messages, **kwargs)
    before = tok.calls
    outputs = [initial_prompt_ids(loop, messages, [], 7, 0, **kwargs) for _ in range(32)]
    assert all(x == expected for x in outputs) and tok.calls - before == 1
    assert len(set(map(id, outputs))) == 32 and not loop._sprint_prompt_cache
    outputs[0].append(999)
    assert outputs[1] == expected
    checks = ['exact_32_outputs_one_tokenization', 'distinct_mutable_lists', 'group_cache_released']
    for changed in [dict(kwargs, add_generation_prompt=False), dict(kwargs, chat_template='v2')]:
        initial_prompt_ids(loop, messages, [], 8, 0, **kwargs)
        result = initial_prompt_ids(loop, messages, [], 8, 0, **changed)
        assert result == tok.apply_chat_template(messages, **changed)
    changed_messages = [{'role': 'user', 'content': 'new'}]
    assert initial_prompt_ids(loop, changed_messages, [], 8, 0, **kwargs) == tok.apply_chat_template(changed_messages, **kwargs)
    checks += ['changed_template_kwargs_native', 'changed_messages_native']
    for iteration, tools, env in [(1, [], None), (0, ['tool'], None), (0, [], {'env': object()})]:
        loop.environment_factories = env
        before = tok.calls
        initial_prompt_ids(loop, messages, tools, 9, iteration, **kwargs)
        assert tok.calls == before + 1
    checks.append('later_turns_tools_environments_native')
    from trl.experimental.async_grpo import async_rollout_worker as native
    source = inspect.getsource(native._AsyncRolloutLoop._generate_one)
    transformed = transform(source)
    calls = [ast.unparse(n.func) for n in ast.walk(transformed) if isinstance(n, ast.Call)]
    assert calls.count('_sprint_initial_prompt_ids') == 1 and calls.count('self._generate_one_turn') == 1
    assert calls.count('parse_response') == 1 and calls.count('_chain_to_sequences') == 1
    compile(transformed, '<gate>', 'exec')
    checks.append('native_http_parse_sequence_calls_preserved')
    return {'passed': True, 'checks': checks, 'check_count': len(checks),
            'scope': 'CPU exact cache semantics and installed native AST; no GPU or generation probe'}


if __name__ == '__main__':
    print(json.dumps(cpu_gate(), indent=2))
