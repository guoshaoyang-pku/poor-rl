"""Future current CPU serving recipe with exact partial-prefix/no-op KV proof."""
import serve_cpu_ssm_entry
import serving_kv_partial_proof_prototype as proof
from vllm.v1.engine.core import EngineCore

proof.install()
native_rpc = EngineCore.collective_rpc


def collective_rpc(self, method, timeout=None, args=(), kwargs=None):
    if method == 'sprint_kv_partial_proof_stats':
        return [proof.stats()]
    if method == 'sprint_kv_partial_proof_toggle':
        return [proof.toggle(args[0] == '1')]
    return native_rpc(self, method, timeout, args, kwargs)


EngineCore.collective_rpc = collective_rpc
if __name__ == '__main__':
    serve_cpu_ssm_entry.serve_pause_observed_entry.serve_kv_bandwidth_entry.serve_kv_observed_entry.serve_driver.main()
