"""Exact KV cache bookkeeping with the existing dedicated serving control."""
import serve_cpu_dedicated_entry
import serve_kv_partial_proof_entry

if __name__ == "__main__":
    serve_cpu_dedicated_entry.serve_dedicated_control_entry.serve_control_observed_entry.serve_pause_observed_entry.serve_kv_bandwidth_entry.serve_kv_observed_entry.serve_driver.main()
