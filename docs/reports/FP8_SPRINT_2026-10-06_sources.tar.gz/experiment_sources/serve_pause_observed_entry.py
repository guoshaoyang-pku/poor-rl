"""Future native-serving entry with bounded per-rank pause logs."""
import serving_pause_observer as observer

observer.install()
import serve_kv_bandwidth_entry
from vllm.v1.engine.core import EngineCore

native_rpc = EngineCore.collective_rpc


def collective_rpc(self, method, timeout=None, args=(), kwargs=None):
    if method == 'sprint_pause_stats':
        return [observer.stats()]
    return native_rpc(self, method, timeout, args, kwargs)


EngineCore.collective_rpc = collective_rpc
if __name__ == '__main__':
    serve_kv_bandwidth_entry.serve_kv_observed_entry.serve_driver.main()
