"""Compose exact reference wire encoding with the frozen group-tail trainer."""
import ast
import hashlib
import json
import os
from pathlib import Path

if __name__ in ('__main__', '__mp_main__'):
    import reference_payload_encoder_prototype as encoder
    encoder.install()
    print(json.dumps(dict(reference_payload_encoder=dict(
        pid=os.getpid(), entry=__name__,
        source_sha256=hashlib.sha256(Path(encoder.__file__).read_bytes()).hexdigest(),
        stats=encoder.stats()))), flush=True)
    path = Path(__file__).with_name('train_group_tail_v5_entry.py')
    namespace = dict(__name__=__name__, __file__=str(Path(__file__)),
                     __package__=None, __builtins__=__builtins__)
    exec(compile(ast.parse(path.read_text()), str(path), 'exec'), namespace)
