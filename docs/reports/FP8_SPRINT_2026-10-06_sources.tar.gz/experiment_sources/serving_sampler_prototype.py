"""Process-only parallel sampled-token logprob/rank for vLLM's GPU runner."""
import json
import os

import torch
import triton
import triton.language as tl

_INSTALLED = False
_ORIGINAL_TOPK = None
_FAST_TOPK = None
_COUNTS = {'fast': 0, 'fallback': 0}
_FRONTEND_COUNTS = {'token_ids_only': 0, 'regular': 0}
_FRONTEND_INSTALLED = False
_CPU_PROFILE_STATE = None


@triton.jit
def _partial_scores(LOGITS, TOKENS, MAXIMA, SUMS, RANKS,
                    STRIDE: tl.constexpr, V: tl.constexpr,
                    TILES: tl.constexpr, BLOCK: tl.constexpr):
    row, tile = tl.program_id(0).to(tl.int64), tl.program_id(1)
    ids = tile * BLOCK + tl.arange(0, BLOCK)
    x = tl.load(LOGITS + row * STRIDE + ids, ids < V,
                other=-float('inf')).to(tl.float32)
    token = tl.load(TOKENS + row)
    selected = tl.load(LOGITS + row * STRIDE + token).to(tl.float32)
    mx = tl.max(x, 0)
    mass = tl.sum(tl.exp(x - mx), 0)
    rank = tl.sum(((ids < V) & (x >= selected)).to(tl.int32), 0)
    off = row * TILES + tile
    tl.store(MAXIMA + off, mx)
    tl.store(SUMS + off, mass)
    tl.store(RANKS + off, rank)


@triton.jit
def _finish_scores(LOGITS, TOKENS, MAXIMA, SUMS, RANKS, LOGPROBS, TOKEN_RANKS,
                   STRIDE: tl.constexpr, V: tl.constexpr,
                   TILES: tl.constexpr, BLOCK: tl.constexpr):
    row = tl.program_id(0).to(tl.int64)
    tiles = tl.arange(0, BLOCK)
    off = row * TILES + tiles
    mx = tl.load(MAXIMA + off, tiles < TILES, other=-float('inf'))
    mass = tl.load(SUMS + off, tiles < TILES, other=0)
    ranks = tl.load(RANKS + off, tiles < TILES, other=0)
    maximum = tl.max(mx, 0)
    lse = tl.log(tl.sum(mass * tl.exp(mx - maximum), 0))
    token = tl.load(TOKENS + row)
    selected = tl.load(LOGITS + row * STRIDE + token).to(tl.float32)
    tl.store(LOGPROBS + row, selected - maximum - lse)
    tl.store(TOKEN_RANKS + row, tl.sum(ranks, 0).to(tl.int64))


def selected_logprob_and_rank(logits, tokens):
    if logits.ndim != 2 or not logits.is_cuda or logits.stride(1) != 1:
        raise ValueError('CUDA logits with contiguous vocab axis required')
    rows, vocab = logits.shape
    tokens = tokens.reshape(-1).contiguous()
    if tokens.numel() != rows:
        raise ValueError('One sampled token per logit row required')
    tiles = triton.cdiv(vocab, 4096)
    maxima = torch.empty((rows, tiles), dtype=torch.float32, device=logits.device)
    sums = torch.empty_like(maxima)
    ranks = torch.empty((rows, tiles), dtype=torch.int32, device=logits.device)
    lp = torch.empty((rows, 1), dtype=torch.float32, device=logits.device)
    token_ranks = torch.empty(rows, dtype=torch.int64, device=logits.device)
    _partial_scores[(rows, tiles)](logits, tokens, maxima, sums, ranks,
                                   STRIDE=logits.stride(0), V=vocab,
                                   TILES=tiles, BLOCK=4096, num_warps=8)
    _finish_scores[(rows,)](logits, tokens, maxima, sums, ranks, lp, token_ranks,
                            STRIDE=logits.stride(0), V=vocab, TILES=tiles,
                            BLOCK=triton.next_power_of_2(tiles), num_warps=4)
    return lp, token_ranks


def install():
    global _INSTALLED, _ORIGINAL_TOPK, _FAST_TOPK
    if _INSTALLED:
        return
    from vllm.v1.outputs import LogprobsTensors
    from vllm.v1.worker.gpu.sample import sampler as gpu_sampler
    original = gpu_sampler.compute_topk_scores

    def scores(logits, num_logprobs, sampled_token_ids, cu_num_logits=None,
               logprob_token_ids_state=None, expanded_idx_mapping=None,
               max_per_req_token_ids=0, logits_mode=False):
        supported = (num_logprobs == 0 and max_per_req_token_ids == 0
                     and not logits_mode and logits.is_cuda
                     and logits.ndim == 2 and logits.stride(1) == 1)
        if not supported:
            _COUNTS['fallback'] += 1
            return original(logits, num_logprobs, sampled_token_ids, cu_num_logits,
                            logprob_token_ids_state, expanded_idx_mapping,
                            max_per_req_token_ids, logits_mode)
        lp, rank = selected_logprob_and_rank(logits, sampled_token_ids)
        _COUNTS['fast'] += 1
        total = _COUNTS['fast'] + _COUNTS['fallback']
        if total in (1, 10, 100, 1000) or total % 10000 == 0:
            print('SPRINT_SAMPLER ' + json.dumps({'pid': os.getpid(),
                  'counts': dict(_COUNTS), 'runtime': gpu_sampler.__name__}), flush=True)
        is_tensor = isinstance(cu_num_logits, torch.Tensor)
        return LogprobsTensors(
            logprob_token_ids=sampled_token_ids.unsqueeze(-1), logprobs=lp,
            selected_token_ranks=rank,
            cu_num_generated_tokens=None if is_tensor else cu_num_logits,
            cu_num_generated_tokens_tensor=cu_num_logits if is_tensor else None)

    _ORIGINAL_TOPK, _FAST_TOPK = original, scores
    gpu_sampler.compute_topk_scores = scores
    _INSTALLED = True


class StatsWorker:
    def sprint_kv_stats(self):
        import serving_kv_prototype
        import sys
        from vllm.v1.engine.core import EngineCore
        state = serving_kv_prototype.stats()
        frame = sys._getframe()
        while frame is not None:
            engine = frame.f_locals.get('self')
            if isinstance(engine, EngineCore):
                coordinator = engine.scheduler.kv_cache_manager.coordinator
                state['coordinator'] = type(coordinator).__name__
                state['scheduler_block_size'] = coordinator.scheduler_block_size
                state['partial_hash_hits'] = getattr(coordinator, 'enable_partial_hash_hits', None)
                state['managers'] = [
                    {name: str(getattr(manager, name, None)) for name in
                     ['block_size', 'mamba_cache_mode', 'num_speculative_blocks',
                      'use_eagle', 'fine_grained_prefix_cache', 'has_prefill_checkpoint_blocks']}
                    | {'class': type(manager).__name__,
                       'spec': type(manager.kv_cache_spec).__name__,
                       'hash_block_size': manager.block_pool.hash_block_size}
                    for manager in coordinator.single_type_managers]
                break
            frame = frame.f_back
        del frame
        return state

    def sprint_kv_toggle(self, enabled='1'):
        import serving_kv_prototype
        return serving_kv_prototype.toggle(enabled == '1')

    def sprint_cpu_profile_arm(self, output, label='engine', calls='8'):
        global _CPU_PROFILE_STATE
        import cProfile
        import pstats
        import sys
        import time
        from pathlib import Path
        from vllm.v1.engine.core import EngineCore
        if _CPU_PROFILE_STATE is not None and not _CPU_PROFILE_STATE.get('complete'):
            raise RuntimeError('CPU profile already active')
        frame = sys._getframe()
        engine = None
        while frame is not None:
            candidate = frame.f_locals.get('self')
            if isinstance(candidate, EngineCore):
                engine = candidate
                break
            frame = frame.f_back
        del frame
        if engine is None:
            raise RuntimeError('No EngineCore in same-process RPC stack')
        original = engine.step_fn
        count = int(calls)
        if not 1 <= count <= 16:
            raise ValueError('Bounded profile needs 1-16 engine calls')
        directory = Path(output)
        directory.mkdir(parents=True, exist_ok=True)
        profiler = cProfile.Profile()
        state = {'pid': os.getpid(), 'label': label, 'calls': 0, 'limit': count,
                 'wall_ms': 0.0, 'complete': False, 'running_per_call': []}
        _CPU_PROFILE_STATE = state

        def profiled_step():
            state['running_per_call'].append(len(engine.scheduler.running))
            started = time.perf_counter()
            profiler.enable()
            try:
                return original()
            finally:
                profiler.disable()
                state['calls'] += 1
                state['wall_ms'] += (time.perf_counter() - started) * 1000
                if state['calls'] == count:
                    engine.step_fn = original
                    state['complete'] = True
                    path = directory / (label + '_' + str(os.getpid()) + '.pstats')
                    profiler.dump_stats(str(path))
                    ordered = sorted(pstats.Stats(profiler).stats.items(),
                                     key=lambda pair: pair[1][3], reverse=True)
                    result = dict(state, profile_path=str(path),
                                  scope='Bounded live EngineCore step; includes cProfile and GPU waits',
                                  functions=[{'file': k[0], 'line': k[1], 'name': k[2],
                                              'primitive_calls': v[0], 'calls': v[1],
                                              'self_s': v[2], 'cumulative_s': v[3]}
                                             for k, v in ordered[:80]])
                    path.with_suffix('.json').write_text(json.dumps(result, indent=2))
                    print('SPRINT_ENGINE_PROFILE ' + json.dumps(result), flush=True)

        engine.step_fn = profiled_step
        return dict(state)

    def sprint_cpu_profile_stats(self):
        return _CPU_PROFILE_STATE

    def sprint_runtime_state(self):
        runner = self.model_runner

        def tensors(value):
            if isinstance(value, torch.Tensor):
                return [{'dtype': str(value.dtype), 'shape': list(value.shape),
                         'stride': list(value.stride()), 'bytes': value.numel() * value.element_size()}]
            if isinstance(value, (tuple, list)):
                return [item for part in value for item in tensors(part)]
            if isinstance(value, dict):
                return [item for part in value.values() for item in tensors(part)]
            return []

        context = runner.compilation_config.static_forward_context
        layers = []
        for name, layer in context.items():
            caches = tensors(getattr(layer, 'kv_cache', None))
            if caches:
                impl = getattr(layer, 'impl', None)
                layers.append({'name': name, 'class': type(layer).__module__ + '.' + type(layer).__name__,
                               'impl': None if impl is None else type(impl).__module__ + '.' + type(impl).__name__,
                               'kv_cache_dtype': str(getattr(layer, 'kv_cache_dtype', None)),
                               'tensors': caches})
        config = runner.cache_config
        return {'pid': os.getpid(), 'runner': type(runner).__module__ + '.' + type(runner).__name__,
                'configured': {name: str(getattr(config, name, None)) for name in
                               ['cache_dtype', 'mamba_cache_dtype', 'mamba_ssm_cache_dtype']},
                'runner_kv_cache_dtype': str(runner.kv_cache_dtype), 'layers': layers,
                'allocated_cache_tensors': tensors(getattr(runner, 'kv_caches', [])),
                'boundary': 'Actual tensor dtype/shape recorded, not only launch flags; cache allocations may alias'}

    def sprint_sampler_stats(self):
        from vllm.v1.worker.gpu.sample import sampler as gpu_sampler
        sampler = self.model_runner.sampler
        active = gpu_sampler.compute_topk_scores
        return {'installed': _INSTALLED, 'counts': dict(_COUNTS),
                'rank_boundary': 'Exact sampled rank retained; RNG and sampler unchanged',
                'sampler_class': str(type(sampler)),
                'sampler_module': type(sampler).__module__,
                'call_module': getattr(type(sampler).__call__, '__module__', None),
                'scores_module': getattr(active, '__module__', None),
                'candidate_active': active is _FAST_TOPK}

    def sprint_sampler_toggle(self, enabled='1'):
        from vllm.v1.worker.gpu.sample import sampler as gpu_sampler
        if _ORIGINAL_TOPK is None:
            raise RuntimeError('Sampler prototype was not installed in this engine')
        gpu_sampler.compute_topk_scores = _FAST_TOPK if enabled == '1' else _ORIGINAL_TOPK
        return {'enabled': enabled == '1', 'counts': dict(_COUNTS)}


def install_frontend(profile_dir=None):
    global _FRONTEND_INSTALLED
    if _FRONTEND_INSTALLED:
        return
    from vllm.entrypoints.openai.completion.protocol import CompletionRequest
    original = CompletionRequest.to_sampling_params

    def sampling_params(self, max_tokens, default_sampling_params=None):
        params = original(self, max_tokens, default_sampling_params)
        opted_in = (self.vllm_xargs or {}).get('poor_rl_token_ids_only') == 1
        supported = (opted_in and self.return_token_ids
                     and self.return_tokens_as_token_ids and self.logprobs == 0
                     and not self.stop and not self.stream and not self.echo
                     and not self.logprob_token_ids and not params.stop)
        if supported:
            params.detokenize = False
            _FRONTEND_COUNTS['token_ids_only'] += 1
        else:
            _FRONTEND_COUNTS['regular'] += 1
        total = sum(_FRONTEND_COUNTS.values())
        if total in (1, 32, 512, 1024) or total % 10000 == 0:
            print('SPRINT_FRONTEND ' + json.dumps({'pid': os.getpid(),
                  'counts': dict(_FRONTEND_COUNTS)}), flush=True)
        return params

    CompletionRequest.to_sampling_params = sampling_params
    _FRONTEND_INSTALLED = True
    if profile_dir is None:
        return
    import cProfile
    import pstats
    import time
    from pathlib import Path
    from vllm.v1.engine.output_processor import OutputProcessor
    process = OutputProcessor.process_outputs
    profiler = cProfile.Profile()
    state = {'calls': 0, 'profiled_calls': 0, 'outputs': 0, 'wall_ms': 0.0}
    directory = Path(profile_dir)
    directory.mkdir(parents=True, exist_ok=True)

    def profiled_outputs(self, engine_core_outputs, *args, **kwargs):
        state['calls'] += 1
        active = 64 < state['calls'] <= 72
        if not active:
            return process(self, engine_core_outputs, *args, **kwargs)
        started = time.perf_counter()
        profiler.enable()
        try:
            return process(self, engine_core_outputs, *args, **kwargs)
        finally:
            profiler.disable()
            state['profiled_calls'] += 1
            state['outputs'] += len(engine_core_outputs)
            state['wall_ms'] += (time.perf_counter() - started) * 1000
            if state['calls'] == 72:
                path = directory / ('frontend_' + str(os.getpid()) + '.pstats')
                profiler.dump_stats(str(path))
                stats = pstats.Stats(profiler)
                ordered = sorted(stats.stats.items(), key=lambda pair: pair[1][3], reverse=True)
                result = dict(state, pid=os.getpid(), profile_path=str(path),
                              scope='Eight output processing calls; includes cProfile overhead',
                              frontend_counts=dict(_FRONTEND_COUNTS),
                              functions=[{'file': k[0], 'line': k[1], 'name': k[2],
                                          'primitive_calls': v[0], 'calls': v[1],
                                          'self_s': v[2], 'cumulative_s': v[3]}
                                         for k, v in ordered[:60]])
                path.with_suffix('.json').write_text(json.dumps(result, indent=2))
                print('SPRINT_FRONTEND_PROFILE ' + json.dumps(result), flush=True)

    OutputProcessor.process_outputs = profiled_outputs


if os.environ.get('RLFORGE_SPRINT_SAMPLER') == '1':
    install()
if os.environ.get('RLFORGE_SPRINT_KV') == '1':
    import serving_kv_prototype
    serving_kv_prototype.install()
