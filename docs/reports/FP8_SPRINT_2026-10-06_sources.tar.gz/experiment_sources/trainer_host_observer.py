"""Optional host timings at the existing step anchor; no CUDA synchronization."""
import functools
import hashlib
import json
import time
from pathlib import Path


def install_for_trainer(trainer, client=None, *, output):
    totals, counts, records, edits = {}, {}, [], []
    patched, bound_runtime = set(), False
    previous_anchor = None
    previous_reference = {}
    reference_keys = (
        "trainer_wait_s", "stage_total_ms", "stage_host_ms", "stage_payload_ms",
        "worker_compute_ms", "completion_tokens", "requests",
    )
    if client is not None:
        previous_reference = {key: client.stats.get(key, 0) for key in reference_keys}

    def add(label, elapsed):
        totals[label] = totals.get(label, 0.0) + elapsed
        counts[label] = counts.get(label, 0) + 1

    def replace(owner, name, replacement):
        original = getattr(owner, name)
        existed = name in owner.__dict__
        own_value = owner.__dict__.get(name)
        edits.append((owner, name, existed, own_value))
        setattr(owner, name, replacement)
        for callback in trainer.callback_handler.callbacks:
            if getattr(callback, "fn", None) == original:
                edits.append((callback, "fn", True, callback.fn))
                callback.fn = replacement

    def wrap(owner, name, label):
        identity = (id(owner), name)
        if identity in patched or not callable(getattr(owner, name, None)):
            return
        patched.add(identity)
        original = getattr(owner, name)

        @functools.wraps(original)
        def timed(*args, **kwargs):
            start = time.perf_counter()
            try:
                return original(*args, **kwargs)
            finally:
                add(label, time.perf_counter() - start)

        replace(owner, name, timed)

    def bind_runtime():
        nonlocal bound_runtime
        if bound_runtime:
            return
        bound_runtime = True
        for owner, name, label in (
            (trainer.optimizer, "step", "optimizer.step"),
            (trainer.lr_scheduler, "step", "scheduler.step"),
            (trainer.model_wrapped, "zero_grad", "model.zero_grad"),
        ):
            if owner is not None:
                wrap(owner, name, label)

    for name in (
        "get_batch_samples", "_prepare_inputs", "training_step",
        "_compute_loss_subbatched", "_loss_metrics", "_clip_grad_norm",
        "_get_grad_norm", "floating_point_ops", "_track_num_input_tokens",
        "_maybe_log_save_evaluate", "log", "_sync_weight",
    ):
        wrap(trainer, name, "trainer." + name)
    wrap(trainer.accelerator, "backward", "accelerator.backward")
    if client is not None:
        for name in ("stage_inputs", "stage_lists", "bind_inputs", "prefetch", "finish"):
            wrap(client, name, "reference." + name)
    if callable(getattr(trainer, "get_train_dataloader", None)):
        get_loader = trainer.get_train_dataloader

        @functools.wraps(get_loader)
        def dataloader(*args, **kwargs):
            loader = get_loader(*args, **kwargs)
            wrap(loader, "_fetch_batches", "dispatcher.fetch_batches")
            base = getattr(loader, "base_dataloader", loader)
            collator = getattr(base, "collate_fn", None)
            if collator is not None:
                wrap(collator, "torch_call", "collator.torch_call")
                wrap(collator, "_log_metrics", "collator.log_metrics")
            return loader

        replace(trainer, "get_train_dataloader", dataloader)

    handler = trainer.callback_handler
    call_event = handler.call_event

    @functools.wraps(call_event)
    def event(event_name, *args, **kwargs):
        if event_name == "on_train_begin":
            bind_runtime()
        if event_name == "on_step_end":
            return call_event(event_name, *args, **kwargs)
        start = time.perf_counter()
        try:
            return call_event(event_name, *args, **kwargs)
        finally:
            add("callback." + event_name, time.perf_counter() - start)

    replace(handler, "call_event", event)
    for callback in handler.callbacks:
        if type(callback).__name__ == "_EpochStopCallback":
            wrap(callback, "on_step_end", "callback.epoch_stop")

    log_step = trainer._log_step_metrics

    @functools.wraps(log_step)
    def flush(*args, **kwargs):
        nonlocal previous_anchor, previous_reference
        anchor = time.perf_counter()
        reference = {}
        if client is not None:
            current = {key: client.stats.get(key, 0) for key in reference_keys}
            reference = {key: current[key] - previous_reference.get(key, 0) for key in reference_keys}
            previous_reference = current
        record = {
            "step": trainer.state.global_step,
            "host_window_s": None if previous_anchor is None else anchor - previous_anchor,
            "inclusive_host_s": dict(totals), "calls": dict(counts),
            "reference_stats_delta": reference,
        }
        totals.clear()
        counts.clear()
        previous_anchor = anchor
        records.append(record)
        return log_step(*args, **kwargs)

    replace(trainer, "_log_step_metrics", flush)

    def restore():
        path = Path(output)
        artifact = {
            "scope": "Unsynchronized host call durations, inclusive and nested; not GPU time",
            "trainer_class": type(trainer).__module__ + "." + type(trainer).__qualname__,
            "rank": getattr(trainer.accelerator, "process_index", None),
            "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "records": records,
            "post_last_anchor_tail": {"inclusive_host_s": dict(totals), "calls": dict(counts)},
            "boundaries": [
                "No tensor inspection, additional collectives, CUDA events or synchronization.",
                "Nested durations overlap and must not be summed; backward host time may include GPU waits.",
                "Anchors surround the existing _log_step_metrics callback, before HF logging.",
                "Prior HF logging/collation/reference staging may fall in the following step window.",
                "The first record includes warmup; post-last-anchor tail is excluded from step windows.",
            ],
        }
        for owner, name, existed, own_value in reversed(edits):
            if existed:
                setattr(owner, name, own_value)
            else:
                delattr(owner, name)
        path.write_text(json.dumps(artifact, indent=2) + chr(10))

    return restore
