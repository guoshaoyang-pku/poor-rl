"""Speed-first isolated norm/GDN-preparation/SwiGLU fusion candidate.

Policy matrix operations remain native FP8. FP32 parameters and gradients are
preserved. This candidate permits changed scalar/reduction rounding; numerical
alignment and learned-policy quality need later gates. No canonical source edit.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from types import MethodType

import torch
import torch.nn.functional as F

_COMPILED = {}


def _call(name, fn, *args):
    if not any(isinstance(x, torch.Tensor) and x.is_cuda for x in args):
        return fn(*args)
    if os.environ.get("RLFORGE_SPRINT_COMPILE", "1") == "0":
        return fn(*args)
    strict = os.environ.get("RLFORGE_SPRINT_STRICT", "0") == "1"
    key = name, strict
    if key not in _COMPILED:
        options = {"emulate_precision_casts": True} if strict else {}
        _COMPILED[key] = torch.compile(fn, dynamic=True, options=options)
    return _COMPILED[key](*args)


def _rms_fwd(x, weight, eps):
    xf = x.float()
    inv = torch.rsqrt(xf.square().mean(-1, keepdim=True) + eps)
    return (xf * inv * (1.0 + weight.to(x.dtype).float())).to(x.dtype), inv


def _rms_bwd(x, weight, inv, grad):
    xf, gf = x.float(), grad.float()
    w = 1.0 + weight.to(x.dtype).float()
    gn = gf * w
    projection = (gn * xf).mean(-1, keepdim=True)
    dx = (inv * (gn - xf * inv.square() * projection)).to(x.dtype)
    dw = (gf * xf * inv).sum(tuple(range(x.ndim - 1)))
    return dx, dw.to(x.dtype).to(weight.dtype)


class _RMS(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, weight, eps):
        ctx.set_materialize_grads(False)
        y, inv = _call("rms_fwd", _rms_fwd, x.detach(), weight, eps)
        ctx.save_for_backward(x, weight, inv)
        return y

    @staticmethod
    def backward(ctx, grad):
        if grad is None:
            return None, None, None
        x, weight, inv = ctx.saved_tensors
        dx, dw = _call("rms_bwd", _rms_bwd, x.detach(), weight, inv.detach(), grad.detach())
        return dx if ctx.needs_input_grad[0] else None, dw if ctx.needs_input_grad[1] else None, None


def _gated_fwd(x, gate, weight, eps):
    xf = x.float()
    inv = torch.rsqrt(xf.square().mean(-1, keepdim=True) + eps)
    y = xf * inv * weight.to(x.dtype).float() * F.silu(gate.float())
    return y.to(x.dtype), inv


def _gated_bwd(x, gate, weight, inv, grad):
    xf, zf, gf = x.float(), gate.float(), grad.float()
    wf = weight.to(x.dtype).float()
    s = torch.sigmoid(zf)
    norm = xf * inv
    gw = gf * zf * s
    gn = gw * wf
    projection = (gn * xf).mean(-1, keepdim=True)
    dx = (inv * (gn - xf * inv.square() * projection)).to(x.dtype)
    dz = (gf * norm * wf * s * (1.0 + zf * (1.0 - s))).to(gate.dtype)
    dw = (gw * norm).sum(tuple(range(x.ndim - 1))).to(x.dtype).to(weight.dtype)
    return dx, dz, dw


class _GatedRMS(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, gate, weight, eps):
        ctx.set_materialize_grads(False)
        y, inv = _call("gated_fwd", _gated_fwd, x.detach(), gate.detach(), weight, eps)
        ctx.save_for_backward(x, gate, weight, inv)
        return y

    @staticmethod
    def backward(ctx, grad):
        if grad is None:
            return None, None, None, None
        x, gate, weight, inv = ctx.saved_tensors
        dx, dz, dw = _call("gated_bwd", _gated_bwd, x.detach(), gate.detach(), weight,
                           inv.detach(), grad.detach())
        return (dx if ctx.needs_input_grad[0] else None, dz if ctx.needs_input_grad[1] else None,
                dw if ctx.needs_input_grad[2] else None, None)


def _qk_fwd(q, k):
    qf, kf = q.float(), k.float()
    qinv = torch.rsqrt(qf.square().sum(-1, keepdim=True) + 1e-6)
    kinv = torch.rsqrt(kf.square().sum(-1, keepdim=True) + 1e-6)
    return (qf * qinv).to(q.dtype), (kf * kinv).to(k.dtype), qinv, kinv


def _l2_bwd(x, inv, grad):
    xf, gf = x.float(), grad.float()
    projection = (gf * xf).sum(-1, keepdim=True)
    return (inv * (gf - xf * inv.square() * projection)).to(x.dtype)


class _QK(torch.autograd.Function):
    @staticmethod
    def forward(ctx, q, k):
        ctx.set_materialize_grads(False)
        qo, ko, qi, ki = _call("qk_fwd", _qk_fwd, q.detach(), k.detach())
        ctx.save_for_backward(q, k, qi, ki)
        return qo, ko

    @staticmethod
    def backward(ctx, gq, gk):
        q, k, qi, ki = ctx.saved_tensors
        dq = _call("q_bwd", _l2_bwd, q.detach(), qi.detach(), gq.detach()) if gq is not None else None
        dk = _call("k_bwd", _l2_bwd, k.detach(), ki.detach(), gk.detach()) if gk is not None else None
        return dq if ctx.needs_input_grad[0] else None, dk if ctx.needs_input_grad[1] else None


def _beta_gate(b, a, a_log, dt_bias):
    beta = b.float().sigmoid()
    gate = -a_log.float().exp() * F.softplus(a.float() + dt_bias.to(a.dtype).float())
    return beta, gate


def _prepare(q, k, b, a, a_log, dt_bias):
    q, k = _QK.apply(q, k)
    beta, gate = _call("beta_gate", _beta_gate, b, a, a_log, dt_bias)
    return q, k, beta, gate


def _swiglu_fwd(gate, up):
    # Fast candidate fuses the intermediate BF16 SiLU cast into final multiplication.
    return (F.silu(gate.float()) * up.float()).to(gate.dtype)


def _swiglu_bwd(gate, up, grad):
    g, u, dy = gate.float(), up.float(), grad.float()
    s = g.sigmoid()
    return (dy * u * s * (1 + g * (1 - s))).to(gate.dtype), (dy * g * s).to(up.dtype)


class _SwiGLU(torch.autograd.Function):
    @staticmethod
    def forward(ctx, gate, up):
        ctx.set_materialize_grads(False)
        ctx.save_for_backward(gate, up)
        return _call("swiglu_fwd", _swiglu_fwd, gate.detach(), up.detach())

    @staticmethod
    def backward(ctx, grad):
        if grad is None:
            return None, None
        gate, up = ctx.saved_tensors
        dg, du = _call("swiglu_bwd", _swiglu_bwd, gate.detach(), up.detach(), grad.detach())
        return dg if ctx.needs_input_grad[0] else None, du if ctx.needs_input_grad[1] else None


def _rms_forward(self, x):
    return _RMS.apply(x, self.weight, self.eps)


def _gated_forward(self, x, gate):
    return _GatedRMS.apply(x, gate, self.weight, self.variance_epsilon)


def _mlp_forward(self, x):
    from rlforge import fp8

    combined = fp8._FP8GateUp.apply(x, self.gate_proj.weight, self.up_proj.weight, *fp8._gate_up_cache(self))
    gate, up = combined.chunk(2, dim=-1)
    return self.down_proj(_SwiGLU.apply(gate, up))


def _reference_rms(x, weight, eps):
    xf = x.float()
    y = xf * torch.rsqrt(xf.square().mean(-1, keepdim=True) + eps) * (1 + weight.float())
    return y.to(x.dtype)


def install_for_benchmark(policy, ref=None):
    from transformers.models.qwen3_5 import modeling_qwen3_5 as mq
    from rlforge import fp8_alignment as alignment

    originals = []
    for module in policy.modules():
        if isinstance(module, mq.Qwen3_5RMSNorm):
            forward = _rms_forward
        elif isinstance(module, mq.Qwen3_5RMSNormGated):
            forward = _gated_forward
        elif type(module).__name__ in ("Qwen3_5MLP", "Qwen3_5MoeMLP") and module.config.hidden_act == "silu":
            forward = _mlp_forward
        else:
            continue
        originals.append((module, module.forward))
        module.forward = MethodType(forward, module)
    old_prepare = alignment._gdn_prepare
    alignment._gdn_prepare = _prepare
    if ref is not None and os.environ.get("RLFORGE_SPRINT_FUSE_REF", "0") == "1":
        for module in ref.modules():
            if isinstance(module, mq.Qwen3_5RMSNorm):
                originals.append((module, module.forward))
                def reference_forward(self, x):
                    return _call("reference_rms", _reference_rms, x, self.weight, self.eps)
                module.forward = MethodType(reference_forward, module)
    def restore():
        for module, original in originals:
            module.forward = original
        alignment._gdn_prepare = old_prepare
    return restore


def cpu_gate():
    torch.set_num_threads(1)
    torch.manual_seed(19)
    rows = []
    for name in ("rms", "gated", "qk", "swiglu"):
        x = torch.randn(2, 3, 8, dtype=torch.float32).requires_grad_()
        z = torch.randn_like(x).requires_grad_()
        w = torch.randn(8).requires_grad_()
        upstream = torch.randn_like(x)
        if name == "rms":
            y = _RMS.apply(x, w, 1e-6)
            reference = _rms_fwd(x, w, 1e-6)[0]
            params = x, w
        elif name == "gated":
            y = _GatedRMS.apply(x, z, w, 1e-6)
            reference = _gated_fwd(x, z, w, 1e-6)[0]
            params = x, z, w
        elif name == "qk":
            y, _ = _QK.apply(x, z)
            reference = _qk_fwd(x, z)[0]
            params = x,
        else:
            y = _SwiGLU.apply(x, z)
            reference = _swiglu_fwd(x, z)
            params = x, z
        grad = torch.autograd.grad(y, params, upstream, retain_graph=True)
        expected = torch.autograd.grad(reference, params, upstream)
        assert torch.equal(y, reference)
        for actual, baseline in zip(grad, expected):
            torch.testing.assert_close(actual, baseline, rtol=1e-5, atol=2e-6)
        rows.append({"module": name, "fwd_exact_own_formula": True,
                     "analytic_gradient_close": True})
    return {"scope": "CPU eager FP32 analytic checks; changed rounding vs canonical allowed",
            "rows": rows, "gpu_tested": False, "masters": "FP32 unchanged"}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--cpu-gate", action="store_true")
    parser.add_argument("--output")
    args = parser.parse_args()
    if not args.cpu_gate:
        parser.error("Use --cpu-gate or import install_for_benchmark")
    value = cpu_gate()
    result = json.dumps(value, indent=2)
    if args.output:
        Path(args.output).write_text(result)
    print(result)
