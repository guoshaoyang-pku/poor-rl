"""Read actual attention KV scales outside the measured serving window."""
import torch
from serving_sampler_prototype import StatsWorker


class BandwidthWorker(StatsWorker):
    def sprint_kv_precision(self):
        state = self.sprint_runtime_state()
        extra = []
        for name, layer in self.model_runner.compilation_config.static_forward_context.items():
            if not hasattr(layer, 'impl') or 'GatedDelta' in type(layer).__name__:
                continue
            scales = {}
            for attr in ('_k_scale', '_v_scale', '_q_scale', '_k_scale_float', '_v_scale_float', 'calculate_kv_scales'):
                value = getattr(layer, attr, None)
                if isinstance(value, torch.Tensor) and value.numel() < 8:
                    scales[attr] = value.detach().cpu().tolist()
                elif isinstance(value, (int, float, bool)) or value is None:
                    scales[attr] = value
            extra.append({'name': name, 'impl': type(layer.impl).__module__+'.'+type(layer.impl).__name__,
                          'kv_cache_dtype': str(getattr(layer, 'kv_cache_dtype', None)), 'scales': scales})
        state['attention_precision'] = extra
        return state
