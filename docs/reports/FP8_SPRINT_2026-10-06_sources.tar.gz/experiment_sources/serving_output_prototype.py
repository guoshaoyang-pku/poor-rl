"""Fused ordinary one-token output bookkeeping; native stop/cache semantics."""
import os

_INSTALLED = False
_ENABLED = False
_COUNTS = {'fast': 0, 'fallback': 0}


def install():
    global _INSTALLED
    if _INSTALLED:
        return
    from vllm.v1.core.sched.async_scheduler import AsyncScheduler
    from vllm.v1.request import RequestStatus
    native = AsyncScheduler._update_request_with_output

    def update(self, request, new_token_ids, is_stale=False):
        params = request.sampling_params
        if (not _ENABLED or is_stale or len(new_token_ids) != 1
                or request.status != RequestStatus.RUNNING or params is None
                or request.pooling_params or request.resumable
                or request.use_structured_output or params.repetition_detection is not None):
            _COUNTS['fallback'] += 1
            return native(self, request, new_token_ids, is_stale)
        token = new_token_ids[0]
        request._output_token_ids.append(token)
        request._all_token_ids.append(token)
        if request._block_hasher is not None:
            request.block_hashes.extend(request._block_hasher(request))
        if token == params.eos_token_id:
            request.status = RequestStatus.FINISHED_STOPPED
            stopped = True
        elif token in (params.stop_token_ids or ()):
            request.status = RequestStatus.FINISHED_STOPPED
            request.stop_reason = token
            stopped = True
        elif len(request._all_token_ids) >= self.max_model_len or len(request._output_token_ids) >= request.max_tokens:
            request.status = RequestStatus.FINISHED_LENGTH_CAPPED
            stopped = True
        else:
            stopped = False
        request.num_output_placeholders -= 1
        assert request.num_output_placeholders >= 0
        self.kv_cache_manager.cache_blocks(
            request, request.num_computed_tokens - request.num_output_placeholders)
        _COUNTS['fast'] += 1
        return new_token_ids, stopped

    AsyncScheduler._update_request_with_output = update
    _INSTALLED = True


def toggle(enabled):
    global _ENABLED
    _ENABLED = enabled
    return stats()


def stats():
    return {'pid': os.getpid(), 'installed': _INSTALLED, 'enabled': _ENABLED,
            'counts': dict(_COUNTS),
            'boundary': 'Single token stop/append/hash/placeholder/cache fusion; stale/spec/stream/repetition uses native'}
