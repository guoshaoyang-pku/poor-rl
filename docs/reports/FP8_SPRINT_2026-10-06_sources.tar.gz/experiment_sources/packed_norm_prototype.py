"""Pack independent small norm rows into one Triton CTA."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import torch
import fusion_triton_prototype as norm

try:
    import triton
    import triton.language as tl
except ImportError:
    triton = tl = None


if triton is not None:
    @triton.jit
    def _packed_fwd(X, Z, W, Y, Inv, Rows, N1, N2,
                    XS0, XS1, XS2, XSC, ZS0, ZS1, ZS2, ZSC,
                    C: tl.constexpr, EPS: tl.constexpr, MODE: tl.constexpr,
                    RB: tl.constexpr, CB: tl.constexpr):
        rows = tl.program_id(0) * RB + tl.arange(0, RB)
        cols = tl.arange(0, CB)
        valid = (rows[:, None] < Rows) & (cols[None, :] < C)
        offsets = norm._row_offset(rows, N1, N2, XS0, XS1, XS2)
        x = tl.load(X + offsets[:, None] + cols[None, :] * XSC, valid, other=0).to(tl.float32)
        var = tl.sum(x * x, 1)
        if MODE != 0:
            var = var / C
        inv = tl.rsqrt(var + EPS)
        y = x * inv[:, None]
        if MODE != 0:
            weight = tl.load(W + cols, cols < C, other=0).to(X.dtype.element_ty).to(tl.float32)
            if MODE == 1:
                weight = 1.0 + weight
            y = y * weight[None, :]
        if MODE == 2:
            offsets = norm._row_offset(rows, N1, N2, ZS0, ZS1, ZS2)
            z = tl.load(Z + offsets[:, None] + cols[None, :] * ZSC, valid, other=0).to(tl.float32)
            y = y * z * tl.sigmoid(z)
        tl.store(Y + rows[:, None] * C + cols[None, :], y, valid)
        tl.store(Inv + rows, inv, rows < Rows)

    @triton.jit
    def _packed_bwd(X, Z, W, Inv, DY, DX, DZ, Rows, N1, N2,
                    XS0, XS1, XS2, XSC, ZS0, ZS1, ZS2, ZSC,
                    DS0, DS1, DS2, DSC, C: tl.constexpr, MODE: tl.constexpr,
                    RB: tl.constexpr, CB: tl.constexpr):
        rows = tl.program_id(0) * RB + tl.arange(0, RB)
        cols = tl.arange(0, CB)
        valid = (rows[:, None] < Rows) & (cols[None, :] < C)
        xoff = norm._row_offset(rows, N1, N2, XS0, XS1, XS2)
        doff = norm._row_offset(rows, N1, N2, DS0, DS1, DS2)
        x = tl.load(X + xoff[:, None] + cols[None, :] * XSC, valid, other=0).to(tl.float32)
        dy = tl.load(DY + doff[:, None] + cols[None, :] * DSC, valid, other=0).to(tl.float32)
        inv = tl.load(Inv + rows, rows < Rows, other=0)
        gn = dy
        if MODE != 0:
            weight = tl.load(W + cols, cols < C, other=0).to(X.dtype.element_ty).to(tl.float32)
            if MODE == 1:
                weight = 1.0 + weight
            gn = gn * weight[None, :]
        if MODE == 2:
            zoff = norm._row_offset(rows, N1, N2, ZS0, ZS1, ZS2)
            z = tl.load(Z + zoff[:, None] + cols[None, :] * ZSC, valid, other=0).to(tl.float32)
            sigmoid = tl.sigmoid(z)
            gn = gn * z * sigmoid
            dz = dy * x * inv[:, None] * weight[None, :] * sigmoid * (1.0 + z * (1.0 - sigmoid))
            tl.store(DZ + rows[:, None] * C + cols[None, :], dz, valid)
        projection = tl.sum(gn * x, 1)
        if MODE != 0:
            projection = projection / C
        dx = inv[:, None] * (gn - x * inv[:, None] * inv[:, None] * projection[:, None])
        tl.store(DX + rows[:, None] * C + cols[None, :], dx, valid)


def _value(x, weight, eps, mode, gate=None):
    if not x.is_cuda or x.shape[-1] > 256:
        return norm._value(x, weight, eps, mode, gate)
    dims, strides = norm._layout(x)
    zs = norm._layout(gate)[1] if gate is not None else (0, 0, 0, 0)
    rows, width = x.numel() // x.shape[-1], x.shape[-1]
    y = torch.empty(x.shape, device=x.device, dtype=x.dtype)
    inv = torch.empty(rows, device=x.device, dtype=torch.float32)
    _packed_fwd[(triton.cdiv(rows, 16),)](
        x, gate if gate is not None else x, weight if weight is not None else x, y, inv,
        rows, dims[1], dims[2], *strides, *zs, C=width, EPS=eps, MODE=mode,
        RB=16, CB=triton.next_power_of_2(width), num_warps=4, enable_fp_fusion=True)
    return y, inv


def _gradient(x, weight, inv, grad, mode, gate=None, need_weight=True):
    if not x.is_cuda or x.shape[-1] > 256:
        return norm._gradient(x, weight, inv, grad, mode, gate, need_weight)
    dims, strides = norm._layout(x)
    zs = norm._layout(gate)[1] if gate is not None else (0, 0, 0, 0)
    ds = norm._layout(grad)[1]
    rows, width = x.numel() // x.shape[-1], x.shape[-1]
    dx = torch.empty(x.shape, device=x.device, dtype=x.dtype)
    dz = torch.empty(gate.shape, device=gate.device, dtype=gate.dtype) if gate is not None else None
    _packed_bwd[(triton.cdiv(rows, 16),)](
        x, gate if gate is not None else x, weight if weight is not None else x, inv, grad, dx,
        dz if dz is not None else dx, rows, dims[1], dims[2], *strides, *zs, *ds,
        C=width, MODE=mode, RB=16, CB=triton.next_power_of_2(width), num_warps=4)
    dw = None
    if mode != 0 and need_weight:
        groups = triton.cdiv(rows, 128)
        partial = torch.empty((groups, width), device=x.device, dtype=torch.float32)
        norm._norm_dw[(groups, triton.cdiv(width, 32))](
            x, gate if gate is not None else x, inv, grad, partial, rows, dims[1], dims[2],
            *strides, *zs, *ds, C=width, GATED=mode == 2, RB=128, CB=32, num_warps=8)
        dw = partial.sum(0).to(weight.dtype)
    return dx, dz, dw


def install_for_benchmark(policy, ref=None):
    import branch_conv_precise_prototype as branch

    restore_branch = branch.install_for_benchmark(policy, ref=ref)
    original_value, original_gradient = norm._value, norm._gradient

    def value(x, weight, eps, mode, gate=None):
        if x.is_cuda and x.shape[-1] <= 256:
            return _value(x, weight, eps, mode, gate)
        return original_value(x, weight, eps, mode, gate)

    def gradient(x, weight, inv, grad, mode, gate=None, need_weight=True):
        if x.is_cuda and x.shape[-1] <= 256:
            return _gradient(x, weight, inv, grad, mode, gate, need_weight)
        return original_gradient(x, weight, inv, grad, mode, gate, need_weight)

    norm._value, norm._gradient = value, gradient

    def restore():
        norm._value, norm._gradient = original_value, original_gradient
        restore_branch()

    return restore


def gate(device):
    torch.manual_seed(19)
    evidence = []
    for width in (128, 256):
        for mode in (0, 1, 2):
            source = torch.randn(3, 19, 4, width + 8, device=device, dtype=torch.bfloat16)
            x = source[..., :width].transpose(1, 2)
            weight = torch.randn(width, device=device) * 0.1 if mode else None
            z = torch.randn_like(source)[..., :width].transpose(1, 2) if mode == 2 else None
            actual, inv = _value(x, weight, 1e-6, mode, z)
            expected, expected_inv = norm._value(x, weight, 1e-6, mode, z)
            difference = (actual.float() - expected.float()).abs()
            assert torch.equal(actual, expected)
            assert torch.equal(inv.reshape(-1), expected_inv.reshape(-1))
            upstream = torch.randn_like(actual) * 0.01
            gradients = _gradient(x, weight, inv, upstream, mode, z)
            wanted = norm._gradient(x, weight, expected_inv, upstream, mode, z)
            for a, b in zip(gradients, wanted):
                if a is not None:
                    torch.testing.assert_close(a, b, rtol=0.008, atol=0.0001)
            if mode:
                assert gradients[2].dtype == torch.float32
            evidence.append(dict(width=width, mode=mode, forward_max_abs=float(difference.max()),
                                 gradients_close=True, fp32_weight_gradient=bool(mode)))
    return evidence


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--device', default='cpu')
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    result = dict(scope=str(args.device) + ' independent packed-row norm primitive only',
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  primitive=gate(torch.device(args.device)))
    Path(args.output).write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
