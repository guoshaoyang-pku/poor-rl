"""Frozen Triton norm plus head-v2 benchmark composition."""
from fusion_triton_prototype import install_for_benchmark as norm
from matmul_prototype_v2 import install_for_benchmark as head


def install_for_benchmark(policy, ref=None):
    undo_norm = norm(policy, ref=ref)
    undo_head = head(policy, ref=ref)

    def restore():
        undo_head()
        undo_norm()

    return restore
