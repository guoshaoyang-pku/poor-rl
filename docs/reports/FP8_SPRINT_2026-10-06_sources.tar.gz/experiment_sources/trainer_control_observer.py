"""Time only weight-control HTTP; optional per-thread persistent connections."""
import itertools
import json
import os
import threading
import time


def install():
    import requests
    from trl.experimental.async_grpo.vllm_client import VLLMClient

    sessions = threading.local()
    serial = itertools.count(1)
    persistent = os.getenv("SPRINT_CONTROL_SESSION", "0") == "1"
    control_url = os.getenv("SPRINT_CONTROL_BASE_URL", "").rstrip("/")

    def request(self, method, timeout, **kwargs):
        call_id = f"{os.getpid()}-{next(serial)}"
        row = dict(pid=os.getpid(), rank=os.getenv("RANK"), method=method,
                   call_id=call_id, persistent=persistent, dedicated=bool(control_url),
                   wall_ns=time.time_ns(), monotonic_ns=time.perf_counter_ns())
        print("SPRINT_CONTROL " + json.dumps(dict(row, event="begin")), flush=True)
        began = time.perf_counter_ns()
        response = None
        failure = None
        try:
            if persistent:
                if not hasattr(sessions, "http"):
                    sessions.http = requests.Session()
                post = sessions.http.post
            else:
                post = requests.post
            response = post(f"{control_url or self.server_url}/{method}", timeout=timeout,
                            headers={"X-Poor-RL-Control-ID": call_id}, **kwargs)
            if response.status_code != 200:
                raise RuntimeError(f"Weight-control {method} returned {response.status_code}")
        except Exception as error:
            failure = type(error).__name__
            raise
        finally:
            print("SPRINT_CONTROL " + json.dumps(dict(
                row, event="end", elapsed_ms=(time.perf_counter_ns()-began)/1e6,
                finished_wall_ns=time.time_ns(), finished_monotonic_ns=time.perf_counter_ns(),
                status=None if response is None else response.status_code, failure=failure)), flush=True)

    def pause(self, timeout=1800):
        return request(self, "pause", timeout, params={"mode": "keep"})

    def resume(self, timeout=1800):
        return request(self, "resume", timeout)

    def initialize(self, init_info, timeout=1800):
        return request(self, "init_weight_transfer_engine", timeout, json={"init_info": init_info})

    def start(self, timeout=1800):
        return request(self, "start_weight_update", timeout, json={"is_checkpoint_format": True})

    def update(self, update_info, timeout=1800):
        return request(self, "update_weights", timeout, json={"update_info": update_info})

    def finish(self, timeout=1800):
        return request(self, "finish_weight_update", timeout)

    for name, function in [("pause", pause), ("resume", resume),
                           ("init_weight_transfer_engine", initialize),
                           ("start_weight_update", start), ("update_weights", update),
                           ("finish_weight_update", finish)]:
        setattr(VLLMClient, name, function)
