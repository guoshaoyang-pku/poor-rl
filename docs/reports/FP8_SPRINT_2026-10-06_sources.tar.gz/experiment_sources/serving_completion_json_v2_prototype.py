"""Use native model dump and Rust JSON only for successful full completions."""
import ast
import hashlib
import inspect
import os
import textwrap
import time

_INSTALLED = False
_ENABLED = False
_COUNTS = dict(fast=0, fallback=0, encode_ns=0)


def response(model, headers, native_response, raw_response):
    if not _ENABLED:
        _COUNTS['fallback'] += 1
        return native_response(content=model.model_dump(), headers=headers)
    started = time.perf_counter_ns()
    try:
        from pydantic_core import to_json
        # Dump with the native serializers first. Nested native model serializers
        # can otherwise replace nonfinite values with null before encoding.
        encoded = to_json(model.model_dump(), inf_nan_mode='constants')
        if b'NaN' in encoded or b'Infinity' in encoded:
            # Preserve native ValueError for NaN/Infinity instead of emitting null.
            _COUNTS['fallback'] += 1
            return native_response(content=model.model_dump(), headers=headers)
    except (TypeError, ValueError):
        _COUNTS['fallback'] += 1
        return native_response(content=model.model_dump(), headers=headers)
    finally:
        _COUNTS['encode_ns'] += time.perf_counter_ns() - started
    _COUNTS['fast'] += 1
    return raw_response(content=encoded, media_type='application/json', headers=headers)


def transform(source):
    tree = ast.parse(textwrap.dedent(source))
    function = tree.body[0]
    assert isinstance(function, ast.AsyncFunctionDef) and function.name == 'create_completion'
    function.decorator_list = []
    changes = 0
    for node in ast.walk(function):
        if isinstance(node, ast.If) and ast.unparse(node.test) == 'isinstance(generator, CompletionResponse)':
            assert len(node.body) == 1 and isinstance(node.body[0], ast.Return)
            assert ast.unparse(node.body[0].value) == 'JSONResponse(content=generator.model_dump(), headers=metrics_header(metrics_header_format))'
            node.body[0].value = ast.parse(
                'poor_rl_completion_response(generator, metrics_header(metrics_header_format), JSONResponse, Response)',
                mode='eval').body
            changes += 1
    assert changes == 1
    return ast.fix_missing_locations(tree)


def install():
    global _INSTALLED
    if _INSTALLED:
        return
    from starlette.responses import Response
    from vllm.entrypoints.openai.completion import api_router
    native = inspect.unwrap(api_router.create_completion)
    source = inspect.getsource(native)
    namespace = dict(native.__globals__, poor_rl_completion_response=response, Response=Response)
    exec(compile(transform(source), str(__file__), 'exec'), namespace)
    # Retain native FastAPI dependency wiring, cancellation and load bookkeeping.
    parent = api_router.create_completion
    while getattr(parent, '__wrapped__', None) is not native:
        parent = parent.__wrapped__
    matching = [cell for cell in parent.__closure__ or () if cell.cell_contents is native]
    if len(matching) != 1:
        raise ValueError('Native completion decorator closure changed')
    matching[0].cell_contents = namespace['create_completion']
    _INSTALLED = True
    return dict(native_route_sha256=hashlib.sha256(source.encode()).hexdigest(),
                successful_full_response_only=True, native_decorators_routes_errors_streams_retained=True)


def toggle(enabled):
    global _ENABLED
    _ENABLED = enabled
    return stats()


def stats():
    return dict(pid=os.getpid(), installed=_INSTALLED, enabled=_ENABLED, counts=dict(_COUNTS),
                boundary='Native model_dump unchanged. Rust JSON emits same parsed fields/text/finitefloatbits; nonfinite errors use native renderer. No GPU/sampling changes.')
