"""Batch GSPO diagnostic collectives without changing the loss or metric math."""
import json
import os
import sys

import torch


def loss_metrics(self, log_ratio, entropy, advantages, completion_mask, seq_ids, num_seq,
                 seq_mean_lr, rho, low_bound, kl_seq_mean):
    ratio = torch.exp(log_ratio)
    valid = completion_mask > 0
    low = (ratio < 1 - self.epsilon_low) & (advantages < 0)
    high = (ratio > 1 + self.epsilon_high) & (advantages > 0)
    stats = torch.stack([ratio[valid].sum(), ((ratio[valid] - 1) - log_ratio[valid]).sum(),
                         entropy[valid].sum(), low[valid].float().sum(), high[valid].float().sum(),
                         (low | high)[valid].float().sum(), valid.sum().float()])
    slr = seq_mean_lr.detach().float()
    abs_slr = slr.abs()
    comp = completion_mask[0].float()
    counts = torch.zeros(num_seq, device=comp.device).index_add_(0, seq_ids, comp)
    seq_low = torch.zeros_like(counts).index_add_(0, seq_ids, low[0].float() * comp) / counts
    seq_high = torch.zeros_like(counts).index_add_(0, seq_ids, high[0].float() * comp) / counts
    from trl.trainer.utils import nanmin, nanmax
    local = torch.stack([*stats.unbind(),
                         kl_seq_mean if kl_seq_mean is not None else slr.new_zeros(()),
                         (rho < low_bound).float().mean(), (rho > 1 + self.epsilon_high).float().mean(),
                         abs_slr.mean(), abs_slr.max(), slr.mean(),
                         torch.quantile(abs_slr, .5), torch.quantile(abs_slr, .9),
                         nanmin(seq_low), nanmax(seq_high), rho.detach().mean()])
    gathered = self.accelerator.gather(local).reshape(self.accelerator.num_processes, -1)
    sums = gathered[:, :7].sum(0)
    g_ratio, g_kl, g_ent, g_low, g_high, g_region, g_count = sums.unbind()
    values = torch.stack([g_ratio / g_count, g_kl / g_count, g_ent / g_count,
                          g_low / g_count, g_high / g_count, g_region / g_count,
                          gathered[:, 7].mean(), gathered[:, 8].mean(), gathered[:, 9].mean(),
                          gathered[:, 10].mean(), gathered[:, 11].max(),
                          gathered[:, 12].mean(), gathered[:, 13].mean(), gathered[:, 14].mean(),
                          nanmin(gathered[:, 15]), nanmax(gathered[:, 16]), local[17]])
    names = ['ratio', 'kl', 'entropy', 'clip_ratio/low_mean', 'clip_ratio/high_mean',
             'clip_ratio/region_mean', 'kl_ref', 'gspo/seq_clip_low_frac', 'gspo/seq_clip_high_frac',
             'gspo/abs_log_rho_mean', 'gspo/abs_log_rho_max', 'gspo/log_rho_mean',
             'gspo/abs_log_rho_p50', 'gspo/abs_log_rho_p90', 'clip_ratio/low_min',
             'clip_ratio/high_max', 'gspo/rho_mean']
    sink = self._metrics['train']
    for name, value in zip(names, values.detach().cpu().tolist()):
        if name != 'kl_ref' or kl_seq_mean is not None:
            sink[name].append(value)
    if self._dyn_low_frac > 0 and self._dyn_low_ema is not None:
        sink['gspo/dyn_low_bound'].append(float(torch.exp(self._dyn_low_ema)))


def install_for_benchmark(policy, ref=None):
    target = None
    source_file = None
    frame = sys._getframe(1)
    try:
        while frame is not None:
            candidate = frame.f_globals.get("GSPOAsyncGRPOTrainer")
            if (isinstance(candidate, type) and candidate.__module__ == frame.f_globals.get("__name__")
                    and "_loss_metrics" in candidate.__dict__):
                target = candidate
                source_file = frame.f_globals.get("__file__")
                break
            frame = frame.f_back
    finally:
        del frame
    activation = "executing_frame_globals"
    if target is None:
        from rlforge.trainer import GSPOAsyncGRPOTrainer
        target = GSPOAsyncGRPOTrainer
        source_file = sys.modules[target.__module__].__file__
        activation = "canonical_import"
    original = target._loss_metrics
    metadata = {"class_module": target.__module__, "class_name": target.__qualname__,
                "class_source_file": source_file, "activation": activation}
    seen_ranks = set()

    def activated_loss_metrics(self, *args, **kwargs):
        rank = getattr(self.accelerator, "process_index", int(os.environ.get("RANK", "0")))
        if rank not in seen_ranks:
            seen_ranks.add(rank)
            print(json.dumps({"metrics_batch": {"event": "first_actual_loss_metrics",
                  "rank": rank, "self_class_module": type(self).__module__,
                  "collectives_per_call": 1, **metadata}}), flush=True)
        return loss_metrics(self, *args, **kwargs)

    target._loss_metrics = activated_loss_metrics
    print(json.dumps({"metrics_batch": {"event": "installed",
          "rank": int(os.environ.get("RANK", "0")), **metadata}}), flush=True)

    def restore():
        target._loss_metrics = original

    return restore
