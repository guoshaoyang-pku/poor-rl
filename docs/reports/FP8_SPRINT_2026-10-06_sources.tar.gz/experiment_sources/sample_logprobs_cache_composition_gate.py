"""Frozen bulk/native controls plus cache activation in main and spawned API."""
import hashlib
from pathlib import Path

root = Path(__file__).resolve().parent
base = root / 'serving_frontend_output_dedicated_composition_gate.py'
source = base.read_text()
if hashlib.sha256(base.read_bytes()).hexdigest() != '4dbdddc577a5f4805ddc93707a1918915c80d9316b039ab5a10f30610df36ccd':
    raise RuntimeError('Frozen native composition gate changed')
source = source.replace('serve_frontend_output_dedicated_entry.py', 'serve_sample_logprobs_cache_entry.py')
source = source.replace("assert Scheduler.update_from_output.__code__.co_filename == 'native_per_request_output_fusion'",
                        "assert Scheduler.update_from_output.__code__.co_filename == str(ROOT / 'serving_bulk_decode_prototype.py')")
source = source.replace("assert Scheduler.schedule.__code__.co_filename == str(ROOT / 'serving_decode_scheduler_prototype.py')",
                        "assert Scheduler.schedule.__code__.co_filename == str(ROOT / 'serving_bulk_decode_prototype.py')")
anchor = '    assert main_calls == ([] if run_name'
if source.count(anchor) != 1:
    raise RuntimeError('Frozen native gate assertion changed')
addition = '''
    import serving_sample_logprobs_cache_prototype as sample
    from vllm.entrypoints.openai.completion.protocol import CompletionRequest
    assert sample._INSTALLED and sample._ENABLED
    sample.install()
    assert EngineCore.collective_rpc(object(), 'sprint_sample_logprobs_cache_stats')[0]['installed']
    assert CompletionRequest(model='test',prompt='test',logprobs=0).to_sampling_params(128,{}).flat_logprobs
    assert not CompletionRequest(model='test',prompt='test',logprobs=0,stream=True).to_sampling_params(128,{}).flat_logprobs
    assert not CompletionRequest(model='test',prompt='test',logprobs=2).to_sampling_params(128,{}).flat_logprobs
    assert TestClient(FastAPI()).get('/sprint_sample_logprobs_cache_stats').json()['enabled']
    assert not torch.cuda.is_initialized()
    checks.append('sample_cache_native_flat_final_only_installed_main_or_spawn_rpc_and_api_stats')
'''
source = source.replace(anchor, addition + anchor)
source = source.replace('result = dict(passed=True,',
    "names += ['serve_bulk_frontend_entry.py','serving_bulk_decode_prototype.py','serving_sample_logprobs_cache_prototype.py','sample_logprobs_cache_composition_gate.py']\nresult = dict(passed=True,", 1)
exec(compile(source, str(base), 'exec'), {'__file__': str(base), '__name__': '__main__'})
