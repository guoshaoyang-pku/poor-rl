"""BF16 reference lookahead while the trainer collects its existing GAS batches."""
from __future__ import annotations

import json
import os
from collections import deque
from types import MethodType

from reference_prefetch import ReferenceClient, build_payload
from reference_prefetch import install_for_trainer as install_microbatch_reference


def tensor_identity(tensors):
    return tuple((t.data_ptr(), t._version, tuple(t.shape), str(t.device)) for t in tensors)


class ReferenceAheadClient(ReferenceClient):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.staged = {}
        self.staged_count = 0
        self.max_ahead = int(os.environ.get("RLFORGE_REFERENCE_AHEAD_BATCHES", "64"))
        self.stats.update(ahead_submitted_batches=0, ahead_consumed_batches=0,
                          ahead_fallback_batches=0, ahead_peak_batches=0)

    def _bodies(self, ids, mask, plan):
        bodies = [build_payload(ids, mask, sb, self.reference_sha256,
                                self.source_sha256, self.temperature) for sb in plan]
        slots = [slot for body in bodies for slot in body["expected_slots"]]
        expected = [i - 1 for i in range(1, len(mask)) if mask[i]]
        if sorted(slots) != expected or len({json.dumps(sb, sort_keys=True) for sb in plan}) != len(plan):
            raise ValueError("Ahead plan must score every completion exactly once")
        return bodies, tuple(body["request_sha256"] for body in bodies)

    def stage_lists(self, ids, mask, plan, *, owners=()):
        bodies, signature = self._bodies(ids, mask, plan)
        identity = tensor_identity(owners)
        with self.lock:
            if self.failure is not None or self.closed:
                raise RuntimeError("Reference client failed or closed") from self.failure
            if self.staged_count >= self.max_ahead:
                raise RuntimeError("Reference lookahead exceeds bounded GAS batch capacity")
            pending = {}
            for sb, body in zip(plan, bodies):
                endpoint = self.endpoints[self.next_endpoint % len(self.endpoints)]
                self.next_endpoint += 1
                pending[json.dumps(sb, sort_keys=True)] = (body, self.executor.submit(self._send, endpoint, body))
            self.staged.setdefault(signature, deque()).append((pending, tuple(owners), identity))
            self.staged_count += 1
            self.stats["ahead_submitted_batches"] += 1
            self.stats["ahead_peak_batches"] = max(self.stats["ahead_peak_batches"], self.staged_count)

    def stage_inputs(self, inputs, budget):
        from rlforge.prefix_share import plan_subbatches

        required = ("input_ids", "completion_mask", "attention_mask", "position_ids")
        owners = tuple(inputs[name] for name in required)
        mask = inputs["attention_mask"].bool()
        ids = inputs["input_ids"][mask].detach().cpu().unsqueeze(0)
        cm = inputs["completion_mask"][mask].detach().cpu().unsqueeze(0)
        pos = inputs["position_ids"][mask].detach().cpu().unsqueeze(0)
        plan = plan_subbatches(ids, pos, cm, budget)
        self.stage_lists(ids[0].tolist(), cm[0].tolist(), plan, owners=owners)

    def prefetch(self, input_ids, completion_mask, plan):
        ids = input_ids.detach().cpu()[0].tolist()
        mask = completion_mask.detach().cpu()[0].tolist()
        _bodies, signature = self._bodies(ids, mask, plan)
        with self.lock:
            if self.failure is not None or self.closed:
                raise RuntimeError("Reference client failed or closed") from self.failure
            if self.pending:
                raise RuntimeError("Previous reference microbatch has unconsumed scores")
            queue = self.staged.get(signature)
            entry = queue.popleft() if queue else None
            if entry is not None:
                self.staged_count -= 1
                if not queue:
                    del self.staged[signature]
        if entry is None:
            self.stats["ahead_fallback_batches"] += 1
            return super().prefetch(input_ids, completion_mask, plan)
        pending, owners, identity = entry
        if tensor_identity(owners) != identity:
            for _body, future in pending.values():
                future.cancel()
            error = ValueError("Lookahead batch token/mask tensors changed before consumption")
            self.cancel(error)
            raise error
        self.pending = pending
        self.active_identity = tensor_identity((input_ids, completion_mask))
        self.active_tensors = (input_ids, completion_mask)
        self.stats["ahead_consumed_batches"] += 1

    def cancel(self, error):
        with self.lock:
            staged = [future for queue in self.staged.values() for pending, _owners, _identity in queue
                      for _body, future in pending.values()]
            self.staged.clear()
            self.staged_count = 0
        for future in staged:
            future.cancel()
        super().cancel(error)

    def assert_drained(self):
        if self.staged_count or self.pending:
            raise RuntimeError("Lookahead BF16 scores were not consumed by every staged batch")


def install_for_trainer(trainer, client, *, offload_local_reference=True):
    restore_microbatch = install_microbatch_reference(
        trainer, client, offload_local_reference=offload_local_reference)
    original_get = trainer.get_batch_samples

    def get_batch_samples(self, epoch_iterator, num_batches, device):
        def staged_iterator():
            for batch in epoch_iterator:
                client.stage_inputs(batch, self._sb_tokens)
                yield batch

        return original_get(staged_iterator(), num_batches, device)

    trainer.get_batch_samples = MethodType(get_batch_samples, trainer)
    trainer._reference_ahead = True

    def restore(*, return_reference_to_gpu=True):
        trainer.get_batch_samples = original_get
        trainer._reference_ahead = False
        restore_microbatch(return_reference_to_gpu=return_reference_to_gpu)

    return restore
