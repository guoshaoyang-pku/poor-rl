"""Native CPU decode bookkeeping with the existing dedicated control API."""
import serve_cpu_ssm_entry
import serve_dedicated_control_entry

if __name__ == "__main__":
    serve_dedicated_control_entry.serve_control_observed_entry.serve_pause_observed_entry.serve_kv_bandwidth_entry.serve_kv_observed_entry.serve_driver.main()
