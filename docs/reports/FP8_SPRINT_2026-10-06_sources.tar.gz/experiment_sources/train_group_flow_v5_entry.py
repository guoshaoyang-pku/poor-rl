"""Compose group admission with the frozen deferred V5 training entry."""
import ast
import hashlib
import json
import os
from pathlib import Path

if __name__ in ('__main__', '__mp_main__'):
    if __name__ == '__mp_main__':
        import rollout_group_flow_prototype as flow
        metadata = flow.install()
        print(json.dumps(dict(group_flow=dict(event='spawn_child_installed', pid=os.getpid(),
              source_sha256=hashlib.sha256(Path(flow.__file__).read_bytes()).hexdigest(),
              metadata=metadata))), flush=True)
    path = Path(__file__).with_name('train_deferred_v5_cache_json_host_entry.py')
    namespace = dict(__name__=__name__, __file__=str(Path(__file__)),
                     __package__=None, __builtins__=__builtins__)
    exec(compile(ast.parse(path.read_text()), str(path), 'exec'), namespace)
