"""Compact convolution state with the original eager FP32 SiLU boundary."""
from __future__ import annotations

import torch
import torch.nn.functional as F
import fusion_conv_prototype as compact


def preactivation(x, weight, bias):
    if not x.is_cuda:
        return compact._cpu_pre(x, weight, bias)
    batch, channels, length = x.shape
    time_major = x.stride(1) == 1
    out = (torch.empty((batch, length, channels), device=x.device, dtype=torch.float32).transpose(1, 2)
           if time_major else torch.empty(x.shape, device=x.device, dtype=torch.float32))
    compact._forward_kernel[(compact.triton.cdiv(x.numel(), 256),)](
        x, weight, bias if bias is not None else x, out, x.numel(), length, channels, *x.stride(),
        bias is not None, False, time_major, 256, enable_fp_fusion=False)
    return out


class _Conv(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, weight, bias, silu):
        ctx.set_materialize_grads(False)
        ctx.save_for_backward(x, weight, bias)
        ctx.silu = silu
        pre = preactivation(x, weight, bias)
        return (F.silu(pre) if silu else pre).to(x.dtype)

    @staticmethod
    def backward(ctx, grad):
        if grad is None:
            return None, None, None, None
        x, weight, bias = ctx.saved_tensors
        need_x, need_w, need_b = ctx.needs_input_grad[:3]
        dx = dw = db = None
        upstream = grad.float()
        if ctx.silu:
            pre = preactivation(x, weight, bias)
            upstream = torch.ops.aten.silu_backward(upstream, pre)
        if not x.is_cuda:
            length = x.shape[-1]
            g = upstream.to(x.dtype).float()
            if need_x:
                dx = torch.zeros_like(x, dtype=torch.float32)
                wf = weight.to(x.dtype).float()
                for tap in range(4):
                    delay = 3 - tap
                    if delay < length:
                        dx[..., :length - delay] += g[..., delay:] * wf[:, tap][None, :, None]
                dx = dx.to(x.dtype)
            if need_w:
                padded = F.pad(x.float(), (3, 0))
                dw = torch.stack([(g * padded[..., tap:tap + length]).sum((0, 2)) for tap in range(4)], -1)
                dw = dw.to(x.dtype).to(weight.dtype)
            if need_b:
                db = upstream.sum((0, 2)).to(x.dtype).to(bias.dtype)
            return dx, dw, db, None
        batch, channels, length = x.shape
        time_major = x.stride(1) == 1
        if time_major:
            upstream = upstream.transpose(1, 2).contiguous().transpose(1, 2)
        else:
            upstream = upstream.contiguous()
        if need_x:
            dx = torch.empty_like(upstream, dtype=x.dtype)
            compact._dx_kernel[(compact.triton.cdiv(x.numel(), 256),)](
                upstream, weight, dx, x.numel(), length, channels,
                compact.tl.bfloat16 if x.dtype == torch.bfloat16 else compact.tl.float32,
                time_major, 256, enable_fp_fusion=False)
        if need_w or need_b:
            groups = compact.triton.cdiv(batch * length, 128)
            partial_w = torch.empty((groups, channels, 4), device=x.device, dtype=torch.float32)
            partial_b = torch.empty((groups, channels), device=x.device, dtype=torch.float32) if need_b else partial_w
            compact._dw_kernel[(groups, compact.triton.cdiv(channels, 16))](
                x, upstream, partial_w, partial_b, batch * length, length, channels, *x.stride(), *upstream.stride(),
                need_b, 128, 16, enable_fp_fusion=False)
            if need_w:
                dw = partial_w.sum(0).to(x.dtype).to(weight.dtype)
            if need_b:
                db = partial_b.sum(0).to(x.dtype).to(bias.dtype)
        return dx, dw, db, None


def causal_conv(x, weight, bias, activation):
    if weight.shape != (x.shape[1], 4) or not weight.is_contiguous():
        raise ValueError("Compact convolution requires contiguous four-tap weights")
    if x.dtype not in (torch.bfloat16, torch.float32) or activation not in (None, "silu", "swish"):
        raise ValueError("Compact convolution requires BF16/FP32 and SiLU")
    return _Conv.apply(x, weight, bias, activation is not None)


def install_for_benchmark(policy, ref=None):
    from rlforge import fp8_alignment as alignment
    import fusion_mlp_prototype as mlp

    restore_mlp = mlp.install_for_benchmark(policy, ref=ref)
    original = alignment._causal_conv
    alignment._causal_conv = causal_conv

    def restore():
        alignment._causal_conv = original
        restore_mlp()

    return restore
