"""Reserve the last native API client for weight-control HTTP on a private port."""
import copy
import functools
import json
import os
import time

_INSTALLED = False
_IS_CONTROL = False
_CONTROL_PATHS = {'/health', '/ping', '/version', '/metrics', '/server_info'}


def is_control_client(args, client_config):
    count = int(client_config.get('client_count', 1))
    if count < 2 or count != args.api_server_count:
        raise ValueError('Dedicated control requires an explicit API count of at least two')
    return int(client_config.get('client_index', 0)) == count - 1


def retain_control_routes(app):
    app.router.routes[:] = [
        route for route in app.router.routes
        if getattr(route, 'path', None) in _CONTROL_PATHS
        or getattr(getattr(route, 'endpoint', None), '__module__', '')
        == 'vllm.entrypoints.serve.dev.rlhf.api_router'
    ]
    if not {'/pause', '/resume', '/update_weights'}.issubset(
        {getattr(route, 'path', None) for route in app.router.routes}
    ):
        raise RuntimeError('Native RLHF control routes were not registered')
    return app


def install():
    global _INSTALLED
    if _INSTALLED:
        return
    from vllm.entrypoints.launchers import launcher
    from vllm.entrypoints.launchers.api_server import entry

    native_worker = entry.run_server_worker
    native_build_app = entry.build_app

    @functools.wraps(native_worker)
    async def worker(listen_address, sock, args, client_config=None, **kwargs):
        global _IS_CONTROL
        port = int(os.environ.get('SPRINT_CONTROL_PORT', '0'))
        if not port:
            return await native_worker(listen_address, sock, args, client_config, **kwargs)
        if not 1 <= port <= 65535 or port == args.port or getattr(args, 'uds', None):
            raise ValueError('Dedicated control requires a distinct valid TCP port')
        _IS_CONTROL = is_control_client(args, client_config or {})
        if not _IS_CONTROL:
            return await native_worker(listen_address, sock, args, client_config, **kwargs)
        private_args = copy.copy(args)
        private_args.host = os.environ.get('SPRINT_CONTROL_HOST', '127.0.0.1')
        private_args.port = port
        sock.close()
        private_address, private_socket = launcher.setup_server(private_args, reuse_port=False)
        print('SPRINT_DEDICATED_CONTROL ' + json.dumps({
            'pid': os.getpid(), 'wall_ns': time.time_ns(),
            'monotonic_ns': time.perf_counter_ns(),
            'client_count': client_config['client_count'],
            'client_index': client_config['client_index'],
            'control_host': private_args.host, 'control_port': port,
            'generation_port': args.port, 'shared_native_engine_addresses': True,
        }), flush=True)
        try:
            return await native_worker(private_address, private_socket, private_args,
                                       client_config, **kwargs)
        finally:
            private_socket.close()

    @functools.wraps(native_build_app)
    def build_app(*args, **kwargs):
        app = native_build_app(*args, **kwargs)
        return retain_control_routes(app) if _IS_CONTROL else app

    entry.run_server_worker = worker
    entry.build_app = build_app
    _INSTALLED = True


def cpu_gate():
    import asyncio
    from argparse import Namespace
    from unittest.mock import patch
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from vllm.entrypoints.serve.dev.rlhf import api_router
    from vllm.entrypoints.launchers import launcher
    from vllm.entrypoints.launchers.api_server import entry

    checks = []
    calls = []

    class Engine:
        async def pause_generation(self, **kwargs):
            calls.append(('pause', kwargs))

        async def resume_generation(self):
            calls.append(('resume', None))

        async def init_weight_transfer_engine(self, request):
            calls.append(('init', request.init_info))

        async def start_weight_update(self):
            calls.append(('start', None))

        async def update_weights(self, request):
            calls.append(('update', request.update_info))

        async def finish_weight_update(self, version):
            calls.append(('finish', version))

    app = FastAPI()
    app.state.engine_client = Engine()
    api_router.attach_router(app)

    @app.post('/v1/completions')
    async def generation():
        return {'generation': True}

    @app.get('/health')
    async def health():
        return {'status': 'ok'}

    client = TestClient(retain_control_routes(app))
    requests = [('/pause?mode=keep', None), ('/resume', None),
                ('/init_weight_transfer_engine', {'init_info': {'world_size': 8}}),
                ('/start_weight_update', {'is_checkpoint_format': True}),
                ('/update_weights', {'update_info': {'names': ['weight'], 'dtypes': ['float32']}}),
                ('/finish_weight_update', None)]
    for path, body in requests:
        response = client.post(path, json=body) if body is not None else client.post(path)
        assert response.status_code == 200, (path, response.text)
        checks.append(path)
    assert calls[0] == ('pause', {'mode': 'keep', 'clear_cache': True,
                                'wait_for_inflight_requests': False})
    assert calls[2][1] == requests[2][1]['init_info']
    assert calls[4][1] == requests[4][1]['update_info']
    assert client.post('/v1/completions').status_code == 404
    assert client.get('/health').status_code == 200
    checks += ['native_payloads', 'no_generation_routes', 'health']

    args = Namespace(api_server_count=8, port=8039, host='0.0.0.0', uds=None)
    config = {'client_count': 8, 'client_index': 7, 'input_address': 'input',
              'output_address': 'output', 'stats_update_address': 'stats'}
    assert is_control_client(args, config)
    assert not is_control_client(args, dict(config, client_index=6))
    captured = []

    async def native_worker(address, sock, worker_args, cfg, **kwargs):
        captured.append((address, sock, worker_args, cfg, kwargs))
        return 'native_return'

    class Socket:
        closed = False

        def close(self):
            self.closed = True

    inherited, private = Socket(), Socket()
    with patch.object(entry, 'run_server_worker', native_worker), \
         patch.object(entry, 'build_app', lambda *a, **k: app), \
         patch.object(launcher, 'setup_server', return_value=('private', private)) as setup, \
         patch.dict(os.environ, {'SPRINT_CONTROL_PORT': '8040'}, clear=False):
        install()
        result = asyncio.run(entry.run_server_worker('generation', inherited, args, config, native_option=True))
        assert result == 'native_return' and inherited.closed and private.closed
        assert captured[-1][3] is config and captured[-1][4] == {'native_option': True}
        assert captured[-1][2].port == 8040 and args.port == 8039
        setup.assert_called_once()
        checks += ['private_worker_native_return', 'native_client_config_identity',
                   'private_socket_lifecycle', 'original_args_unchanged']
        public = Socket()
        public_cfg = dict(config, client_index=0)
        result = asyncio.run(entry.run_server_worker('generation', public, args, public_cfg))
        assert result == 'native_return' and not public.closed
        assert captured[-1][:4] == ('generation', public, args, public_cfg)
        checks.append('generation_worker_unchanged')
    return {'passed': True, 'checks': checks, 'check_count': len(checks),
            'scope': 'CPU native RLHF router, payloads, worker wiring; no GPU throughput claim'}


if __name__ == '__main__':
    print(json.dumps(cpu_gate(), indent=2))
