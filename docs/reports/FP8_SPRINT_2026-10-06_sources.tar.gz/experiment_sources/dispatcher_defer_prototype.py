"""Yield a ready infinite RL batch before fetching the following global batch."""
import ast
import hashlib
import inspect
import textwrap


NATIVE_ITER_SHA256 = '7213231277a21320e60f74917d1666ab3f508c6ffdf9547ff18b312f32227ba2'


def build_iterator(native):
    source = inspect.getsource(native)
    if hashlib.sha256(source.encode()).hexdigest() != NATIVE_ITER_SHA256:
        raise ValueError('Installed Accelerate dispatcher iterator changed')
    tree = ast.parse(textwrap.dedent(source))
    function = tree.body[0]
    loops = [node for node in function.body if isinstance(node, ast.While)]
    if len(loops) != 1:
        raise ValueError('Expected one native dispatch loop')
    loop = loops[0]
    lookahead = [node for node in loop.body if isinstance(node, ast.If)
                 and ast.unparse(node.test) == 'not stop_iteration']
    if len(lookahead) != 1 or ast.unparse(loop.body[-1]) != 'batch_index += 1':
        raise ValueError('Native dispatcher lookahead boundary changed')
    fetch = lookahead[0].body[0]
    fetch_ast = ast.dump(ast.parse('next_batch, next_batch_info = self._fetch_batches(main_iterator)').body[0])
    if ast.dump(fetch) != fetch_ast:
        raise ValueError('Unexpected native next-batch fetch')
    loop.body.remove(lookahead[0])
    guard = ast.parse("if self._stop_iteration or next_batch_info[0] is None:\n"
                      "    raise RuntimeError('Infinite rollout dispatcher ended unexpectedly')").body[0]
    loop.body.extend([fetch, guard])
    initial = next(i for i, node in enumerate(function.body)
                   if ast.dump(node) == fetch_ast)
    function.body.insert(initial + 1, ast.parse(ast.unparse(guard)).body[0])
    size = next(i for i, node in enumerate(loop.body)
                if ast.unparse(node) == 'observed_batch_size = find_batch_size(batch)')
    loop.body.insert(size + 1, ast.parse(
        "if observed_batch_size != self.state.num_processes:\n"
        "    raise RuntimeError('Rollout dispatcher requires exactly one packed row per rank')"
    ).body[0])
    function.name = '_deferred_infinite_iter'
    namespace = dict(native.__globals__)
    exec(compile(ast.fix_missing_locations(tree), __file__, 'exec'), namespace)
    return namespace[function.name]


def supported(loader):
    return (getattr(loader, '_sprint_infinite_rollout', False)
            and loader.split_batches and loader.submesh_tp is None
            and loader.skip_batches >= 0 and loader.base_dataloader.batch_size == 1
            and loader.base_dataloader.num_workers == 0)


def mark(loader):
    from accelerate.data_loader import DataLoaderDispatcher
    from rlforge.prefix_share import BalancedGroupRowBatcher
    from trl.experimental.async_grpo.async_grpo_trainer import RolloutQueueDataset, _EmptyIterableDataset

    if not isinstance(loader, DataLoaderDispatcher):
        raise ValueError('Expected native Accelerate dispatcher')
    dataset = loader.base_dataloader.dataset
    if loader.state.process_index == 0:
        valid = type(dataset) is BalancedGroupRowBatcher and type(dataset.dataset) is RolloutQueueDataset
    else:
        valid = type(dataset) is _EmptyIterableDataset
    if not valid:
        raise ValueError('Deferred dispatch is restricted to the infinite balanced rollout stream')
    loader._sprint_infinite_rollout = True
    if not supported(loader):
        raise ValueError('Unsupported deferred rollout dispatcher configuration')
    return loader


def install():
    from accelerate.data_loader import DataLoaderDispatcher
    from trl.experimental.async_grpo import AsyncGRPOTrainer

    native_iter = DataLoaderDispatcher.__iter__
    deferred = build_iterator(native_iter)
    native_loader = AsyncGRPOTrainer.get_train_dataloader

    def iterate(self):
        return deferred(self) if supported(self) else native_iter(self)

    def get_train_dataloader(self):
        return mark(native_loader(self))

    DataLoaderDispatcher.__iter__ = iterate
    AsyncGRPOTrainer.get_train_dataloader = get_train_dataloader
    return dict(native_iterator_sha256=NATIVE_ITER_SHA256,
                change='fetch following global batch after yielding current ready batch',
                admission_timing_changed=True, staleness_limits_changed=False)
