"""Future native-KV decode-only scheduler, with all other cases falling back."""
import os

_INSTALLED = False
_ENABLED = False
_COUNTS = {'fast_steps': 0, 'fallback_steps': 0, 'fast_requests': 0}


def install():
    global _INSTALLED
    if _INSTALLED:
        return
    from vllm.v1.core.sched.scheduler import Scheduler, PauseState
    from vllm.v1.core.sched.output import CachedRequestData, SchedulerOutput
    from vllm.v1.core.single_type_kv_cache_manager import FullAttentionManager, MambaManager
    from vllm.v1.kv_cache_interface import FullAttentionSpec
    from vllm.v1.request import RequestStatus
    native = Scheduler.schedule

    def schedule(self, throttle_prefills=False):
        running = self.running
        manager = self.kv_cache_manager
        config = self.scheduler_config
        supported = (
            _ENABLED and running and not self.waiting and not self.skipped_waiting
            and self._pause_state == PauseState.UNPAUSED
            and self.use_v2_model_runner and not self.use_pp
            and not self.vllm_config.speculative_config and not self.num_spec_tokens
            and not self.num_lookahead_tokens and not self.num_prefill_lookahead
            and self.num_sampled_tokens_per_step == 1
            and self.connector is None and self.ec_connector is None
            and self.lora_config is None and not self.is_encoder_decoder
            and not self.enable_return_routed_experts and not self.return_sampling_mask
            and not self.dynamic_sd_lookup and not self._inflight_prefills
            and not self.num_waiting_for_streaming_input
            and len(running) <= self.max_num_running_reqs
            and len(running) <= min(self.max_num_scheduled_tokens, config.max_num_batched_tokens)
            and not (self.log_stats and self.observability_config.enable_logging_iteration_details))
        if supported:
            groups = manager.coordinator.single_type_managers
            block = manager.coordinator.scheduler_block_size
            supported = (manager.enable_caching
                and not manager.coordinator.eagle_group_ids
                and all((type(m) is FullAttentionManager and type(m.kv_cache_spec) is FullAttentionSpec
                         or type(m) is MambaManager and m.mamba_cache_mode == 'align'
                         and not m.num_speculative_blocks and not m.has_prefill_checkpoint_blocks)
                        and m.block_size == block for m in groups))
        if supported:
            step = self.current_step + 1
            for request in running:
                t = request.num_computed_tokens
                placeholders = request.num_output_placeholders
                if (request.status != RequestStatus.RUNNING or request.resumable
                    or request.is_prefill_chunk or request.has_encoder_inputs
                    or request.use_structured_output or request.spec_token_ids
                    or request.next_decode_eligible_step > step
                    or t < request.num_prompt_tokens or t >= self.max_model_len - self.num_sampled_tokens_per_step
                    or request.num_tokens_with_spec + placeholders - t != 1
                    or placeholders > 0 and t + 2 - placeholders >= request.num_prompt_tokens + request.max_tokens
                    or t < request.num_tokens - 1):
                    supported = False
                    break
            required_free = 2 * len(running) * len(groups)
            if supported and manager.block_pool.get_num_free_blocks() < required_free + manager.watermark_blocks:
                supported = False
        if not supported:
            _COUNTS['fallback_steps'] += 1
            return native(self, throttle_prefills)

        self.current_step += 1
        self.prefill_capacity_bound = False
        manager.new_step_starts()
        req_ids, blocks, computed, output = [], [], [], []
        scheduled = {}
        for request in running:
            rid = request.request_id
            new = manager.allocate_slots(request, 1, num_lookahead_tokens=0)
            if new is None:
                raise RuntimeError('Decode scheduler free-block proof failed; abort diagnostic')
            req_ids.append(rid)
            scheduled[rid] = 1
            blocks.append(new.get_block_ids(allow_none=True))
            computed.append(request.num_computed_tokens)
            output.append(request.num_output_tokens + request.num_output_placeholders)
        manager.take_boundary_state_offloads()
        copies, retained = manager.take_kv_cache_block_copies()
        if copies:
            self._free_cow_retained_blocks(retained, self.sched_step_seq + 1)
        result = SchedulerOutput(
            scheduled_new_reqs=[],
            scheduled_cached_reqs=CachedRequestData(
                req_ids=req_ids, resumed_req_ids=set(), new_token_ids=[], all_token_ids={},
                new_block_ids=blocks, num_computed_tokens=computed, num_output_tokens=output),
            num_scheduled_tokens=scheduled, total_num_scheduled_tokens=len(running),
            scheduled_spec_decode_tokens={}, scheduled_encoder_inputs={},
            num_common_prefix_blocks=manager.get_num_common_prefix_blocks(running[0].request_id),
            preempted_req_ids=self.reset_preempted_req_ids, finished_req_ids=self.finished_req_ids,
            free_encoder_mm_hashes=self.encoder_cache_manager.get_freed_mm_hashes(),
            new_block_ids_to_zero=self._get_new_block_ids_to_zero(),
            kv_cache_block_copies=copies or None, num_spec_tokens_to_schedule=0,
            ec_manager_metadata=self.encoder_cache_manager.get_manager_metadata())
        if self.defer_block_free:
            self.sched_step_seq += 1
        self._update_after_schedule(result)
        _COUNTS['fast_steps'] += 1
        _COUNTS['fast_requests'] += len(running)
        return result

    Scheduler.schedule = schedule
    _INSTALLED = True


def toggle(enabled):
    global _ENABLED
    _ENABLED = enabled
    return stats()


def stats():
    return {'pid': os.getpid(), 'installed': _INSTALLED, 'enabled': _ENABLED,
            'counts': dict(_COUNTS),
            'boundary': 'Decode-only native KV allocations; unsupported/admission/tail cases use native scheduler'}
