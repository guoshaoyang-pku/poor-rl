"""Observe native HTTP, renderer, AsyncLLM and utility-control latency."""
import asyncio
import contextvars
import functools
import json
import os
import time

_INSTALLED = False
_PENDING = {}
_RECORDS = []
_HTTP_NUMBER = 0
_CONTROL_ID = contextvars.ContextVar('poor_rl_control_id', default=None)
_METHODS = {'pause_scheduler', 'resume_scheduler'}
_PATHS = {'/pause', '/resume', '/start_weight_update', '/update_weights', '/finish_weight_update'}


def emit(event, **values):
    row = {'pid': os.getpid(), 'wall_ns': time.time_ns(),
           'monotonic_ns': time.perf_counter_ns(), 'event': event,
           'control_id': _CONTROL_ID.get(), **values}
    _RECORDS.append(row)
    del _RECORDS[:-192]
    print('SPRINT_CONTROL ' + json.dumps(row), flush=True)
    return row


def stats():
    return {'pid': os.getpid(), 'records': list(_RECORDS),
            'scope': 'Native control observations; nested durations must not be added'}


async def _loop_lag(result):
    interval = 0.05
    while True:
        start = time.perf_counter_ns()
        await asyncio.sleep(interval)
        lag = max(0.0, (time.perf_counter_ns() - start) / 1e6 - interval * 1000)
        result['max_loop_lag_ms'] = max(result['max_loop_lag_ms'], lag)
        result['loop_samples'] += 1


def install():
    global _INSTALLED
    if _INSTALLED:
        return
    import msgspec
    from fastapi import FastAPI
    from vllm.renderers.base import BaseRenderer
    from vllm.v1.engine import EngineCoreRequestType
    from vllm.v1.engine import core_client
    from vllm.v1.engine.async_llm import AsyncLLM

    native_asgi = FastAPI.__call__
    native_pause = AsyncLLM.pause_generation
    native_resume = AsyncLLM.resume_generation
    native_clear = BaseRenderer.clear_mm_cache_async
    native_call = core_client.AsyncMPClient._call_utility_async
    native_send = core_client.AsyncMPClient._send_input_message
    native_output = core_client._process_utility_output

    @functools.wraps(native_asgi)
    async def asgi(self, scope, receive, send):
        global _HTTP_NUMBER
        if scope.get('type') != 'http' or scope.get('path') not in _PATHS:
            return await native_asgi(self, scope, receive, send)
        _HTTP_NUMBER += 1
        number = _HTTP_NUMBER
        path = scope['path']
        headers = dict(scope.get('headers', ()))
        value = headers.get(b'x-poor-rl-control-id', b'')
        control_id = value.decode('ascii', errors='replace')[:128] or None
        token = _CONTROL_ID.set(control_id)
        start = time.perf_counter_ns()
        lag = {'max_loop_lag_ms': 0.0, 'loop_samples': 0}
        monitor = asyncio.create_task(_loop_lag(lag))
        emit('http_begin', path=path, number=number)

        async def observed_send(message):
            if message['type'] == 'http.response.start':
                emit('http_response_start', path=path, number=number,
                     status=message['status'], elapsed_ms=(time.perf_counter_ns() - start) / 1e6)
            return await send(message)

        try:
            return await native_asgi(self, scope, receive, observed_send)
        finally:
            monitor.cancel()
            try:
                await monitor
            except asyncio.CancelledError:
                pass
            emit('http_end', path=path, number=number,
                 elapsed_ms=(time.perf_counter_ns() - start) / 1e6, **lag)
            _CONTROL_ID.reset(token)

    def llm_wrapper(native, method):
        @functools.wraps(native)
        async def observed(self, *args, **kwargs):
            start = time.perf_counter_ns()
            emit('llm_begin', method=method, client_class=type(self.engine_core).__name__,
                 mode=kwargs.get('mode'), clear_cache=kwargs.get('clear_cache', True))
            try:
                return await native(self, *args, **kwargs)
            finally:
                emit('llm_end', method=method, elapsed_ms=(time.perf_counter_ns() - start) / 1e6)
        return observed

    @functools.wraps(native_clear)
    async def clear(self, *args, **kwargs):
        start = time.perf_counter_ns()
        emit('renderer_clear_begin', multimodal_cache=self.mm_processor_cache is not None)
        try:
            return await native_clear(self, *args, **kwargs)
        finally:
            emit('renderer_clear_end', elapsed_ms=(time.perf_counter_ns() - start) / 1e6)

    @functools.wraps(native_call)
    async def call(self, method, *args, **kwargs):
        if method not in _METHODS:
            return await native_call(self, method, *args, **kwargs)
        start = time.perf_counter_ns()
        engine = kwargs.get('engine')
        identity = engine.hex() if isinstance(engine, bytes) else str(engine)
        emit('utility_call_begin', method=method, engine=identity, client_index=self.client_index)
        try:
            return await native_call(self, method, *args, **kwargs)
        finally:
            emit('utility_call_end', method=method, engine=identity,
                 elapsed_ms=(time.perf_counter_ns() - start) / 1e6)

    @functools.wraps(native_send)
    def send_message(self, message, engine):
        control = None
        if message[0] == EngineCoreRequestType.UTILITY.value:
            request = msgspec.msgpack.decode(message[1])
            if request[2] in _METHODS:
                control = {'client_index': request[0], 'call_id': request[1], 'method': request[2],
                           'engine': engine.hex() if isinstance(engine, bytes) else str(engine),
                           'control_id': _CONTROL_ID.get()}
        if control is None:
            return native_send(self, message, engine)
        start = time.perf_counter_ns()
        _PENDING[control['call_id']] = dict(control, started_ns=start)
        emit('utility_send_begin', **control)
        awaitable = native_send(self, message, engine)

        async def completed():
            try:
                return await awaitable
            finally:
                emit('utility_send_end', elapsed_ms=(time.perf_counter_ns() - start) / 1e6, **control)
        return completed()

    @functools.wraps(native_output)
    def output(result, futures):
        pending = _PENDING.pop(result.call_id, None)
        if pending is not None:
            emit('utility_reply_received', elapsed_ms=(time.perf_counter_ns() - pending['started_ns']) / 1e6,
                 **{k: v for k, v in pending.items() if k != 'started_ns'})
        return native_output(result, futures)

    FastAPI.__call__ = asgi
    AsyncLLM.pause_generation = llm_wrapper(native_pause, 'pause_generation')
    AsyncLLM.resume_generation = llm_wrapper(native_resume, 'resume_generation')
    BaseRenderer.clear_mm_cache_async = clear
    core_client.AsyncMPClient._call_utility_async = call
    core_client.AsyncMPClient._send_input_message = send_message
    core_client._process_utility_output = output
    _INSTALLED = True
