"""Per-request ordinary decode output fusion with untouched native rare-path/tail."""
import hashlib
import inspect
import os
import textwrap

INSTALLED=False
ENABLED=True
COUNTS={'fast_requests':0,'native_requests':0}
SOURCE_SHA='ac3f8f3f3a48ad50089e0dff3fd0f56bebf262e1664a788e23b86fdf3d4cd0d6'


def install():
    global INSTALLED
    if INSTALLED:
        return
    from vllm.v1.core.sched.scheduler import Scheduler
    native=Scheduler.update_from_output
    source=inspect.getsource(native)
    if hashlib.sha256(source.encode()).hexdigest()!=SOURCE_SHA:
        raise RuntimeError('Native output source changed; per-request fusion not installed')
    anchor='            scheduled_spec_token_ids = (\n'
    if source.count(anchor)!=1:
        raise RuntimeError('Native output loop anchor changed')
    fast_branch = """
            params=request.sampling_params
            if (_sprint_output_enabled() and num_tokens_scheduled==1
                    and not output_is_stale and request.status==RequestStatus.RUNNING
                    and len(generated_token_ids)==1 and params is not None
                    and not request.resumable and not request.mm_features
                    and request.structured_output_request is None and not request.pooling_params
                    and params.repetition_detection is None and request.prefill_stats is None
                    and not request.is_prefill_chunk and not self.is_mm_encoder_only
                    and not self.enable_return_routed_experts and not self.return_sampling_mask
                    and not scheduler_output.scheduled_spec_decode_tokens
                    and not self.num_spec_tokens and self.num_sampled_tokens_per_step==1
                    and pooler_outputs is None and routing_data is None
                    and req_id not in prompt_logprobs_dict
                    and request.num_output_placeholders>=1
                    and request.num_computed_tokens>=request.num_prompt_tokens
                    and len(request._all_token_ids)+1<self.max_model_len
                    and len(request._output_token_ids)+1<request.max_tokens
                    and generated_token_ids[0]!=params.eos_token_id
                    and generated_token_ids[0] not in (params.stop_token_ids or ())):
                token=generated_token_ids[0]
                request._output_token_ids.append(token)
                request._all_token_ids.append(token)
                if request._block_hasher is not None:
                    request.block_hashes.extend(request._block_hasher(request))
                request.num_output_placeholders-=1
                self.kv_cache_manager.cache_blocks(request,
                    request.num_computed_tokens-request.num_output_placeholders)
                fast_logprobs=None
                if params.num_logprobs is not None and logprobs:
                    fast_logprobs=logprobs.slice_request(req_index,1)
                if num_nans_in_logits is not None and req_id in num_nans_in_logits:
                    request.num_nans_in_logits=num_nans_in_logits[req_id]
                fast_events=request.events
                if fast_events:
                    request.events=[]
                else:
                    fast_events=None
                outputs[request.client_index].append(EngineCoreOutput(
                    request_id=req_id,new_token_ids=generated_token_ids,new_logprobs=fast_logprobs,
                    stop_reason=request.stop_reason,events=fast_events,trace_headers=request.trace_headers,
                    num_nans_in_logits=request.num_nans_in_logits))
                _sprint_output_counts['fast_requests']+=1
                continue
            _sprint_output_counts['native_requests']+=1
"""
    source=source.replace(anchor,fast_branch+anchor)
    namespace=dict(native.__globals__)
    namespace.update(_sprint_output_enabled=lambda:ENABLED,_sprint_output_counts=COUNTS)
    exec(compile(textwrap.dedent(source),'native_per_request_output_fusion','exec'),namespace)
    Scheduler.update_from_output=namespace['update_from_output']
    INSTALLED=True


def toggle(enabled):
    global ENABLED
    ENABLED=enabled
    return stats()


def stats():
    return {'pid':os.getpid(),'installed':INSTALLED,'enabled':ENABLED,'counts':dict(COUNTS),
        'native_source_sha256':SOURCE_SHA,
        'boundary':'Source-pinned native function prefix/tail unchanged; only ordinary one-token request branch fused; native stops/stale/spec/prefill/events/statistics retained'}
