"""Future serving diagnostic, preserving the frozen CPU serving recipe."""
import serve_cpu_ssm_entry
import serving_host_timeline_observer

serving_host_timeline_observer.install()
if __name__ == '__main__':
    serve_cpu_ssm_entry.serve_pause_observed_entry.serve_kv_bandwidth_entry.serve_kv_observed_entry.serve_driver.main()
