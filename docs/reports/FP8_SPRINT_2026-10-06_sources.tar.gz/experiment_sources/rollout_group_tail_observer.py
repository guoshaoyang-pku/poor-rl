"""Observe G32 tail members and client request counts without changing admission."""
import ast
import hashlib
import json
import os
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path


def snapshot(loop, pending, completed, inflight, started, now):
    tasks_by_group = defaultdict(list)
    for task, metadata in inflight.items():
        tasks_by_group[metadata[0]].append(task)
    unharvested_hist, unfinished_hist = Counter(), Counter()
    groups = []
    totals = Counter()
    for group_id, group in pending.items():
        tasks = tasks_by_group[group_id]
        done = sum(task.done() for task in tasks)
        running = len(tasks) - done
        harvested = completed[group_id]
        undispatched = loop.num_generations - harvested - len(tasks)
        if undispatched < 0:
            raise RuntimeError('Tail observer found more than G group members')
        unharvested = loop.num_generations - harvested
        unfinished = running + undispatched
        unharvested_hist[unharvested] += 1
        unfinished_hist[unfinished] += 1
        totals.update(running_tasks=running, done_unharvested_tasks=done,
                      undispatched_members=undispatched, harvested_members=harvested)
        mono, wall, version = started[group_id]
        groups.append(dict(group_id=int(group_id), age_s=now - mono,
                           dispatch_epoch=wall, model_version=version,
                           version_lag=loop.model_version - version,
                           harvested_members=harvested, running_tasks=running,
                           done_unharvested_tasks=done, undispatched_members=undispatched))
    router = getattr(loop, '_router', None)
    load = list(router.load) if router else []
    return dict(pending_groups=len(pending), inflight_tasks=len(inflight),
                running_tasks=totals['running_tasks'],
                done_unharvested_tasks=totals['done_unharvested_tasks'],
                undispatched_members=totals['undispatched_members'],
                harvested_members_in_pending_groups=totals['harvested_members'],
                unharvested_member_hist=dict(sorted(unharvested_hist.items())),
                unfinished_member_hist=dict(sorted(unfinished_hist.items())),
                oldest_pending_age_s=max((row['age_s'] for row in groups), default=0.0),
                oldest_pending_version_lag=max((row['version_lag'] for row in groups), default=0),
                oldest_pending_groups=sorted(groups, key=lambda row: row['age_s'], reverse=True)[:10],
                router_client_requests_per_dp=load, router_client_requests=sum(load),
                router_pinned_prompts=len(router._pin) if router else 0,
                boundary='Tasks and router load are client work, not GPU scheduler running requests. Ages cover pending generation groups only.')


def transform(tree):
    method = tree.body[0]
    assignment = next(i for i, node in enumerate(method.body)
                      if isinstance(node, ast.Assign) or isinstance(node, ast.AnnAssign))
    if not isinstance(method, ast.AsyncFunctionDef) or method.name != '_generate_loop':
        raise ValueError('Expected native generation method')
    method.body.insert(assignment, ast.parse('poor_rl_tail_started = {}').body[0])
    added = removed = 0
    for node in list(ast.walk(method)):
        if not hasattr(node, 'body') or not isinstance(node.body, list):
            continue
        for index, child in reversed(list(enumerate(node.body))):
            if ast.unparse(child) == 'pending_completed[group_id] = 0':
                node.body.insert(index + 1, ast.parse(
                    'poor_rl_tail_started[group_id] = (time.monotonic(), time.time(), pending_groups[group_id].model_version)'
                ).body[0])
                added += 1
            elif ast.unparse(child) == 'del pending_groups[group_id]':
                node.body.insert(index + 1, ast.parse('del poor_rl_tail_started[group_id]').body[0])
                removed += 1
    if added != 1 or removed != 1:
        raise ValueError('Native group lifecycle changed')
    return ast.fix_missing_locations(tree)


def install():
    import rollout_group_flow_prototype as flow
    if getattr(flow, '_poor_rl_tail_observer_installed', False):
        raise ValueError('Tail observer installed twice')
    native_transform, native_observe = flow.transform, flow.observe

    def observed_transform(source, cap):
        return transform(native_transform(source, cap))

    def observe(loop, pending, ready, dispatched):
        native_observe(loop, pending, ready, dispatched)
        now = time.monotonic()
        if now - getattr(loop, '_poor_rl_tail_last_log', 0.0) < 10.0:
            return
        loop._poor_rl_tail_last_log = now
        frame = sys._getframe(1)
        try:
            local = frame.f_locals
            result = snapshot(loop, pending, local['pending_completed'],
                              local['inflight_tasks'], local['poor_rl_tail_started'], now)
        finally:
            del frame
        result.update(utc_epoch=time.time(), model_version=loop.model_version,
                      cap_groups=loop._poor_rl_group_flow['cap_groups'])
        output = os.getenv('SCALE_OUT')
        if output:
            with (Path(output) / 'group_tail_runtime.jsonl').open('a') as stream:
                stream.write(json.dumps(result) + '\n')

    flow.transform, flow.observe = observed_transform, observe
    flow._poor_rl_tail_observer_installed = True
    return dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                generation_score_and_admission_unchanged=True,
                per_group_timestamp_and_10s_snapshots=True)
