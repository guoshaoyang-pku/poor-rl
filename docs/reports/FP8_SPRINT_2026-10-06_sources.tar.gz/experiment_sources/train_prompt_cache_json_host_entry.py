"""Compose full-response JSON decoding with the frozen prompt-cache entry."""
import ast
import hashlib
import json
import os
from pathlib import Path


def main():
    if __name__ == '__mp_main__':
        import rollout_http_json_prototype as decoder
        from rlforge import dp_route

        metadata = decoder.install()
        print(json.dumps(dict(rollout_json=dict(event='spawn_child_installed', pid=os.getpid(),
              metadata=metadata, source_sha256=hashlib.sha256(Path(decoder.__file__).read_bytes()).hexdigest(),
              entry_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))), flush=True)
    path = Path(__file__).with_name('train_prompt_cache_host_entry.py')
    namespace = dict(__name__=__name__, __file__=str(Path(__file__)),
                     __package__=None, __builtins__=__builtins__)
    exec(compile(ast.parse(path.read_text()), str(path), 'exec'), namespace)
    if __name__ == '__mp_main__':
        native_run = dp_route.GroupAffineRolloutLoop.run

        def run(self):
            try:
                return native_run(self)
            finally:
                print(json.dumps(dict(rollout_json=dict(event='final', pid=os.getpid(),
                                                       counters=decoder.stats()))), flush=True)

        dp_route.GroupAffineRolloutLoop.run = run


if __name__ in ('__main__', '__mp_main__'):
    main()
