"""Per-request native decode output fusion with frozen dedicated-control recipe."""
import serve_kv_partial_dedicated_entry
import serving_output_request_prototype as output
from vllm.v1.engine.core import EngineCore

output.install()
native_rpc=EngineCore.collective_rpc


def collective_rpc(self,method,timeout=None,args=(),kwargs=None):
    if method=='sprint_output_request_stats':
        return [output.stats()]
    if method=='sprint_output_request_toggle':
        return [output.toggle(args[0]=='1')]
    return native_rpc(self,method,timeout,args,kwargs)


EngineCore.collective_rpc=collective_rpc
if __name__=='__main__':
    import serve_cpu_dedicated_entry
    serve_cpu_dedicated_entry.serve_dedicated_control_entry.serve_control_observed_entry.serve_pause_observed_entry.serve_kv_bandwidth_entry.serve_kv_observed_entry.serve_driver.main()
