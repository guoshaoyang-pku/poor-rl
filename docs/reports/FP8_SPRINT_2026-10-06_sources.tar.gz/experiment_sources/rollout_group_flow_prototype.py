"""Bound whole-group inventory while continuing to harvest completed requests."""
import ast
import hashlib
import inspect
import json
import math
import os
import textwrap
import time
from collections import deque
from pathlib import Path

NATIVE_HASH_PREFIX = '699c7c7bfbe2b7b0'


def inventory(loop, pending, ready):
    return (len(pending) + len(ready) + loop._groups_to_score.qsize()
            + len(loop._score_tasks)
            + math.ceil(loop.rollout_buffer.qsize() / loop.num_generations))


def observe(loop, pending, ready, dispatched):
    state = loop._poor_rl_group_flow
    count = inventory(loop, pending, ready)
    state.update(pending_groups=len(pending), ready_groups=len(ready),
                 score_queue_groups=loop._groups_to_score.qsize(),
                 score_tasks=len(loop._score_tasks), buffer_samples=loop.rollout_buffer.qsize(),
                 inventory_groups=count, dispatched_samples=dispatched,
                 peak_inventory_groups=max(state.get('peak_inventory_groups', 0), count))
    now = time.monotonic()
    if now - state.get('last_log_monotonic', 0) >= 10:
        state['last_log_monotonic'] = now
        row = dict(state, utc_epoch=time.time(), model_version=loop.model_version)
        output = os.getenv('SCALE_OUT')
        if output:
            with (Path(output) / 'group_flow_runtime.jsonl').open('a') as stream:
                stream.write(json.dumps(row) + '\n')


def transform(source, cap):
    if cap < 1:
        raise ValueError('Group inventory cap must be positive')
    tree = ast.parse(textwrap.dedent(source))
    method = tree.body[0]
    if not isinstance(method, ast.AsyncFunctionDef) or method.name != '_generate_loop':
        raise ValueError('Native generation method changed')
    work = next(i for i, n in enumerate(method.body)
                if ast.unparse(n) == 'work_iter = self._repeat_iterator()')
    method.body[work + 1:work + 1] = ast.parse(
        "ready_groups = poor_rl_deque()\n"
        "dispatched_samples = 0\n"
        f"self._poor_rl_group_flow = dict(cap_groups={cap}, completed_groups=0)\n").body
    outer_try = next(n for n in method.body if isinstance(n, ast.Try))
    outer = outer_try.body[0]
    if not isinstance(outer, ast.While) or ast.unparse(outer.test) != 'True':
        raise ValueError('Native generation loop changed')
    refills = [n for n in outer.body if isinstance(n, ast.While)]
    if len(refills) != 1 or ast.unparse(refills[0].test) != 'free_slots and (not stop_event.is_set())':
        raise ValueError('Native refill condition changed')
    refill = refills[0]
    idx = outer.body.index(refill)
    outer.body[idx:idx] = ast.parse(
        "while ready_groups and not self._groups_to_score.full():\n"
        "    self._groups_to_score.put_nowait(ready_groups.popleft())\n"
        "poor_rl_observe(self, pending_groups, ready_groups, dispatched_samples)\n").body
    refill.test = ast.parse(
        "free_slots and not stop_event.is_set() and "
        f"(dispatched_samples % self.num_generations != 0 or poor_rl_inventory(self, pending_groups, ready_groups) < {cap})",
        mode='eval').body
    if ast.dump(refill.body[0]) != ast.dump(ast.parse('group_id, row = next(work_iter)').body[0]):
        raise ValueError('Native group iterator changed')
    refill.body.insert(1, ast.parse('dispatched_samples += 1').body[0])
    done_loop = next(n for n in outer.body if isinstance(n, ast.For)
                     and ast.unparse(n.target) == 'task')
    group_complete = [n for n in done_loop.body if isinstance(n, ast.If)
                      and ast.unparse(n.test) == 'pending_completed[group_id] == self.num_generations']
    if len(group_complete) != 1:
        raise ValueError('Native group completion boundary changed')
    complete = group_complete[0]
    if (ast.unparse(complete.body[0]) != 'group.queued_at = time.monotonic()'
            or ast.unparse(complete.body[-2]) != 'del pending_groups[group_id]'
            or ast.unparse(complete.body[-1]) != 'del pending_completed[group_id]'):
        raise ValueError('Native group completion cleanup changed')
    complete.body = [complete.body[0]] + ast.parse(
        "ready_groups.append(group)\n"
        "self._poor_rl_group_flow['completed_groups'] += 1\n").body + complete.body[-2:]
    return ast.fix_missing_locations(tree)


def install():
    from trl.experimental.async_grpo import async_rollout_worker as native
    cap = int(os.environ['SPRINT_GROUP_CAP'])
    cls = native._AsyncRolloutLoop
    if getattr(cls, '_poor_rl_group_flow_installed', False):
        raise ValueError('Group flow installed twice')
    original = cls._generate_loop
    source = inspect.getsource(original)
    digest = hashlib.sha256(source.encode()).hexdigest()
    if not digest.startswith(NATIVE_HASH_PREFIX):
        raise ValueError('Installed TRL generation source changed')
    namespace = dict(original.__globals__, poor_rl_deque=deque,
                     poor_rl_inventory=inventory, poor_rl_observe=observe)
    exec(compile(transform(source, cap), __file__, 'exec'), namespace)
    cls._generate_loop = namespace['_generate_loop']
    cls._poor_rl_group_flow_installed = True
    return dict(cap_groups=cap, native_sha256=digest, whole_groups_preserved=True,
                scoring_and_staleness_rules_unchanged=True, admission_timing_changed=True)
