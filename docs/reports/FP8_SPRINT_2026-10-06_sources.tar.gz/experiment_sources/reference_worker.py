"""Trusted-cluster BF16 frozen-reference scorer; every request scores fresh exact tokens."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from reference_prefetch import MAX_BODY, SCHEMA, validate_payload


def source_fingerprint(code):
    names = ["prefix_share.py", "fast_logprob.py", "fused_ops.py"]
    hashes = {name: hashlib.sha256((Path(code) / "rlforge" / name).read_bytes()).hexdigest() for name in names}
    relevant = {key: os.getenv(key, "") for key in ["RLFORGE_FAST_LOGPROB", "RLFORGE_FUSED_OPS",
                "RLFORGE_PREFIX_ALIGN", "RLFORGE_LOGPROB_TOK_CHUNK", "RLFORGE_LOGPROB_VOCAB_CHUNK",
                "RLFORGE_LOGPROB_COMPILE", "RLFORGE_PREFIX_SDPA"]}
    return hashlib.sha256(json.dumps({"files": hashes, "env": relevant}, sort_keys=True).encode()).hexdigest(), hashes, relevant


def checkpoint_fingerprint(checkpoint):
    directory = Path(checkpoint)
    files = sorted(directory.glob("*.safetensors")) + [directory / "config.json"]
    if len(files) < 2:
        raise ValueError("Expected frozen checkpoint config and safetensors")
    hashes = {}
    for path in files:
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(8 * 2**20), b""):
                digest.update(block)
        hashes[path.name] = digest.hexdigest()
    return hashlib.sha256(json.dumps(hashes, sort_keys=True).encode()).hexdigest(), hashes


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--code", required=True)
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--temperature", type=float, default=1.0)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--metrics", required=True)
    args = parser.parse_args()
    os.environ.setdefault("RLFORGE_FAST_LOGPROB", "1")
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
    if os.getenv("RLFORGE_FUSED_OPS", ""):
        raise ValueError("Unchanged-anchor worker requires stock BF16 pointwise source in this arm")
    import sys
    sys.path.insert(0, args.code)
    import torch
    from transformers import AutoModelForCausalLM
    from trl.trainer.utils import patch_chunked_lm_head
    from rlforge.prefix_share import install

    torch.set_num_threads(1)
    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise ValueError("Pin exactly one reserved GPU in CUDA_VISIBLE_DEVICES")
    ref_sha, checkpoint_hashes = checkpoint_fingerprint(args.checkpoint)
    code_sha, code_hashes, env = source_fingerprint(args.code)
    model = AutoModelForCausalLM.from_pretrained(
        args.checkpoint, dtype=torch.bfloat16, attn_implementation="kernels-community/flash-attn3").cuda().eval()
    model.requires_grad_(False)
    patch_chunked_lm_head(model, chunk_size=8192, temperature=args.temperature)
    install(model, temperature=args.temperature)
    if any(p.requires_grad or p.dtype != torch.bfloat16 for p in model.parameters()):
        raise ValueError("Frozen reference must have only BF16 parameters")
    manifest = {"schema": SCHEMA, "precision": "BF16", "reference_sha256": ref_sha,
                "source_sha256": code_sha, "temperature": args.temperature,
                "checkpoint": args.checkpoint, "checkpoint_file_sha256": checkpoint_hashes,
                "source_file_sha256": code_hashes, "env": env,
                "worker_script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                "gpu": torch.cuda.get_device_name(0), "pid": os.getpid(),
                "scope": "Full-vocab BF16 frozen reference forward only; excludes policy/rollout/judge."}
    Path(args.manifest).write_text(json.dumps(manifest, indent=2))
    lock = threading.Lock()
    metrics_path = Path(args.metrics)

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_args):
            return

        def write_json(self, status, value):
            body = json.dumps(value, separators=(",", ":")).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            self.write_json(200 if self.path == "/health" else 404, manifest if self.path == "/health" else {"error": "unknown endpoint"})

        def do_POST(self):
            if self.path != "/score":
                self.write_json(404, {"error": "unknown endpoint"})
                return
            try:
                size = int(self.headers.get("Content-Length", "0"))
                if not 0 < size <= MAX_BODY:
                    raise ValueError("Invalid reference request size")
                body = json.loads(self.rfile.read(size))
                slots = validate_payload(body)
                for key in ["schema", "precision", "reference_sha256", "source_sha256", "temperature"]:
                    if body[key] != manifest[key]:
                        raise ValueError("Reference worker contract mismatch: " + key)
                with lock, torch.no_grad(), torch.autocast("cuda", enabled=False):
                    input_ids = torch.tensor([body["input_ids"]], device="cuda", dtype=torch.long)
                    mask = torch.tensor([body["completion_mask"]], device="cuda", dtype=torch.long)
                    start, stop = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
                    start.record()
                    output = model(prefix_share={"input_ids": input_ids, "completion_mask": mask,
                                                   "subbatch": body["subbatch"]})
                    stop.record()
                    stop.synchronize()
                    actual_slots = output["slots"].cpu().tolist()
                    log_probs = output["log_probs"].float()
                    if actual_slots != slots or log_probs.numel() != len(slots) or not bool(torch.isfinite(log_probs).all()):
                        raise ValueError("Reference scoring did not preserve every completion slot")
                    result = {key: body[key] for key in ["schema", "precision", "request_sha256",
                              "reference_sha256", "source_sha256", "temperature"]}
                    result.update(slots=actual_slots, log_probs=log_probs.cpu().tolist(),
                                  compute_ms=start.elapsed_time(stop), completion_tokens=len(slots),
                                  peak_allocated_gib=torch.cuda.max_memory_allocated() / 2**30)
                    row = {key: value for key, value in result.items() if key not in ["log_probs", "slots"]}
                    with metrics_path.open("a") as handle:
                        handle.write(json.dumps(row) + chr(10))
                self.write_json(200, result)
            except Exception as error:
                self.write_json(400, {"error": str(error)})

    print(json.dumps({"ready": True, "host": args.host, "port": args.port, "manifest": args.manifest}), flush=True)
    ThreadingHTTPServer((args.host, args.port), Handler).serve_forever()


if __name__ == "__main__":
    main()
