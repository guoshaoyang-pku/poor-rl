"""Process-local LM-head backward fusion; canonical rlforge is unchanged."""
from __future__ import annotations

import os

import torch
import torch.nn.functional as F
import triton
import triton.language as tl


@triton.jit
def _gradient_value(L, Z, G, GE, E, T, rows, cols, N: tl.constexpr,
                    V: tl.constexpr, LS: tl.constexpr, IT: tl.constexpr,
                    HAS_ENT: tl.constexpr):
    valid = (rows < N) & (cols < V)
    l = tl.load(L + rows * V + cols, valid, other=0).to(tl.float32)
    z = tl.load(Z + rows, rows < N, other=0)
    g = tl.load(G + rows, rows < N, other=0)
    target = tl.load(T + rows, rows < N, other=-1)
    x = (l * LS) * IT
    lp = x - z
    p = tl.exp(lp)
    gl = (-g) * p
    if HAS_ENT:
        ge = tl.load(GE + rows, rows < N, other=0)
        ent = tl.load(E + rows, rows < N, other=0)
        gl = gl + ((-ge) * p) * (lp + ent)
    gl = gl + tl.where(target == cols, g, 0.0)
    gl = (gl * IT) * LS
    return tl.where(valid, gl, 0.0)


@triton.jit
def _gradient_amax(L, Z, G, GE, E, T, PARTIAL, N: tl.constexpr,
                   V: tl.constexpr, LS: tl.constexpr, IT: tl.constexpr,
                   HAS_ENT: tl.constexpr, BLOCK: tl.constexpr):
    idx = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    rows, cols = idx // V, idx % V
    gl = _gradient_value(L, Z, G, GE, E, T, rows, cols, N, V, LS, IT, HAS_ENT)
    tl.store(PARTIAL + tl.program_id(0), tl.max(tl.abs(gl), 0))


@triton.jit
def _gradient_quantize_dual(L, Z, G, GE, E, T, Q, QT, S,
                           N: tl.constexpr, V: tl.constexpr, MP: tl.constexpr,
                           LS: tl.constexpr, IT: tl.constexpr, HAS_ENT: tl.constexpr,
                           BM: tl.constexpr, BN: tl.constexpr):
    rows = tl.program_id(0) * BM + tl.arange(0, BM)
    cols = tl.program_id(1) * BN + tl.arange(0, BN)
    gl = _gradient_value(L, Z, G, GE, E, T, rows[:, None], cols[None, :],
                         N, V, LS, IT, HAS_ENT)
    scale = tl.load(S)
    q = tl.minimum(tl.maximum(gl / scale, -57344.0), 57344.0)
    mask = (rows[:, None] < MP) & (cols[None, :] < V)
    tl.store(Q + rows[:, None] * V + cols[None, :], q, mask)
    qt = tl.inline_asm_elementwise(
        "mov.b32 $0, $1;", constraints="=f,f", args=[tl.trans(q)],
        dtype=tl.float32, is_pure=False, pack=1)
    tl.store(QT + cols[:, None] * MP + rows[None, :], qt, tl.trans(mask))


def quantized_gradient(logits, log_z, g, ge, ent, local_targets, ls, inv_t):
    """Same per-tile tensorwise E5M2 scale without an FP32 grad-logits tensor."""
    from rlforge.fp8 import _amax_scale_kernel

    n, vocab = logits.shape
    mp = (n + 15) // 16 * 16
    blocks = triton.cdiv(n * vocab, 4096)
    partial = torch.empty(blocks, device=logits.device, dtype=torch.float32)
    scale = torch.empty((), device=logits.device, dtype=torch.float32)
    q = torch.empty((mp, vocab), device=logits.device, dtype=torch.float8_e5m2)
    qt = torch.empty((vocab, mp), device=logits.device, dtype=torch.float8_e5m2)
    ge_arg = g if ge is None else ge
    _gradient_amax[(blocks,)](
        logits, log_z, g, ge_arg, ent, local_targets, partial, n, vocab, ls, inv_t,
        ge is not None, 4096, enable_fp_fusion=False)
    _amax_scale_kernel[(1,)](partial, scale, blocks, 57344.0, triton.next_power_of_2(blocks))
    _gradient_quantize_dual[(triton.cdiv(mp, 32), triton.cdiv(vocab, 64))](
        logits, log_z, g, ge_arg, ent, local_targets, q, qt, scale, n, vocab, mp,
        ls, inv_t, ge is not None, 32, 64, enable_fp_fusion=False)
    return q[:n], qt, scale


def _fp8_backward(h, targets, log_z, ent, g, ge, fp8_cache, need_h, need_w, ls, inv_t, *, graph=True):
    from rlforge import fast_logprob as flp
    from rlforge.fp8 import _quantize_tensor, forward_mm, quantize_rows, scaled_mm

    wq, ws, backward_weights = fp8_cache
    n, hidden = h.shape
    vocab = wq.shape[0]
    grad_h = torch.zeros(n, hidden, device=h.device, dtype=torch.float32) if need_h else None
    grad_w = torch.zeros(vocab, hidden, device=h.device, dtype=torch.float32) if need_w else None
    for t0 in range(0, n, flp.TOK_CHUNK):
        t1 = min(n, t0 + flp.TOK_CHUNK)
        hc, tg = h[t0:t1], targets[t0:t1]
        hq, hs = quantize_rows(hc)
        if need_w:
            pad = (-(t1 - t0)) % 16
            hp = F.pad(hc, (0, 0, 0, pad)) if pad else hc
            htq, hts = _quantize_tensor(hp, torch.float8_e4m3fn, transpose=True)
        for vi, v0 in enumerate(range(0, vocab, flp.VOCAB_CHUNK)):
            v1 = min(vocab, v0 + flp.VOCAB_CHUNK)
            logits = forward_mm(hq, wq[v0:v1], hs, ws[v0:v1])
            local_targets = tg - v0
            gq, gtq, gs = quantized_gradient(
                logits, log_z[t0:t1], g[t0:t1], None if ge is None else ge[t0:t1],
                ent[t0:t1], local_targets, ls, inv_t)
            if need_h:
                wtq, wts = backward_weights[vi]
                grad_h[t0:t1] += scaled_mm(gq, wtq, gs, wts, out_dtype=torch.float32)
            if need_w:
                grad_w[v0:v1] += scaled_mm(gtq, htq, gs, hts, out_dtype=torch.float32)
    return grad_h, grad_w


def install_for_benchmark(policy, ref=None):
    from rlforge import fast_logprob as flp

    if os.environ.get("RLFORGE_FP8_HEAD_GRAPH", "0") == "1":
        raise ValueError("matmul prototype requires RLFORGE_FP8_HEAD_GRAPH=0")
    original = flp._fp8_backward
    flp._fp8_backward = _fp8_backward

    def restore():
        flp._fp8_backward = original

    return restore
