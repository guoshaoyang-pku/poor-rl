"""Read-only per-rank pause attribution; native synchronization is retained."""
import functools
import json
import os
import time

_INSTALLED = False
_RECORDS = []


def snapshot(engine):
    scheduler = engine.scheduler
    state = {'pid': os.getpid(), 'dp_rank': getattr(engine, 'dp_rank', 0),
             'pause_state': str(scheduler.pause_state),
             'running': len(scheduler.running),
             'pending_pause': getattr(engine, 'pending_pause', None),
             'engines_running': getattr(engine, 'engines_running', None),
             'step_counter': getattr(engine, 'step_counter', None),
             'dp_sync_interval': getattr(engine, 'dp_sync_interval', None),
             'batch_queue': len(getattr(engine, 'batch_queue', None) or ()),
             'idle_callbacks': len(getattr(engine, '_idle_state_callbacks', ())),
             'wall_ns': time.time_ns(), 'monotonic_ns': time.perf_counter_ns()}
    for name in ('input_queue', 'output_queue'):
        queue = getattr(engine, name, None)
        try:
            state[name] = queue.qsize() if queue is not None else None
        except (AttributeError, NotImplementedError):
            state[name] = None
    return state


def emit(engine, event, **values):
    row = dict(snapshot(engine), event=event, **values)
    _RECORDS.append(row)
    del _RECORDS[:-96]
    print('SPRINT_PAUSE ' + json.dumps(row), flush=True)
    return row


def stats():
    return {'pid': os.getpid(), 'records': list(_RECORDS),
            'scope': 'Per-rank normal wall durations, no synchronization or scheduling changes'}


def install():
    global _INSTALLED
    if _INSTALLED:
        return
    from vllm.v1.engine.core import DPEngineCoreProc, EngineCore, EngineCoreProc
    from vllm.v1.engine import EngineCoreRequestType
    native_init = EngineCoreProc.__init__
    native_handle = EngineCoreProc._handle_client_request
    native_pause = EngineCoreProc.pause_scheduler
    native_finish = EngineCore._finish_pause
    native_reset = EngineCore._reset_caches
    native_consensus = DPEngineCoreProc._has_global_unfinished_reqs
    native_step = EngineCoreProc._process_engine_step
    native_dummy = EngineCore.execute_dummy_batch
    native_resume = DPEngineCoreProc.resume_scheduler

    @functools.wraps(native_init)
    def initialize(self, *args, **kwargs):
        native_init(self, *args, **kwargs)
        self._sprint_utility_enqueued = {}
        original_put = self.input_queue.put_nowait

        def put(item):
            kind, request = item
            if kind == EngineCoreRequestType.UTILITY and request[2] in ('pause_scheduler', 'resume_scheduler'):
                self._sprint_utility_enqueued[request[1]] = time.perf_counter_ns()
                emit(self, 'utility_input_enqueued', method=request[2], call_id=request[1])
            return original_put(item)
        self.input_queue.put_nowait = put

    @functools.wraps(native_handle)
    def handle(self, request_type, request):
        if request_type == EngineCoreRequestType.UTILITY and request[2] in ('pause_scheduler', 'resume_scheduler'):
            enqueued = getattr(self, '_sprint_utility_enqueued', {}).pop(request[1], None)
            emit(self, 'utility_dispatch_begin', method=request[2], call_id=request[1],
                 queue_ms=None if enqueued is None else (time.perf_counter_ns()-enqueued)/1e6)
        return native_handle(self, request_type, request)

    @functools.wraps(native_pause)
    def pause(self, mode='abort', clear_cache=True):
        state = {'started_ns': time.perf_counter_ns(), 'steps': 0, 'step_ms': 0.,
                 'dummy_calls': 0, 'dummy_ms': 0., 'consensus_calls': 0, 'consensus_ms': 0.}
        self._sprint_pause_observation = state
        emit(self, 'pause_received', mode=mode, clear_cache=clear_cache)
        future = native_pause(self, mode, clear_cache)
        emit(self, 'pause_returned', returned_future=future is not None)

        def completed(result=None):
            state['complete'] = True
            emit(self, 'pause_complete', elapsed_ms=(time.perf_counter_ns()-state['started_ns'])/1e6,
                 stages=state, failure=None if result is None else str(result.exception()))
        if future is None:
            completed()
        else:
            future.add_done_callback(completed)
        return future

    @functools.wraps(native_finish)
    def finish(self, clear_cache):
        emit(self, 'finish_pause_begin', clear_cache=clear_cache)
        executor = self.model_executor
        original_rpc = executor.collective_rpc

        def timed_rpc(method, *args, **kwargs):
            begin = time.perf_counter_ns()
            try:
                return original_rpc(method, *args, **kwargs)
            finally:
                emit(self, 'finish_pause_rpc', method=str(method), wall_ms=(time.perf_counter_ns()-begin)/1e6)
        executor.collective_rpc = timed_rpc
        begin = time.perf_counter_ns()
        try:
            return native_finish(self, clear_cache)
        finally:
            executor.collective_rpc = original_rpc
            emit(self, 'finish_pause_end', wall_ms=(time.perf_counter_ns()-begin)/1e6)

    @functools.wraps(native_reset)
    def reset(self, *args, **kwargs):
        begin = time.perf_counter_ns()
        try:
            return native_reset(self, *args, **kwargs)
        finally:
            if getattr(self, '_sprint_pause_observation', None) is not None:
                emit(self, 'reset_caches', wall_ms=(time.perf_counter_ns()-begin)/1e6)

    @functools.wraps(native_consensus)
    def consensus(self, local_unfinished):
        pending = self.pending_pause
        before = self.step_counter
        begin = time.perf_counter_ns() if pending else 0
        result = native_consensus(self, local_unfinished)
        if pending:
            wall_ms = (time.perf_counter_ns()-begin)/1e6
            state = getattr(self, '_sprint_pause_observation', None)
            if state is not None:
                state['consensus_calls'] += 1
                state['consensus_ms'] += wall_ms
            if (before+1 == 1 or (before+1) % self.dp_sync_interval == 0
                    or not self.pending_pause):
                emit(self, 'pause_consensus', wall_ms=wall_ms,
                     local_unfinished=local_unfinished, global_unfinished=result)
        return result

    @functools.wraps(native_step)
    def step(self):
        state = getattr(self, '_sprint_pause_observation', None)
        active = state is not None and not state.get('complete')
        begin = time.perf_counter_ns() if active else 0
        result = native_step(self)
        if active:
            state['steps'] += 1
            state['step_ms'] += (time.perf_counter_ns()-begin)/1e6
        return result

    @functools.wraps(native_dummy)
    def dummy(self):
        state = getattr(self, '_sprint_pause_observation', None)
        active = state is not None and not state.get('complete')
        begin = time.perf_counter_ns() if active else 0
        result = native_dummy(self)
        if active:
            state['dummy_calls'] += 1
            state['dummy_ms'] += (time.perf_counter_ns()-begin)/1e6
        return result

    @functools.wraps(native_resume)
    def resume(self):
        emit(self, 'resume_begin')
        begin = time.perf_counter_ns()
        try:
            return native_resume(self)
        finally:
            emit(self, 'resume_end', wall_ms=(time.perf_counter_ns()-begin)/1e6)

    EngineCoreProc.__init__ = initialize
    EngineCoreProc._handle_client_request = handle
    EngineCoreProc.pause_scheduler = pause
    EngineCore._finish_pause = finish
    EngineCore._reset_caches = reset
    DPEngineCoreProc._has_global_unfinished_reqs = consensus
    EngineCoreProc._process_engine_step = step
    EngineCore.execute_dummy_batch = dummy
    DPEngineCoreProc.resume_scheduler = resume
    _INSTALLED = True
