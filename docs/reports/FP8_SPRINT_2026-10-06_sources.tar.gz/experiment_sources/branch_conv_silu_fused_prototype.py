"""Fuse four-tap convolution with FP32 SiLU and backward layout output."""
import torch

import branch_conv_precise_prototype as branch
import fusion_conv_prototype as compact
import fusion_conv_precise_prototype as precise

triton, tl = compact.triton, compact.tl

if triton is not None:
    from triton.language.extra.cuda import libdevice

    @triton.jit
    def _pre(X, Tail, W, Bias, b, t, c, valid, XS0, XS1, XS2,
             TS0, TS1, TS2, SHARED: tl.constexpr, HAS_TAIL: tl.constexpr,
             HAS_BIAS: tl.constexpr):
        value = tl.full(t.shape, 0.0, tl.float32)
        for tap in tl.static_range(4):
            pos = t + tap - 3
            x = tl.load(X + b * XS0 + c * XS1 + pos * XS2,
                        valid & (pos >= 0), other=0).to(tl.float32)
            if HAS_TAIL:
                tb = 0 if SHARED else b
                tail = tl.load(Tail + tb * TS0 + c * TS1 + (pos + 3) * TS2,
                               valid & (pos < 0), other=0).to(tl.float32)
                x = x + tail
            w = tl.load(W + c * 4 + tap, valid, other=0).to(X.dtype.element_ty).to(tl.float32)
            value = value + (x * w).to(X.dtype.element_ty).to(tl.float32)
        if HAS_BIAS:
            value = value + tl.load(Bias + c, valid, other=0).to(X.dtype.element_ty).to(tl.float32)
        return value

    @triton.jit(do_not_specialize=['N', 'L'])
    def _forward(X, Tail, W, Bias, Y, N, L, C: tl.constexpr,
                 XS0, XS1, XS2, TS0, TS1, TS2, SHARED: tl.constexpr,
                 HAS_TAIL: tl.constexpr, HAS_BIAS: tl.constexpr,
                 SILU: tl.constexpr, TIME_MAJOR: tl.constexpr, BLOCK: tl.constexpr):
        index = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
        b, t, c = compact._index(index, L, C, TIME_MAJOR)
        value = _pre(X, Tail, W, Bias, b, t, c, index < N, XS0, XS1, XS2,
                     TS0, TS1, TS2, SHARED, HAS_TAIL, HAS_BIAS)
        if SILU:
            value = tl.div_rn(value, 1.0 + libdevice.exp(-value))
        tl.store(Y + index, value, index < N)

    @triton.jit(do_not_specialize=['N', 'L'])
    def _upstream(X, Tail, W, Bias, DY, G, N, L, C: tl.constexpr,
                  XS0, XS1, XS2, TS0, TS1, TS2, DS0, DS1, DS2,
                  SHARED: tl.constexpr, HAS_TAIL: tl.constexpr, HAS_BIAS: tl.constexpr,
                  SILU: tl.constexpr, TIME_MAJOR: tl.constexpr, BLOCK: tl.constexpr):
        index = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
        b, t, c = compact._index(index, L, C, TIME_MAJOR)
        dy = tl.load(DY + b * DS0 + c * DS1 + t * DS2, index < N, other=0).to(tl.float32)
        if SILU:
            value = _pre(X, Tail, W, Bias, b, t, c, index < N, XS0, XS1, XS2,
                         TS0, TS1, TS2, SHARED, HAS_TAIL, HAS_BIAS)
            sigmoid = tl.div_rn(1.0, 1.0 + libdevice.exp(-value))
            dy = dy * sigmoid * (1.0 + value * (1.0 - sigmoid))
        tl.store(G + index, dy, index < N)


def _output(x, dtype):
    if x.stride(1) == 1:
        return torch.empty((x.shape[0], x.shape[2], x.shape[1]), device=x.device, dtype=dtype).transpose(1, 2)
    return torch.empty(x.shape, device=x.device, dtype=dtype)


class _Conv(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, tail, weight, bias, silu):
        ctx.set_materialize_grads(False)
        ctx.save_for_backward(x, tail, weight, bias)
        ctx.silu = silu
        batch, channels, length = x.shape
        tm = x.stride(1) == 1
        y = _output(x, x.dtype)
        ts = tail.stride() if tail is not None else (0, 0, 0)
        _forward[(triton.cdiv(x.numel(), 256),)](
            x, tail if tail is not None else x, weight, bias if bias is not None else x, y,
            x.numel(), length, channels, *x.stride(), *ts,
            tail is not None and tail.shape[0] == 1, tail is not None, bias is not None,
            silu, tm, 256, enable_fp_fusion=False)
        return y

    @staticmethod
    def backward(ctx, grad):
        if grad is None:
            return None, None, None, None, None
        x, tail, weight, bias = ctx.saved_tensors
        nx, nt, nw, nb = ctx.needs_input_grad[:4]
        batch, channels, length = x.shape
        tm = x.stride(1) == 1
        g = _output(x, torch.float32)
        ts = tail.stride() if tail is not None else (0, 0, 0)
        _upstream[(triton.cdiv(x.numel(), 256),)](
            x, tail if tail is not None else x, weight, bias if bias is not None else x, grad, g,
            x.numel(), length, channels, *x.stride(), *ts, *grad.stride(),
            tail is not None and tail.shape[0] == 1, tail is not None, bias is not None,
            ctx.silu, tm, 256, enable_fp_fusion=False)
        dx = dt = dw = db = None
        if nx:
            dx = _output(x, x.dtype)
            compact._dx_kernel[(triton.cdiv(x.numel(), 256),)](
                g, weight, dx, x.numel(), length, channels, tl.bfloat16, tm, 256,
                enable_fp_fusion=False)
        if nt and tail is not None:
            dt = torch.empty_like(tail, memory_format=torch.contiguous_format)
            shared = tail.shape[0] == 1
            branch._dtail_kernel[(triton.cdiv(channels, 32), 1 if shared else batch)](
                g, weight, dt, length, channels, batch, shared,
                triton.next_power_of_2(batch) if shared else 1, 32, enable_fp_fusion=False)
        if nw or nb:
            groups = triton.cdiv(batch * length, 128)
            pw = torch.empty((groups, channels, 4), device=x.device, dtype=torch.float32)
            pb = torch.empty((groups, channels), device=x.device, dtype=torch.float32) if nb else pw
            if tail is not None:
                branch._dw_kernel[(groups, triton.cdiv(channels, 16))](
                    x, tail, g, pw, pb, batch * length, length, channels, *x.stride(), *ts,
                    tail.shape[0] == 1, nb, 128, 16, enable_fp_fusion=False)
            else:
                compact._dw_kernel[(groups, triton.cdiv(channels, 16))](
                    x, g, pw, pb, batch * length, length, channels, *x.stride(), *g.stride(),
                    nb, 128, 16, enable_fp_fusion=False)
            if nw:
                dw = pw.sum(0).to(x.dtype).to(weight.dtype)
            if nb:
                db = pb.sum(0).to(x.dtype).to(bias.dtype)
        return dx, dt, dw, db, None


def branch_conv(x, tail, weight, bias=None):
    if (not x.is_cuda or x.dtype != torch.bfloat16 or x.stride(1) != 1
            or weight.shape != (x.shape[1], 4) or tail.shape[-2:] != (x.shape[1], 3)):
        return branch._BranchConv.apply(x, tail, weight, bias)
    return _Conv.apply(x, tail, weight, bias, True)


def causal_conv(x, weight, bias, activation):
    if (not x.is_cuda or x.dtype != torch.bfloat16 or weight.shape != (x.shape[1], 4)
            or not weight.is_contiguous() or activation not in (None, 'silu', 'swish')):
        return precise.causal_conv(x, weight, bias, activation)
    return _Conv.apply(x, None, weight, bias, activation is not None)


def install_for_benchmark(policy, ref=None):
    from rlforge import fp8_alignment as alignment
    restore_branch = branch.install_for_benchmark(policy, ref=ref)
    old_branch, old_causal = branch.branch_conv, alignment._causal_conv
    branch.branch_conv, alignment._causal_conv = branch_conv, causal_conv

    def restore():
        branch.branch_conv, alignment._causal_conv = old_branch, old_causal
        restore_branch()
    return restore
