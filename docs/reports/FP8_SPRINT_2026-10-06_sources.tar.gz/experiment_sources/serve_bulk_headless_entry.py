"""Native headless serving with the same bulk bookkeeping as local DP."""
import os
import serve_output_request_proof_entry
import serving_bulk_decode_prototype as bulk
from vllm.v1.engine.core import EngineCore

bulk.install()
bulk.toggle(os.environ.get('SPRINT_BULK_DECODE', '1') == '1')
native_rpc = EngineCore.collective_rpc


def collective_rpc(self, method, timeout=None, args=(), kwargs=None):
    if method == 'sprint_bulk_decode_stats':
        return [bulk.stats()]
    if method == 'sprint_bulk_decode_toggle':
        return [bulk.toggle(args[0] == '1')]
    return native_rpc(self, method, timeout, args, kwargs)


EngineCore.collective_rpc = collective_rpc
if __name__ == '__main__':
    serve_output_request_proof_entry.serve_kv_partial_proof_entry.serve_cpu_ssm_entry.serve_pause_observed_entry.serve_kv_bandwidth_entry.serve_kv_observed_entry.serve_driver.main()
