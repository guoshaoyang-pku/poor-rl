"""Run the frozen train_filestore entry with BF16 reference prefetch on each rank."""
from __future__ import annotations

import ast
import hashlib
import json
import os
import runpy
from pathlib import Path


def _install_train_hook():
    from trl.experimental.async_grpo import AsyncGRPOTrainer
    from reference_prefetch import ReferenceClient, install_for_trainer
    from reference_worker import checkpoint_fingerprint, source_fingerprint

    original_train = AsyncGRPOTrainer.train

    def train(self, *args, **kwargs):
        endpoints = [s for s in os.environ.get("RLFORGE_REFERENCE_ENDPOINTS", "").split(",") if s]
        if not endpoints or self._ref_model is None:
            raise ValueError("Reference endpoints and existing frozen reference are required")
        checkpoint = os.environ["RLFORGE_REF_MODEL"]
        code = os.environ["SCALE_SOURCE"]
        reference_sha, checkpoint_files = checkpoint_fingerprint(checkpoint)
        source_sha, source_files, source_env = source_fingerprint(code)
        client = ReferenceClient(endpoints, reference_sha256=reference_sha, source_sha256=source_sha,
                                 temperature=self.temperature, timeout=float(os.environ.get("RLFORGE_REFERENCE_TIMEOUT_S", "90")))
        restore = install_for_trainer(self, client, offload_local_reference=True)
        output = Path(os.environ["SCALE_OUT"]) / ("reference_rank" + os.environ.get("RANK", "0") + ".json")
        manifest = {"precision": "BF16 full-vocab frozen reference; policy unchanged by this hook",
                    "kl_beta": self._kl_beta, "temperature": self.temperature, "endpoints": endpoints,
                    "reference_sha256": reference_sha, "checkpoint_file_sha256": checkpoint_files,
                    "source_sha256": source_sha, "source_file_sha256": source_files, "source_env": source_env,
                    "canonical_loss_ast_sha256": self._reference_prefetch_source_sha256,
                    "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    "client_sha256": hashlib.sha256(Path(__file__).with_name("reference_prefetch.py").read_bytes()).hexdigest(),
                    "stats": client.stats, "status": "running", "pid": os.getpid()}
        output.write_text(json.dumps(manifest, indent=2))
        try:
            result = original_train(self, *args, **kwargs)
            manifest["status"] = "completed"
            return result
        except BaseException as error:
            client.cancel(error)
            manifest["status"] = "failed"
            manifest["error"] = type(error).__name__ + ": " + str(error)
            raise
        finally:
            manifest["stats"] = dict(client.stats)
            output.write_text(json.dumps(manifest, indent=2))
            restore(return_reference_to_gpu=False)
            client.close()

    AsyncGRPOTrainer.train = train


def main():
    path = Path(__file__).with_name("train_filestore.py")
    if os.environ.get("SCALE_TRAIN_CHILD") == "1":
        _install_train_hook()
        runpy.run_path(str(path), run_name="__main__")
        return
    tree = ast.parse(path.read_text())
    # Frozen parent spawns __file__; execute its identical AST with this wrapper as __file__.
    namespace = {"__name__": "__main__", "__file__": str(Path(__file__)),
                 "__package__": None, "__builtins__": __builtins__}
    exec(compile(tree, str(path), "exec"), namespace)


if __name__ == "__main__":
    main()
