"""Native fixed-length real-context cohort; diagnostic serving, not trained RL."""
import argparse
import asyncio
import datetime
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys
import time

ROOT = Path(__file__).resolve().parent


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False))


def cohort(tokens, context_len, concurrency, group, cap, seed, model):
    data = json.loads(Path(tokens).read_text())
    sequences = data['sequences']
    if concurrency <= 0 or concurrency % group or context_len <= 0 or cap <= 0:
        raise ValueError('Positive equal-length context, cap and complete groups required')
    selected = [s['token_ids'][:context_len] for s in sequences if len(s['token_ids']) >= context_len]
    if len(selected) < concurrency // group:
        raise ValueError('Not enough saved real contexts for distinct cohort groups')
    selected = selected[:concurrency // group]
    if any(len(p) != context_len or any(type(t) is not int or t < 0 for t in p) for p in selected):
        raise ValueError('Saved context token IDs invalid')
    bodies = [dict(model=model, prompt=selected[i // group], n=1, temperature=1.0,
                   top_p=1.0, top_k=-1, repetition_penalty=1.0,
                   presence_penalty=0.0, frequency_penalty=0.0, ignore_eos=True,
                   max_tokens=cap, seed=seed+i, return_token_ids=True, logprobs=0)
              for i in range(concurrency)]
    provenance = dict(path=str(Path(tokens).resolve()), file_sha256=hashlib.sha256(Path(tokens).read_bytes()).hexdigest(),
                      context_len=context_len, cap=cap, concurrency=concurrency, G=group,
                      context_tokens_sha256=hashlib.sha256(json.dumps(selected, separators=(',', ':')).encode()).hexdigest(),
                      unique_contexts=len({tuple(p) for p in selected}), checkpoint=data.get('checkpoint'),
                      original_provenance=data.get('provenance'),
                      scope='Saved historical real token prefixes; context includes historical completion when context_len exceeds original prompt. Finite fixed-cap cohort, no replacement/randomized initial caps/forced tokens.')
    return bodies, provenance


def response_gate(data, body):
    choices = data.get('choices', [])
    if len(choices) != 1:
        raise ValueError('Expected one native completion')
    choice, cap = choices[0], body['max_tokens']
    ids = choice.get('token_ids')
    lps = (choice.get('logprobs') or {}).get('token_logprobs')
    if not isinstance(ids, list) or len(ids) != cap or any(type(t) is not int or t < 0 for t in ids):
        raise ValueError('Native token IDs differ from fixed cap')
    if not isinstance(lps, list) or len(lps) != cap or any(not isinstance(x, (float, int)) or not math.isfinite(x) for x in lps):
        raise ValueError('Full-vocab sampled raw logprobs missing or nonfinite')
    if data.get('usage', {}).get('completion_tokens') != cap or choice.get('finish_reason') != 'length':
        raise ValueError('Unexpected native usage/finish; ignoreEOS length must be exact')
    if not isinstance(choice.get('text'), str):
        raise ValueError('Native full text missing')
    return dict(token_ids_sha256=hashlib.sha256(json.dumps(ids).encode()).hexdigest(),
                logprobs_sha256=hashlib.sha256(json.dumps(lps).encode()).hexdigest(),
                token_ids_head=ids[:8], tokens=cap, text_chars=len(choice['text']),
                raw_lp_min=min(lps), raw_lp_max=max(lps))


def install_inventory():
    from vllm.v1.engine.core import EngineCore
    native = EngineCore.collective_rpc

    def rpc(self, method, timeout=None, args=(), kwargs=None):
        if method != 'sprint_native_cohort_inventory':
            return native(self, method, timeout, args, kwargs)
        requests = self.scheduler.running
        computed = [r.num_computed_tokens for r in requests]
        outputs = [r.num_output_tokens for r in requests]
        prompts = [r.num_prompt_tokens for r in requests]
        def summary(values):
            return dict(min=min(values), max=max(values), mean=statistics.mean(values)) if values else None
        return [dict(running=len(requests), waiting=len(self.scheduler.waiting),
                     prefill=sum(bool(r.is_prefill_chunk) for r in requests),
                     computed=summary(computed), output=summary(outputs), prompt=summary(prompts),
                     native_v2=self.scheduler.use_v2_model_runner,
                     wall_ns=time.time_ns(), scope='Read-only real request geometry; RPC excluded from normal host timing') ]
    EngineCore.collective_rpc = rpc


def serve():
    import serve_output_request_host_entry as entry
    install_inventory()
    entry.serve_kv_partial_host_entry.serve_host_timeline_entry.serve_cpu_ssm_entry.serve_pause_observed_entry.serve_kv_bandwidth_entry.serve_kv_observed_entry.serve_driver.main()


async def bench(args):
    import httpx
    from serving_sprint import parse_metrics
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(output)
    start = time.monotonic()
    result = dict(scope='Native fixed-cap ignoreEOS saved-context serving diagnostic; no forced tokens/judge/reference/training. RNG and raw LP native. Wall includes prefill/drain; normal host window excludes prefill.',
                  started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), settings=vars(args),
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), responses=[], snapshots=[])
    save(output, result)
    async with httpx.AsyncClient(limits=httpx.Limits(max_connections=None, max_keepalive_connections=None), timeout=args.timeout) as client:
        async def get(path):
            r = await client.get(args.base+path, timeout=30); r.raise_for_status(); return r
        async def rpc(method, arguments=()):
            r = await client.post(args.base+'/collective_rpc', json={'method':method, 'args':list(arguments)}, timeout=30)
            r.raise_for_status(); return r.json()['results'][0]
        model = (await get('/v1/models')).json()['data'][0]['id']
        initial = await rpc('sprint_native_cohort_inventory')
        if initial['running'] or initial['waiting']:
            raise RuntimeError('Fresh drained native server required')
        bodies, provenance = cohort(args.tokens, args.context_len, args.concurrency, args.group, args.cap, args.seed, model)
        result['input'] = provenance
        baseline_metrics = parse_metrics((await get('/metrics')).text)
        async def request(index, body):
            r = await client.post(args.base+'/v1/completions', json=body)
            r.raise_for_status()
            proof = response_gate(r.json(), body)
            proof.update(request_id=index, elapsed_s=time.monotonic()-start)
            return proof
        tasks = [asyncio.create_task(request(i,b)) for i,b in enumerate(bodies)]
        try:
            ready_deadline = time.monotonic()+args.prefill_timeout
            while True:
                state = await rpc('sprint_native_cohort_inventory')
                result['snapshots'].append(state)
                done = [t for t in tasks if t.done()]
                if done:
                    for task in done:
                        task.result()
                    raise RuntimeError('Cohort finished before complete equal-shape decode window')
                if state['running']==args.concurrency and state['waiting']==state['prefill']==0 and state['computed']['min']>=args.context_len+args.settle_tokens:
                    break
                if time.monotonic()>ready_deadline:
                    raise TimeoutError('Complete real cohort decode window not reached')
                await asyncio.sleep(.5)
            if not state['native_v2'] or state['prompt']['min'] != args.context_len or state['prompt']['max'] != args.context_len:
                raise RuntimeError('Native runner or equal prompt geometry mismatch')
            result['geometry_before'] = state
            result['metrics_before'] = parse_metrics((await get('/metrics')).text)
            t0 = time.monotonic()
            await rpc('sprint_host_timeline_arm', [64])
            await asyncio.sleep(args.window)
            result['host'] = await rpc('sprint_host_timeline_stats')
            result['metrics_after'] = parse_metrics((await get('/metrics')).text)
            t1 = time.monotonic()
            result['geometry_after'] = await rpc('sprint_native_cohort_inventory')
            if not result['host']['state']['complete'] or result['geometry_after']['running'] != args.concurrency:
                raise RuntimeError('Real 64-step window did not complete at full cohort')
            delta = result['metrics_after']['vllm:generation_tokens_total']-result['metrics_before']['vllm:generation_tokens_total']
            result.update(window_s=t1-t0, generation_counter_delta=delta, generation_token_s=delta/(t1-t0))
            save(output,result)
            result['responses'] = await asyncio.gather(*tasks)
            result['metrics_final'] = parse_metrics((await get('/metrics')).text)
            result['geometry_final'] = await rpc('sprint_native_cohort_inventory')
            result['preemptions'] = result['metrics_final'].get('vllm:num_preemptions_total',0)-baseline_metrics.get('vllm:num_preemptions_total',0)
            if result['preemptions'] or result['geometry_final']['running'] or result['geometry_final']['waiting']:
                raise RuntimeError('Cohort preempted or failed to drain')
            result.update(valid=True, returned_tokens=sum(r['tokens'] for r in result['responses']), total_s=time.monotonic()-start)
            save(output,result)
            print(json.dumps({k:result[k] for k in ['valid','returned_tokens','generation_token_s','total_s']}),flush=True)
        except BaseException as exc:
            result['failure']={'type':type(exc).__name__,'detail':str(exc)[:500]}; save(output,result); raise
        finally:
            for task in tasks:
                if not task.done():
                    task.cancel()
            await asyncio.gather(*tasks,return_exceptions=True)


def main():
    if len(sys.argv)>1 and sys.argv[1]=='serve':
        serve(); return
    p=argparse.ArgumentParser()
    p.add_argument('--base',required=True); p.add_argument('--tokens',required=True); p.add_argument('--output',required=True)
    p.add_argument('--context-len',type=int,default=4000); p.add_argument('--concurrency',type=int,default=1024)
    p.add_argument('--group',type=int,default=32); p.add_argument('--cap',type=int,default=4096); p.add_argument('--seed',type=int,default=42)
    p.add_argument('--window',type=float,default=5); p.add_argument('--settle-tokens',type=int,default=32)
    p.add_argument('--timeout',type=float,default=240); p.add_argument('--prefill-timeout',type=float,default=100)
    asyncio.run(bench(p.parse_args()))


if __name__=='__main__':
    main()
