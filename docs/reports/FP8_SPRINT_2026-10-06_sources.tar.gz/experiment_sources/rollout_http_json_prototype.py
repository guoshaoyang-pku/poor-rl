"""Use installed msgspec for full routed JSON responses with native JSON fallback."""
import ast
import hashlib
import inspect
import json
import textwrap
import time

import msgspec

_COUNTS=dict(calls=0,fast=0,fallback=0,decode_ns=0)


def decode_json(value):
    started=time.perf_counter_ns()
    _COUNTS['calls']+=1
    try:
        result=msgspec.json.decode(value)
        _COUNTS['fast']+=1
        return result
    except msgspec.DecodeError:
        _COUNTS['fallback']+=1
        return json.loads(value)
    finally:
        _COUNTS['decode_ns']+=time.perf_counter_ns()-started


def transform(source):
    tree=ast.parse(textwrap.dedent(source))
    method=tree.body[0]
    assert isinstance(method,ast.AsyncFunctionDef) and method.name=='_post_routed'
    calls=[node for node in ast.walk(method) if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and ast.unparse(node.func)=='response.json']
    assert len(calls)==1 and not calls[0].args and not calls[0].keywords
    calls[0].keywords.append(ast.keyword(arg='loads',value=ast.Name(id='poor_rl_response_json',ctx=ast.Load())))
    return ast.fix_missing_locations(tree)


def install():
    from rlforge import dp_route
    cls=dp_route.GroupAffineRolloutLoop
    if getattr(cls,'_poor_rl_response_json_installed',False):
        return dict(already_installed=True)
    native=cls._post_routed
    source=inspect.getsource(native)
    namespace=dict(native.__globals__,poor_rl_response_json=decode_json)
    exec(compile(transform(source),'<poor-rl full response JSON decoder>','exec'),namespace)
    cls._post_routed=namespace['_post_routed']
    cls._poor_rl_response_json_installed=True
    return dict(native_method_sha256=hashlib.sha256(source.encode()).hexdigest(),
                full_response_decoded=True,native_aiohttp_encoding_status_content_type_retry_preserved=True)


def stats():
    return dict(_COUNTS)
