"""Incremental exact-reference dispatch with one canonical JSON pass per request."""
from __future__ import annotations

import ast
import hashlib
import inspect
import json
import time
from collections import deque

import reference_prefetch
from reference_ahead import tensor_identity
from reference_ahead_v3 import INPUT_NAMES, ReferenceAheadV3Client, install_for_trainer


def _structural_validator():
    tree = ast.parse(inspect.getsource(reference_prefetch.validate_payload))
    function = tree.body[0]
    checks = [node for node in function.body if isinstance(node, ast.If)
              and ast.unparse(node.test) == "body.get('request_sha256') != request_hash(body)"]
    if len(checks) != 1:
        raise ValueError("Frozen reference fingerprint check changed")
    function.body.remove(checks[0])
    function.name = "_validate_structure"
    namespace = dict(reference_prefetch.__dict__)
    exec(compile(tree, __file__, "exec"), namespace)
    return namespace[function.name]


_validate_structure = _structural_validator()


def prepare_compact(ids, mask, sb, reference_sha256, source_sha256, temperature):
    prefix = int(sb["P"])
    prompt = ids[sb["a0"]:sb["a0"] + prefix]
    compact_ids, compact_mask, buckets, global_slots = [], [], [], []
    for bucket in sb["buckets"]:
        compact_bucket = []
        for start, end in bucket:
            if not 0 <= start <= start + prefix < end <= len(ids):
                raise ValueError("Invalid original branch range")
            if ids[start:start + prefix] != prompt:
                raise ValueError("Original branches have different prompt prefixes")
            offset = len(compact_ids)
            compact_ids.extend(ids[start:end])
            compact_mask.extend(mask[start:end])
            compact_bucket.append([offset, len(compact_ids)])
            global_slots.extend(t - 1 for t in range(start + prefix + 1, end) if mask[t])
        buckets.append(compact_bucket)
    compact_sb = dict(sb, a0=0, buckets=buckets)
    body = {"schema": reference_prefetch.SCHEMA, "precision": "BF16",
            "reference_sha256": reference_sha256, "source_sha256": source_sha256,
            "temperature": float(temperature), "input_ids": compact_ids,
            "completion_mask": compact_mask, "subbatch": compact_sb,
            "expected_slots": []}
    for bucket in buckets:
        for start, end in bucket:
            body["expected_slots"].extend(t - 1 for t in range(start + prefix + 1, end) if compact_mask[t])
    _validate_structure(body)
    if len(global_slots) != len(body["expected_slots"]):
        raise ValueError("Compact reference changed completion-slot count")
    canonical = json.dumps(body, sort_keys=True, separators=(",", ":")).encode()
    digest = hashlib.sha256(canonical).hexdigest()
    body["request_sha256"] = digest
    wire = canonical[:-1] + b',"request_sha256":"' + digest.encode() + b'"}'
    return body, wire, global_slots


class ReferenceAheadV4Client(ReferenceAheadV3Client):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.stats.update(incremental_batches=0, first_dispatch_ms_total=0.0,
                          last_dispatch_ms_total=0.0, canonical_json_passes=0)

    def stage_inputs(self, inputs, budget):
        owners = tuple(inputs[name] for name in INPUT_NAMES)
        identity = tensor_identity(owners)
        super().stage_inputs(inputs, budget)
        if tensor_identity(owners) != identity:
            error = ValueError("Original batch changed during host staging")
            self.cancel(error)
            raise error

    def _prepare_one(self, ids, mask, sb, key):
        body, wire, slots = prepare_compact(ids, mask, sb, self.reference_sha256,
                                           self.source_sha256, self.temperature)
        self.stats["request_full_input_tokens"] += len(ids)
        self.stats["request_compact_input_tokens"] += len(body["input_ids"])
        self.stats["request_bytes"] += len(wire)
        self.stats["canonical_json_passes"] += 1
        return (key, body, wire, int(sb["tokens"])), slots

    def _prepare(self, ids, mask, plan):
        start = time.perf_counter()
        keys = [json.dumps(sb, sort_keys=True) for sb in plan]
        if len(keys) != len(set(keys)):
            raise ValueError("Duplicate reference subbatch")
        prepared, slots = [], []
        for key, sb in zip(keys, plan):
            item, item_slots = self._prepare_one(ids, mask, sb, key)
            prepared.append(item)
            slots.extend(item_slots)
        if sorted(slots) != [t - 1 for t in range(1, len(mask)) if mask[t]]:
            raise ValueError("Reference must score every fresh completion exactly once")
        self.stats["stage_payload_ms"] += 1000 * (time.perf_counter() - start)
        return prepared

    def stage_lists(self, ids, mask, plan, *, owners=()):
        start = time.perf_counter()
        identity = tensor_identity(owners)
        keys = [json.dumps(sb, sort_keys=True) for sb in plan]
        if not keys or len(keys) != len(set(keys)):
            raise ValueError("Empty or duplicate reference subbatch plan")
        pending, slots = {}, []
        try:
            with self.lock:
                if self.failure is not None or self.closed:
                    raise RuntimeError("Reference client failed or closed") from self.failure
                if self.staged_count >= self.max_ahead:
                    raise RuntimeError("Reference lookahead exceeds GAS batch capacity")
            for key, sb in zip(keys, plan):
                item, item_slots = self._prepare_one(ids, mask, sb, key)
                slots.extend(item_slots)
                with self.lock:
                    if self.failure is not None or self.closed:
                        raise RuntimeError("Reference client failed or closed") from self.failure
                    pending.update(self._submit_locked([item]))
                elapsed = 1000 * (time.perf_counter() - start)
                if len(pending) == 1:
                    self.stats["first_dispatch_ms_total"] += elapsed
            if sorted(slots) != [t - 1 for t in range(1, len(mask)) if mask[t]]:
                raise ValueError("Reference must score every fresh completion exactly once")
            if tensor_identity(owners) != identity:
                raise ValueError("Original batch changed during reference preparation")
            batch_key = identity if owners else tuple(body["request_sha256"] for body, _future in pending.values())
            with self.lock:
                self.staged.setdefault(batch_key, deque()).append((pending, tuple(owners), identity, tuple(pending)))
                self.staged_count += 1
                self.stats["ahead_submitted_batches"] += 1
                self.stats["ahead_peak_batches"] = max(self.stats["ahead_peak_batches"], self.staged_count)
                self.stats["incremental_batches"] += 1
                self.stats["last_dispatch_ms_total"] += elapsed
        except BaseException as error:
            for _body, future in pending.values():
                future.cancel()
            self.cancel(error)
            raise
        finally:
            self.stats["stage_payload_ms"] += 1000 * (time.perf_counter() - start)
