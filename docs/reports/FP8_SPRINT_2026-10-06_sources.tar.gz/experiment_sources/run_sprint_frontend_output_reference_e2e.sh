#!/bin/bash
set -euo pipefail
ARM="${1:?bf16 or fp8}"
BENCH_ROOT=/data/shared/guoshaoyang/aiq_rl_store/fp8_sprint_20261005
HIST_ROOT=/data/shared/guoshaoyang/aiq_rl_store/benchmarks/v1_4plus4_20261004
source /data/home/guoshaoyang/aiq_rl/env_360_2.sh
source "$VENV/bin/activate"
cd "$BENCH_ROOT"
OUT="$BENCH_ROOT/e2e/${ARM}${SCALE_SUFFIX:-}"
test ! -e "$OUT"
mkdir -p "$OUT"
export MODEL=/data/shared/guoshaoyang/aiq_rl_store/models/v3_1e_ckpt100_20261003
export RLFORGE_REF_MODEL=/data/shared/guoshaoyang/aiq_rl_store/models/v3_ckpt175_20261003
export RLFORGE_BASE_MODEL=/data/home/guoshaoyang/models/Qwen3.5-0.8B-ms
export AIQ_BASE_MODEL="$RLFORGE_BASE_MODEL"
export RLFORGE_TASK_LOG="$OUT/task_split.jsonl" AIQ_SAMPLE_LOG="$OUT/rollout_samples.jsonl"
export AIQ_HALLUC=1 AIQ_HALLUC_K=2 AIQ_HALLUC_LUNA_REWARD=1 AIQ_HALLUC_THREADS=16
export AIQ_HALLUC_RPM=18 AIQ_HALLUC_BURST=16 AIQ_HALLUC_JUDGE_FRAC=0.24
export AIQ_HALLUC_RULES_REWARD=0 AIQ_HALLUC_TIMEOUT_S="${SPRINT_JUDGE_TIMEOUT_S:-90}"
export AIQ_HALLUC_PROVIDER=cctq AIQ_HALLUC_MODEL=gpt-5.6-luna
export AIQ_HALLUC_BASE_URL="${SPRINT_JUDGE_BASE_URL:-http://127.0.0.1:3130/v1}" AIQ_HALLUC_GROUPS_PER_STEP=32
export AIQ_HALLUC_SELECT=scored
export AIQ_HALLUC_PRICE_PER_M=0.1 AIQ_HALLUC_BUDGET_YUAN=250 AIQ_HALLUC_K_OVER_BUDGET=2
unset AIQ_HALLUC_K_FILE AIQ_EVAL_KEYS
export VLLM_SERVER_DEV_MODE=1 VLLM_HTTP_TIMEOUT_KEEP_ALIVE=3600
export VLLM_HOST_IP=10.234.161.3 NCCL_SOCKET_IFNAME=bond4 GLOO_SOCKET_IFNAME=bond4
export NCCL_IB_HCA='^mlx5_bond_0' PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 VLLM_USE_FLASHINFER_SAMPLER=0
export LOCAL_KERNELS=kernels-community/flash-attn3=/data/home/guoshaoyang/aiq_rl/flash_attn3_local
export RLFORGE_FUSED_OPS="${SPRINT_FUSED_OPS:-}" RLFORGE_FAST_LOGPROB=1 RLFORGE_LOGPROB_BWD=tf32
export RLFORGE_DP_SIZE="${SPRINT_ROLLOUT_DP:-4}" RLFORGE_JUDGED_STALE_FIXED=1
export RLFORGE_SB_ACT_GB="${SCALE_ACT_GB:-80}" RLFORGE_SB_MEM_FULL_KB="${SPRINT_MEM_FULL_KB:-128}" RLFORGE_SB_MEM_CKPT_KB=4.7 RLFORGE_SB_MEM_BASE_KB=16
export RLFORGE_FP8_ALIGN_COMPILE=1 RLFORGE_FP8_GRAPHS=0 RLFORGE_FP8_HEAD_GRAPH=0
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export TMPDIR="$BENCH_ROOT/cache/e2e" TRITON_CACHE_DIR="$BENCH_ROOT/cache/triton" TORCHINDUCTOR_CACHE_DIR="$BENCH_ROOT/cache/inductor"
mkdir -p "$TMPDIR" "$TRITON_CACHE_DIR" "$TORCHINDUCTOR_CACHE_DIR"
PORT=8039; ACC_PORT=29539; STEPS=${SPRINT_STEPS:-4}; PREC=bf16; STALE=3; INFLIGHT=${SPRINT_INFLIGHT:-960}
CPS=${SPRINT_CPS_PER_RANK:-256}
SOURCE="${SCALE_SOURCE:-$BENCH_ROOT/code}"
SERVE_ENTRY="${SPRINT_SERVE_ENTRY:-serve_frontend_output_dedicated_entry.py}"
TRAIN_ENTRY="${SPRINT_TRAIN_ENTRY:-train_sprint_entry.py}"
SERVER_FLAGS=(--tensor-parallel-size 1 --data-parallel-size "${SPRINT_ROLLOUT_DP:-4}" --data-parallel-size-local 4 --api-server-count "${SPRINT_API_SERVERS:-${SPRINT_ROLLOUT_DP:-4}}" --data-parallel-address 10.234.161.3 --data-parallel-rpc-port 13439 --max-num-seqs 2048 --max-num-batched-tokens "${SPRINT_SERVE_MAX_TOKENS:-32768}" --max-cudagraph-capture-size 2048 --async-scheduling)
TRAIN_FLAGS=(--prefix-share on --token-budget 0 --dp-route on --queue-maxsize "${SPRINT_QUEUE_MAXSIZE:-512}" --score-concurrency "${SPRINT_SCORE_CONCURRENCY:-32}" --judged-max-staleness 7 --drop-audit on --subbatch-tokens "${SPRINT_SUBBATCH:-131072}" --sb-ckpt "${SPRINT_CKPT:-auto}" --balance-rows on)
if [ "${SPRINT_SERVE_KV:-0}" = 1 ]; then
  export RLFORGE_SPRINT_KV=1
  SERVER_FLAGS+=(--worker-extension-cls serving_sampler_prototype.StatsWorker)
fi
case "$ARM" in
  bf16) ;;
  fp8)
    export RLFORGE_FP8_ALIGN_POINTWISE=1
    TRAIN_FLAGS+=(--dtype none --fp8 native --fp8-align "${SPRINT_FP8_ALIGN:-vllm}")
    SERVER_FLAGS+=(--quantization poor_rl_fp8 --mamba-ssm-cache-dtype "${SPRINT_SSM_DTYPE:-float32}" --additional-config '{"gdn_prefill_backend":"triton"}')
    if [ "${SPRINT_KV:-bf16}" != bf16 ]; then SERVER_FLAGS+=(--kv-cache-dtype "$SPRINT_KV"); fi
    ;;
  *) echo "Unknown arm $ARM"; exit 2 ;;
esac
export VLLM_DISABLE_COMPILE_CACHE=1
export PYTHONPATH="$SOURCE:$BENCH_ROOT:$HIST_ROOT"
export SCALE_ARM="$ARM" SCALE_OUT="$OUT" SCALE_ROOT="$BENCH_ROOT" SCALE_SOURCE="$SOURCE"
"$VENV/bin/python" - <<'CHECK'
import pathlib,os,socket,urllib.request,urllib.error
assert pathlib.Path(os.environ['SCALE_SOURCE'],'rlforge','trainer.py').is_file()
for port in [8039,13439,29539]:
    with socket.socket() as s:
        assert s.connect_ex(('127.0.0.1',port)), 'port already bound '+str(port)
if os.getenv('SPRINT_CONTROL_PORT'):
    with socket.socket() as s:
        assert s.connect_ex(('127.0.0.1',int(os.environ['SPRINT_CONTROL_PORT']))), 'control port already bound'
try:
    with urllib.request.urlopen(os.environ['AIQ_HALLUC_BASE_URL'].rsplit('/v1',1)[0]+'/health',timeout=10) as r:
        assert r.status==200
except urllib.error.HTTPError as e:
    assert e.code==501, 'judge relay rejected health: '+str(e.code)
print('Judge relay listener checked; upstream health will be verified from actual scoring outcomes.')
CHECK
printf '%s\n' "$ARM" > "$OUT/arm.txt"
"$VENV/bin/python" - "$OUT" "$ARM" "$PREC" "$STALE" "$INFLIGHT" "$STEPS" <<'PY'
import datetime,hashlib,importlib.metadata,json,os,pathlib,shutil,sys
out,arm,prec,stale,inflight,steps=sys.argv[1:]
root=pathlib.Path('/data/shared/guoshaoyang/aiq_rl_store/benchmarks/v1_4plus4_20261004')
m=json.loads((root/'inputs.json').read_text())
for filename,want in m['input_sha256'].items():
    assert hashlib.sha256(pathlib.Path(filename).read_bytes()).hexdigest()==want, 'input changed: '+filename
assert hashlib.sha256((root/'aiq_think_reward_v3.py').read_bytes()).hexdigest()=='48cde570dd3c4e389b92088ee787c01ef345ecdc8d851c65f606da1048999e66'
m.pop('fp32_backend_note',None)
m.update(arm=arm,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),stop_reason=None,
         code_revision='2d9295ec6c78d717ab7b909500bb175cad88c892 plus recorded experimental source/prototype hashes',
         bootstrap='FileStore DDP guarded spawn; scoped vLLM pip metadata fallback',
         bootstrap_sha256={name:hashlib.sha256((pathlib.Path(os.environ['SCALE_ROOT'])/name).read_bytes()).hexdigest() for name in ['train_filestore.py','train_sprint_entry.py',os.getenv('SPRINT_TRAIN_ENTRY','train_sprint_entry.py'),'serve_driver.py',os.getenv('SPRINT_SERVE_ENTRY','serve_frontend_output_dedicated_entry.py'),'run_sprint_cpu_reference_e2e.sh','run_sprint_cpu_v2_reference_e2e.sh','run_sprint_frontend_output_reference_e2e.sh']},
         gpu_layout={'trainer':[4,5,6,7],'rollout':[0,1,2,3],'rollout_mode':'DP'+os.getenv('SPRINT_ROLLOUT_DP','4')+' TP1','remote_rollout_gpus': os.getenv('SPRINT_REMOTE_ROLLOUT_GPUS',''),'reference_endpoints':os.getenv('RLFORGE_REFERENCE_ENDPOINTS','').split(',') if os.getenv('RLFORGE_REFERENCE_ENDPOINTS') else []},
         precision={'master':'float32','optimizer':'float32 Adam','compute':'native FP8 PTPC forward and E5M2/E4M3 backward; BF16/FP32 sensitive operations' if arm=='fp8' else 'bfloat16 autocast FA3, fast logprob TF32 backward','rollout':'poor_rl_fp8 stateless PTPC' if arm=='fp8' else 'bfloat16','kv':os.getenv('SPRINT_KV','auto/bfloat16')},
         hyperparams={'seed':0,'cps_per_rank':256,'ngen':32,'gas':8,'lr':2e-6,'warmup_steps':5,'eps_low':0.004,'eps_high':0.004,'kl_beta':0.05,'max_completion':16384,'max_model_len':24576,'temperature':1.0,'top_p':1.0,'steps':int(steps),'max_staleness':int(stale),'inflight':int(inflight),'judge':{'enabled':True,'k':2,'threads':16,'fraction':0.24,'rpm':18,'burst':16,'timeout_s':90,'selection':'scoring order'}},
         environment={n:importlib.metadata.version(n) for n in ['torch','transformers','trl','vllm','accelerate']},
         expected_samples_per_step=1024,
         tuning_env={k:os.getenv(k,'') for k in ['RLFORGE_FUSED_OPS','RLFORGE_FAST_LOGPROB','RLFORGE_LOGPROB_BWD','RLFORGE_FP8_ALIGN_COMPILE','RLFORGE_FP8_ALIGN_POINTWISE','RLFORGE_FP8_ALIGN_BACKWARD','VLLM_DISABLE_COMPILE_CACHE','RLFORGE_FP8_GRAPHS','RLFORGE_FP8_HEAD_GRAPH','RLFORGE_LOGPROB_TOK_CHUNK','RLFORGE_LOGPROB_VOCAB_CHUNK','RLFORGE_SB_ACT_GB','RLFORGE_SB_MEM_FULL_KB','RLFORGE_SB_MEM_CKPT_KB','RLFORGE_SB_MEM_BASE_KB']},
         infra_differences=['matched native FP8 trainer and rollout vs production BF16/TF32 trainer and BF16 rollout'])
m['source_sha256']={str(p.relative_to(pathlib.Path(os.environ['SCALE_SOURCE']))):hashlib.sha256(p.read_bytes()).hexdigest() for p in (pathlib.Path(os.environ['SCALE_SOURCE'])/'rlforge').rglob('*.py')}
m['steps']=int(steps)
m['hyperparams']['cps_per_rank']=int(os.getenv('SPRINT_CPS_PER_RANK','256'))
m['hyperparams']['actual_microbatch_per_rank']=int(os.getenv('SPRINT_MICROBATCH','32'))
assert m['hyperparams']['cps_per_rank'] % m['hyperparams']['actual_microbatch_per_rank'] == 0
m['hyperparams']['gas']=m['hyperparams']['cps_per_rank']//m['hyperparams']['actual_microbatch_per_rank']
m['expected_samples_per_step']=4*m['hyperparams']['cps_per_rank']
m['hyperparams']['judge']['timeout_s']=int(os.getenv('SPRINT_JUDGE_TIMEOUT_S','90'))
m['sprint_settings']={k:os.getenv(k,'') for k in ['SPRINT_TRAIN_ARM','SPRINT_TRAIN_PROTOTYPES','SPRINT_FP8_ALIGN','SPRINT_FUSED_OPS','SPRINT_KV','SPRINT_STEPS','SPRINT_SUBBATCH','SPRINT_MICROBATCH','SPRINT_MEM_FULL_KB','SPRINT_JUDGE_TIMEOUT_S','RLFORGE_REFERENCE_ENDPOINTS','RLFORGE_REFERENCE_MODE']}
m['reference_offload_sha256']={name:hashlib.sha256((pathlib.Path(os.environ['SCALE_ROOT'])/name).read_bytes()).hexdigest() for name in ['reference_prefetch.py','reference_ahead.py','reference_ahead_v3.py','reference_ahead_v4.py','reference_ahead_v5.py','train_reference_filestore.py','train_reference_ahead_filestore.py','train_reference_ahead_v3_filestore.py','train_reference_ahead_v4_filestore.py','train_reference_ahead_v5_filestore.py'] if (pathlib.Path(os.environ['SCALE_ROOT'])/name).exists()}
m['serving_prototype_sha256']={name:hashlib.sha256((pathlib.Path(os.environ['SCALE_ROOT'])/name).read_bytes()).hexdigest() for name in ['serving_kv_prototype.py','serving_sampler_prototype.py','serving_pause_observer.py','serving_control_observer.py','serve_pause_observed_entry.py','serve_kv_bandwidth_entry.py','kv_bandwidth_worker.py'] if (pathlib.Path(os.environ['SCALE_ROOT'])/name).exists()}
m['sprint_settings'].update({k:os.getenv(k,'') for k in ['SPRINT_TRAIN_ENTRY','SPRINT_SERVE_ENTRY','SPRINT_SERVE_KV','SPRINT_ROLLOUT_DP','SPRINT_REMOTE_ROLLOUT_GPUS','SPRINT_CKPT','SPRINT_INFLIGHT','SPRINT_CPS_PER_RANK','SPRINT_QUEUE_MAXSIZE','SPRINT_SCORE_CONCURRENCY','SPRINT_CONTROL_OBSERVE','SPRINT_CONTROL_SESSION','SPRINT_CONTROL_BASE_URL','SPRINT_CONTROL_PORT','SPRINT_API_SERVERS','SPRINT_API_FAIRNESS','SPRINT_COLLATOR_TENSORIZE','VLLM_V1_OUTPUT_PROC_CHUNK_SIZE']})
for name in ['serving_dedicated_control.py','serve_control_observed_entry.py','serving_output_fairness_prototype.py']:
    if (pathlib.Path(os.environ['SCALE_ROOT'])/name).exists():
        m['serving_prototype_sha256'][name]=hashlib.sha256((pathlib.Path(os.environ['SCALE_ROOT'])/name).read_bytes()).hexdigest()
if os.getenv('SPRINT_CONTROL_OBSERVE') == '1':
    m['bootstrap_sha256']['trainer_control_observer.py']=hashlib.sha256((pathlib.Path(os.environ['SCALE_ROOT'])/'trainer_control_observer.py').read_bytes()).hexdigest()
for name in ['train_host_observed_entry.py','trainer_host_observer.py','collator_tensorize_prototype.py',
             'train_prompt_cache_host_entry.py','rollout_prompt_cache_prototype.py',
             'rollout_http_json_prototype.py','train_prompt_cache_json_host_entry.py',
             'dispatcher_defer_prototype.py','train_deferred_cache_json_host_entry.py',
             'train_deferred_v5_cache_json_host_entry.py',
             'rollout_group_flow_prototype.py','train_group_flow_v5_entry.py']:
    if (pathlib.Path(os.environ['SCALE_ROOT'])/name).exists():
        m['bootstrap_sha256'][name]=hashlib.sha256((pathlib.Path(os.environ['SCALE_ROOT'])/name).read_bytes()).hexdigest()
m['sprint_settings'].update({k:os.getenv(k,'') for k in ['SPRINT_ROLLOUT_PROMPT_CACHE','SPRINT_ROLLOUT_JSON','SPRINT_DEFERRED_DISPATCH','SPRINT_REFERENCE_PLAN_REUSE','SPRINT_GROUP_CAP']})
if int(os.getenv('SPRINT_ROLLOUT_DP','4')) == 7:
    m['gpu_layout']['reference_rollout_colocation']='360-1 GPU5/6 own full BF16 reference workers plus rollout ranks5/6; remote serving utilization0.70; 11 physical GPUs total'
m['sprint_settings']['SPRINT_SSM_DTYPE']=os.getenv('SPRINT_SSM_DTYPE','float32')
if int(os.getenv('SPRINT_ROLLOUT_DP','4')) == 5:
    m['gpu_layout']['reference_rollout_colocation']='none: BF16 references exclusively 360-1 GPU5/6; rollout remoteGPU1; 11 physical GPUs total'

m['serving_cpu_sha256']={name:hashlib.sha256((pathlib.Path(os.environ['SCALE_ROOT'])/name).read_bytes()).hexdigest() for name in ['serve_cpu_dedicated_entry.py','serve_cpu_ssm_entry.py','serving_scheduler_prototype.py','serving_decode_scheduler_prototype.py','serving_output_prototype.py'] if (pathlib.Path(os.environ['SCALE_ROOT'])/name).exists()}
m['serving_kv_partial_sha256']={name:hashlib.sha256((pathlib.Path(os.environ['SCALE_ROOT'])/name).read_bytes()).hexdigest() for name in ['serve_kv_partial_dedicated_entry.py','serve_kv_partial_proof_entry.py','serving_kv_partial_proof_prototype.py']}
m['frontend_output_sha256']={name:hashlib.sha256((pathlib.Path(os.environ['SCALE_ROOT'])/name).read_bytes()).hexdigest() for name in ['serve_frontend_output_dedicated_entry.py','serve_output_request_dedicated_entry.py','serving_output_request_prototype.py','serving_flat_logprobs_prototype.py','serving_completion_json_v2_prototype.py','train_payload_encoder_tail_v5_entry.py','reference_payload_encoder_prototype.py']}
m['reference_payload_encoder']='exactASCIIcanonicalf228d; nativewirefallback forothermetadata'

m['group_tail_sha256']={name:hashlib.sha256((pathlib.Path(os.environ['SCALE_ROOT'])/name).read_bytes()).hexdigest() for name in ['train_group_tail_v5_entry.py','rollout_group_tail_observer.py'] if (pathlib.Path(os.environ['SCALE_ROOT'])/name).exists()}
m['judge_relay_base_url']=os.environ['AIQ_HALLUC_BASE_URL']
m['prototype_sha256']={name:hashlib.sha256((pathlib.Path(os.environ['SCALE_ROOT'])/(name+'.py')).read_bytes()).hexdigest() for name in os.getenv('SPRINT_TRAIN_PROTOTYPES','').split(',') if name}
m['comparison_boundary']='Speed-first precision/kernel/batch arms recorded individually. No numerical train/decode gate implied. Counts are actual trained completions, full BF16 frozen reference retained.'

(pathlib.Path(out)/'run.json').write_text(json.dumps(m,indent=2))
shutil.copytree(pathlib.Path(os.environ['SCALE_SOURCE'])/'rlforge',pathlib.Path(out)/'code_snapshot',ignore=shutil.ignore_patterns('__pycache__'))
PY
"$VENV/bin/python" - <<'PY'
import subprocess
lines=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert not lines, 'GPUs were claimed by another job; refusing launch: '+lines
PY
SERVER_PID=; TRAINER_PID=; TELEMETRY_PID=; REASON=startup; RC=1
cleanup() {
  trap '' TERM INT
  for p in "$TRAINER_PID" "$SERVER_PID"; do
    [ -z "$p" ] || kill -TERM -- "-$p" 2>/dev/null || true
  done
  [ -z "$TELEMETRY_PID" ] || kill -TERM "$TELEMETRY_PID" 2>/dev/null || true
  for ((i=0;i<30;i++)); do
    alive=0
    for p in "$TRAINER_PID" "$SERVER_PID"; do
      if [ -n "$p" ] && kill -0 -- "-$p" 2>/dev/null; then alive=1; fi
    done
    [ "$alive" = 0 ] && break
    sleep 1
  done
  for p in "$TRAINER_PID" "$SERVER_PID"; do
    [ -z "$p" ] || kill -KILL -- "-$p" 2>/dev/null || true
  done
  "$VENV/bin/python" - "$OUT" "$REASON" "$RC" <<'PY'
import datetime,json,pathlib,sys
p=pathlib.Path(sys.argv[1])/'run.json';m=json.loads(p.read_text());m.update(stop_reason=sys.argv[2],trainer_exit_code=int(sys.argv[3]),ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());p.write_text(json.dumps(m,indent=2))
PY
}
trap cleanup EXIT
trap 'REASON=interrupted; RC=143; exit 143' TERM INT
(
  while true; do
    date -u +%FT%TZ
    nvidia-smi --query-gpu=index,utilization.gpu,memory.used,power.draw,temperature.gpu --format=csv,noheader
    sleep 5
  done
) > "$OUT/gpu_telemetry.log" 2>&1 &
TELEMETRY_PID=$!
CUDA_VISIBLE_DEVICES=0,1,2,3 setsid "$VENV/bin/python" "$BENCH_ROOT/$SERVE_ENTRY" serve "$MODEL" --served-model-name "$MODEL" --dtype bfloat16 --max-model-len 24576 --gpu-memory-utilization 0.85 --port "$PORT" --weight-transfer-config '{"backend":"nccl"}' "${SERVER_FLAGS[@]}" > "$OUT/vllm.log" 2>&1 &
SERVER_PID=$!
printf '%s\n' "$SERVER_PID" > "$OUT/server.pid"
for ((i=0;i<240;i++)); do
  if curl -fsS "http://127.0.0.1:$PORT/health" >/dev/null 2>&1; then break; fi
  kill -0 "$SERVER_PID" 2>/dev/null || { REASON=server_failed; exit 1; }
  sleep 5
done
curl -fsS "http://127.0.0.1:$PORT/health" >/dev/null || { REASON=server_startup_timeout; exit 1; }
CUDA_VISIBLE_DEVICES=4,5,6,7 ACCELERATE_MIXED_PRECISION=$PREC ACCELERATE_DYNAMO_BACKEND=NO OMP_NUM_THREADS=1 setsid "$VENV/bin/python" "$BENCH_ROOT/$TRAIN_ENTRY" --model "$MODEL" --train /data/shared/guoshaoyang/aiq_rl_store/data/rl_pool_b_v0_think/train_think.jsonl --out "$OUT" --epochs 40 --lr 2e-6 --completions-per-step "$CPS" --num-generations 32 --max-completion 16384 --max-steps "$STEPS" --save-steps 1000 --max-staleness "$STALE" --max-inflight-tasks "$INFLIGHT" --report-to none --reward aiq_think_reward_v3:think_reward --server-url "http://localhost:$PORT" --request-timeout 5400 --gspo --gspo-norm seq_mean --gspo-eps-low 4e-3 --gspo-eps-high 4e-3 --per-seq-forward auto --kl-beta 0.05 "${TRAIN_FLAGS[@]}" > "$OUT/trainer.log" 2>&1 &
TRAINER_PID=$!
printf '%s\n' "$TRAINER_PID" > "$OUT/trainer.pid"
set +e
wait "$TRAINER_PID"
RC=$?
set -e
REASON=completed
[ "$RC" = 0 ] || REASON=trainer_failed
exit "$RC"
