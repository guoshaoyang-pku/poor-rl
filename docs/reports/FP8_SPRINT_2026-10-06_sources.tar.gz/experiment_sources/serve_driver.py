"""Register the isolated FP8 plugin before vLLM parses model arguments."""
import importlib.metadata
import vllm.collect_env as collect_env
from rlforge.fp8_serving import register

register()
original = collect_env.get_pip_packages

def get_pip_packages(run):
    try:
        return original(run)
    except (AttributeError, RuntimeError):
        packages = [name + '==' + importlib.metadata.version(name)
                    for name in ['torch', 'vllm', 'transformers', 'triton']]
        return 'importlib.metadata', '\n'.join(packages)

collect_env.get_pip_packages = get_pip_packages
from vllm.entrypoints.cli.main import main

if __name__ == '__main__':
    main()
