"""Root-owned vLLM launch and closed-loop rollout saturation measurements."""
import argparse
import asyncio
import datetime
import hashlib
import importlib.metadata
import json
import os
import random
import re
import socket
import statistics
import subprocess
import sys
import time
from pathlib import Path


METRICS = [
    'vllm:generation_tokens_total', 'vllm:prompt_tokens_total',
    'vllm:num_requests_running', 'vllm:num_requests_waiting',
    'vllm:kv_cache_usage_perc', 'vllm:gpu_cache_usage_perc',
    'vllm:num_preemptions_total', 'vllm:prefix_cache_hits_total',
    'vllm:prefix_cache_queries_total',
]


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def parse_metrics(raw):
    result = {}
    for key in set(METRICS):
        matches = re.findall(r'^' + re.escape(key) + r'(?:[{][^}]*[}])?[ \t]+([0-9.eE+-]+)[ \t]*$', raw, re.M)
        if matches:
            result[key] = sum(map(float, matches))
    if 'vllm:gpu_cache_usage_perc' in result and 'vllm:kv_cache_usage_perc' not in result:
        result['vllm:kv_cache_usage_perc'] = result['vllm:gpu_cache_usage_perc']
    return result


def save(path, result):
    Path(path).write_text(json.dumps(result, indent=2))


def provenance(root):
    versions = {}
    for name in ['torch', 'vllm', 'transformers', 'triton', 'httpx']:
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            versions[name] = None
    files = root / 'code' / 'rlforge'
    return {
        'hostname': socket.gethostname(), 'pid': os.getpid(),
        'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'script_sha256': sha256(__file__), 'versions': versions,
        'source_sha256': {name: sha256(files / name) for name in ['fp8.py', 'fp8_serving.py']
                          if (files / name).is_file()},
        'CUDA_VISIBLE_DEVICES': os.getenv('CUDA_VISIBLE_DEVICES'),
    }


def serve(args):
    root = Path(args.root).resolve()
    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=True)
    manifest = out / 'serve_manifest.json'
    if manifest.exists():
        raise FileExistsError(manifest)
    model = Path(args.model).resolve()
    if not model.is_dir() or not (root / 'code/rlforge/fp8_serving.py').is_file():
        raise ValueError('Existing checkpoint and fresh sprint/code/rlforge source are required')
    if args.max_batched_tokens < args.max_seqs:
        raise ValueError('max-batched-tokens must cover max-seqs')
    os.environ['PYTHONPATH'] = str(root) + os.pathsep + str(root / 'code') + os.pathsep + os.getenv('PYTHONPATH', '')
    sys.path[:0] = [str(root), str(root / 'code')]
    os.environ.setdefault('OMP_NUM_THREADS', '1')
    os.environ.setdefault('VLLM_USE_FLASHINFER_SAMPLER', '0')
    if args.sampler_prototype or args.kv_prototype or args.profiler_dir:
        os.environ.setdefault('VLLM_SERVER_DEV_MODE', '1')
    sizes = args.capture_sizes
    config = {}
    if args.graph_mode != 'default':
        config['cudagraph_mode'] = args.graph_mode
    if sizes:
        config['cudagraph_capture_sizes'] = sorted(set(sizes))
    command = [
        'vllm', 'serve', str(model), '--served-model-name', str(model),
        '--host', '127.0.0.1', '--port', str(args.port), '--dtype', 'bfloat16',
        '--tensor-parallel-size', '1', '--max-model-len', str(args.max_model_len),
        '--gpu-memory-utilization', str(args.gpu_memory),
        '--max-num-seqs', str(args.max_seqs),
        '--max-num-batched-tokens', str(args.max_batched_tokens),
        '--max-cudagraph-capture-size', str(max(sizes) if sizes else args.max_capture),
        '--kv-cache-dtype', 'auto' if args.kv == 'bf16' else args.kv,
        '--mamba-ssm-cache-dtype', args.ssm_dtype,
        '--enable-prefix-caching' if args.prefix_cache else '--no-enable-prefix-caching',
        '--async-scheduling' if args.async_scheduling else '--no-async-scheduling',
    ]
    if args.weights != 'bf16':
        command += ['--quantization', 'poor_rl_fp8' if args.weights == 'fp8' else 'fp8']
    if args.prefill != 'default':
        command += ['--additional-config', json.dumps({'gdn_prefill_backend': args.prefill})]
    if config:
        command += ['--compilation-config', json.dumps(config)]
    if args.eager:
        command += ['--enforce-eager']
    if args.sampler_prototype:
        os.environ['RLFORGE_SPRINT_SAMPLER'] = '1'
        command += ['--worker-extension-cls', 'serving_sampler_prototype.StatsWorker']
        import serving_sampler_prototype
        serving_sampler_prototype.install()
    if args.kv_prototype:
        os.environ['RLFORGE_SPRINT_KV'] = '1'
        if not args.sampler_prototype:
            command += ['--worker-extension-cls', 'serving_sampler_prototype.StatsWorker']
        import serving_kv_prototype
        serving_kv_prototype.install()
    if args.token_ids_prototype or args.frontend_profile:
        from serving_sampler_prototype import install_frontend
        install_frontend(args.frontend_profile)
    if args.profiler_dir:
        profile = {'profiler': 'torch', 'torch_profiler_dir': str(Path(args.profiler_dir).resolve()),
                   'ignore_frontend': True, 'delay_iterations': 4, 'max_iterations': 8,
                   'torch_profiler_with_stack': args.profiler_stacks, 'torch_profiler_record_shapes': True}
        command += ['--profiler-config', json.dumps(profile)]
    command += args.extra
    state = provenance(root)
    state.update(
        scope='Single-GPU serving saturation; no trainer, judge or weight sync',
        settings=vars(args), command=command, checkpoint=str(model),
        checkpoint_metadata_sha256={p.name: sha256(p) for p in model.iterdir()
                                    if p.name in ['config.json', 'model.safetensors.index.json', 'generation_config.json']},
        checkpoint_tensor_files=[{'name': p.name, 'bytes': p.stat().st_size,
                                  'mtime_ns': p.stat().st_mtime_ns}
                                 for p in sorted(model.glob('*.safetensors'))],
        checkpoint_boundary='Tensor filenames/sizes/mtimes recorded; full tensor content must use root matched input manifest',
        environment={k: os.getenv(k) for k in ['VLLM_USE_FLASHINFER_SAMPLER', 'VLLM_ATTENTION_BACKEND',
                    'VLLM_DISABLE_COMPILE_CACHE', 'OMP_NUM_THREADS', 'HF_HUB_OFFLINE', 'TRANSFORMERS_OFFLINE']},
        quantization_boundary='fp8 uses FP32-master PTPC poor_rl_fp8; stock-fp8 is a changed quantization diagnostic',
        precision_boundary='FP8 KV changes forward numerics; train/decode consistency is a separate gate',
        prototype_sha256=sha256(root / 'serving_sampler_prototype.py')
                         if (args.sampler_prototype or args.token_ids_prototype or args.frontend_profile or args.kv_prototype) else None,
        kv_prototype_sha256=sha256(root / 'serving_kv_prototype.py') if args.kv_prototype else None,
    )
    save(manifest, state)
    try:
        if args.weights == 'fp8':
            from rlforge.fp8_serving import register
            register()
        # Existing vLLM build can fail optional pip diagnostics under this Python.
        import vllm.collect_env as collect_env
        original = collect_env.get_pip_packages

        def packages(run):
            try:
                return original(run)
            except (AttributeError, RuntimeError):
                return 'importlib.metadata fallback', '\n'.join(
                    n + '==' + v for n, v in state['versions'].items() if v is not None)

        collect_env.get_pip_packages = packages
        from vllm.entrypoints.cli.main import main
        sys.argv = command
        main()
    except BaseException as exc:
        state['exit'] = {'type': type(exc).__name__, 'detail': str(exc)[:500]}
        save(manifest, state)
        raise


def read_prompts(args):
    path = Path(args.tokens or args.prompts)
    if args.tokens:
        data = json.loads(path.read_text())
        prompts = [s['token_ids'][:s['prompt_tokens']] for s in data['sequences']]
        checkpoint = data.get('checkpoint')
        boundary = data.get('provenance')
    else:
        from transformers import AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(args.tokenizer, local_files_only=True)
        messages = [json.loads(row)['prompt'] for row in path.read_text().splitlines() if row.strip()]
        prompts = [tokenizer(tokenizer.apply_chat_template(p, tokenize=False, add_generation_prompt=True),
                             add_special_tokens=False)['input_ids'] for p in messages[:args.prompt_limit]]
        checkpoint, boundary = args.tokenizer, 'First declared prompt-limit JSONL prompts, chat template tokenized locally'
    unique = list({tuple(p): p for p in prompts}.values())
    if not unique or any(not p or any(not isinstance(t, int) for t in p) for p in unique):
        raise ValueError('Nonempty token-ID prompts are required')
    encoded = json.dumps(unique, separators=(',', ':')).encode()
    return unique, {'path': str(path.resolve()), 'file_sha256': sha256(path),
                    'unique_prompt_tokens_sha256': hashlib.sha256(encoded).hexdigest(),
                    'unique_prompts': len(unique), 'lengths': [len(p) for p in unique],
                    'checkpoint_or_tokenizer': checkpoint, 'boundary': boundary}


async def bench(args):
    import httpx
    prompts, inputs = read_prompts(args)
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    if any(c <= 0 or c % args.group for c in args.conc):
        raise ValueError('Concurrency must be a positive multiple of G')
    state = provenance(Path(args.root).resolve())
    state.update(scope='Server generation counter deltas in steady closed-loop windows; not trained RL token/s',
                 settings=vars(args), input=inputs, results=[])
    if args.profile:
        state['scope'] = 'Profiled diagnostic window; profiler overhead included, not a serving capacity result'
    if args.serve_manifest:
        state['serve_manifest'] = json.loads(Path(args.serve_manifest).read_text())
        state['serve_manifest_sha256'] = sha256(args.serve_manifest)
    save(output, state)
    base = args.base.rstrip('/')
    async with httpx.AsyncClient(limits=httpx.Limits(max_connections=None, max_keepalive_connections=None),
                                 timeout=args.request_timeout) as client:
        async def scrape():
            r = await client.get(base + '/metrics', timeout=30)
            r.raise_for_status()
            metrics = parse_metrics(r.text)
            if 'vllm:generation_tokens_total' not in metrics:
                raise RuntimeError('Missing generation counter; refuse fake zero throughput')
            return metrics

        async def drain():
            deadline = time.monotonic() + args.drain_timeout
            while True:
                metrics = await scrape()
                if sum(metrics.get(k, 0) for k in ['vllm:num_requests_running', 'vllm:num_requests_waiting']) == 0:
                    return
                if time.monotonic() >= deadline:
                    raise RuntimeError('Server did not drain; next concurrency arm would overlap')
                await asyncio.sleep(1)

        response = await client.get(base + '/v1/models', timeout=30)
        response.raise_for_status()
        model = response.json()['data'][0]['id']
        for conc in args.conc:
            await drain()
            randomizer = random.Random(args.seed)
            counter = 0
            counts = {'success': 0, 'failed': 0, 'returned_tokens': 0, 'cancelled': 0}
            errors, proof, latencies = [], [], []

            async def worker():
                nonlocal counter
                cap = randomizer.randint(1, args.max_tokens)
                while True:
                    request_id = counter
                    counter += 1
                    prompt = prompts[(request_id // args.group) % len(prompts)]
                    body = dict(model=model, prompt=prompt, n=1, temperature=1.0, top_p=1.0,
                                top_k=-1, repetition_penalty=1.0,
                                ignore_eos=True, max_tokens=cap, return_token_ids=True, logprobs=0)
                    if args.token_ids_only:
                        body['return_tokens_as_token_ids'] = True
                        body['vllm_xargs'] = {'poor_rl_token_ids_only': 1}
                    if args.request_seed:
                        body['seed'] = args.seed + request_id
                    started = time.monotonic()
                    try:
                        response = await client.post(base + '/v1/completions', json=body)
                        response.raise_for_status()
                        data = response.json()
                        if len(data.get('choices', [])) != 1:
                            raise ValueError('Expected exactly one choice')
                        choice = data['choices'][0]
                        ids = choice.get('token_ids')
                        lp = (choice.get('logprobs') or {}).get('token_logprobs')
                        if not isinstance(ids, list) or len(ids) != cap or not isinstance(lp, list) or len(lp) != cap:
                            raise ValueError('Completion token IDs/logprobs do not match the forced cap')
                        if data.get('usage', {}).get('completion_tokens') != cap:
                            raise ValueError('Usage token count disagrees with returned token IDs')
                        counts['success'] += 1
                        counts['returned_tokens'] += len(ids)
                        latencies.append(time.monotonic() - started)
                        if len(proof) < 2:
                            proof.append({'request_id': request_id, 'cap': cap, 'finish_reason': choice.get('finish_reason'),
                                          'token_ids_sha256': hashlib.sha256(json.dumps(ids).encode()).hexdigest(),
                                          'token_ids_head': ids[:16], 'logprobs_count': len(lp)})
                    except asyncio.CancelledError:
                        counts['cancelled'] += 1
                        raise
                    except Exception as exc:
                        counts['failed'] += 1
                        if len(errors) < 10:
                            errors.append({'type': type(exc).__name__, 'detail': str(exc)[:300]})
                        await asyncio.sleep(1)
                    cap = args.max_tokens

            tasks = [asyncio.create_task(worker()) for _ in range(conc)]
            telemetry, samples = [], []
            try:
                await asyncio.sleep(args.warmup)
                if args.profile:
                    profile_start = await client.post(base + '/start_profile', timeout=60)
                    profile_start.raise_for_status()
                m0 = await scrape()
                c0 = dict(counts)
                t0 = time.monotonic()
                while time.monotonic() - t0 < args.window:
                    await asyncio.sleep(min(args.sample_interval, max(.001, args.window - (time.monotonic() - t0))))
                    samples.append({'elapsed_s': time.monotonic() - t0, 'metrics': await scrape()})
                    if args.gpu_index is not None:
                        gpu = subprocess.run(['nvidia-smi', '-i', str(args.gpu_index),
                                              '--query-gpu=index,uuid,memory.used,utilization.gpu,power.draw',
                                              '--format=csv,noheader'], text=True, capture_output=True, timeout=10)
                        telemetry.append({'elapsed_s': time.monotonic() - t0, 'returncode': gpu.returncode,
                                          'csv': gpu.stdout.strip()})
                m1 = await scrape()
                dt = time.monotonic() - t0
                deltas = {k: m1[k] - m0[k] for k in METRICS if k.endswith('_total') and k in m0 and k in m1}
                if any(v < 0 for v in deltas.values()):
                    raise RuntimeError('Server counter reset during measured window')
                def average(key):
                    values = [s['metrics'][key] for s in samples if key in s['metrics']]
                    return statistics.mean(values) if values else None
                row = {
                    'concurrency': conc, 'G': args.group, 'max_completion_tokens': args.max_tokens,
                    'window_s': dt, 'generation_token_s': deltas['vllm:generation_tokens_total'] / dt,
                    'counter_deltas': deltas, 'metrics_start': m0, 'metrics_end': m1,
                    'average_running': average('vllm:num_requests_running'),
                    'average_waiting': average('vllm:num_requests_waiting'),
                    'average_kv_usage': average('vllm:kv_cache_usage_perc'),
                    'client_counts_whole_arm': dict(counts),
                    'client_completed_window': {k: counts[k] - c0[k] for k in counts},
                    'failed_request_examples': errors, 'response_proof': proof,
                    'request_latency_median_s_whole_arm': statistics.median(latencies) if latencies else None,
                    'samples': samples, 'gpu_telemetry': telemetry,
                    'valid_counter_window': counts['failed'] == 0 and counts['success'] > 0,
                    'boundary': 'Counters include partial in-flight completions; returned client tokens cannot equal this window delta. First warmup requests have randomized caps; replacement requests use fixed cap.',
                    'profiling_enabled': args.profile,
                    'token_ids_only_requested': args.token_ids_only,
                }
                state['results'].append(row)
                save(output, state)
                print('RESULT ' + json.dumps({k: row[k] for k in ['concurrency', 'generation_token_s',
                                                                  'average_running', 'average_waiting',
                                                                  'average_kv_usage', 'valid_counter_window']}), flush=True)
            finally:
                if args.profile:
                    profile_stop = await client.post(base + '/stop_profile', timeout=60)
                    profile_stop.raise_for_status()
                for task in tasks:
                    task.cancel()
                await asyncio.gather(*tasks, return_exceptions=True)
            await drain()
    state['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save(output, state)


def main():
    parser = argparse.ArgumentParser(__doc__)
    sub = parser.add_subparsers(dest='mode', required=True)
    launch = sub.add_parser('serve')
    launch.add_argument('--root', required=True)
    launch.add_argument('--model', required=True)
    launch.add_argument('--output', required=True)
    launch.add_argument('--port', type=int, default=8042)
    launch.add_argument('--weights', choices=['bf16', 'fp8', 'stock-fp8'], default='fp8')
    launch.add_argument('--kv', choices=['bf16', 'fp8', 'fp8_e4m3', 'fp8_per_token_head', 'int4_per_token_head'], default='bf16')
    launch.add_argument('--ssm-dtype', choices=['float32', 'bfloat16'], default='float32')
    launch.add_argument('--max-seqs', type=int, default=2048)
    launch.add_argument('--max-batched-tokens', type=int, default=32768)
    launch.add_argument('--max-capture', type=int, default=2048)
    launch.add_argument('--capture-sizes', type=int, nargs='+')
    launch.add_argument('--max-model-len', type=int, default=24576)
    launch.add_argument('--gpu-memory', type=float, default=.85)
    launch.add_argument('--graph-mode', choices=['default', 'FULL_AND_PIECEWISE', 'FULL_DECODE_ONLY', 'PIECEWISE', 'NONE'], default='default')
    launch.add_argument('--prefix-cache', action=argparse.BooleanOptionalAction, default=True)
    launch.add_argument('--async-scheduling', action=argparse.BooleanOptionalAction, default=True)
    launch.add_argument('--prefill', choices=['default', 'triton', 'flashinfer'], default='triton')
    launch.add_argument('--eager', action='store_true')
    launch.add_argument('--sampler-prototype', action='store_true')
    launch.add_argument('--kv-prototype', action='store_true')
    launch.add_argument('--token-ids-prototype', action='store_true')
    launch.add_argument('--frontend-profile', help='Directory for eight bounded CPU output-processing cProfile calls')
    launch.add_argument('--profiler-dir', help='Eight real engine iterations with CUDA graphs; /start_profile activates it')
    launch.add_argument('--profiler-stacks', action='store_true')
    launch.add_argument('extra', nargs=argparse.REMAINDER)
    measure = sub.add_parser('bench')
    measure.add_argument('--root', required=True)
    measure.add_argument('--base', default='http://127.0.0.1:8042')
    inputs = measure.add_mutually_exclusive_group(required=True)
    inputs.add_argument('--tokens')
    inputs.add_argument('--prompts')
    measure.add_argument('--tokenizer')
    measure.add_argument('--prompt-limit', type=int, default=64)
    measure.add_argument('--output', required=True)
    measure.add_argument('--serve-manifest')
    measure.add_argument('--conc', type=int, nargs='+', default=[256, 512, 1024, 2048])
    measure.add_argument('--max-tokens', type=int, default=2048)
    measure.add_argument('--group', type=int, default=32)
    measure.add_argument('--warmup', type=float, default=60)
    measure.add_argument('--window', type=float, default=60)
    measure.add_argument('--sample-interval', type=float, default=5)
    measure.add_argument('--drain-timeout', type=float, default=60)
    measure.add_argument('--request-timeout', type=float, default=600)
    measure.add_argument('--gpu-index', type=int)
    measure.add_argument('--seed', type=int, default=0)
    measure.add_argument('--request-seed', action='store_true',
                         help='Diagnostic only: production has no per-request seed and avoids per-sequence RNG loops')
    measure.add_argument('--token-ids-only', action='store_true',
                         help='Opt in to server prototype: retain IDs/logprobs, no incremental text decoding')
    measure.add_argument('--profile', action='store_true',
                         help='Diagnostic only: activate bounded server profiler; window includes profiler overhead')
    args = parser.parse_args()
    if args.mode == 'serve':
        if args.extra[:1] == ['--']:
            args.extra = args.extra[1:]
        serve(args)
    else:
        if args.prompts and not args.tokenizer:
            parser.error('--prompts requires --tokenizer')
        if min(args.warmup, args.window, args.sample_interval, args.drain_timeout) <= 0:
            parser.error('All timing intervals must be positive')
        asyncio.run(bench(args))


if __name__ == '__main__':
    main()
