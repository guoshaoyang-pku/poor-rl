"""Sampled logprob CPU cache on the frozen bulk/full-output native recipe."""
import os
import serve_bulk_frontend_entry
import serving_sample_logprobs_cache_prototype as sample
from vllm.v1.engine.core import EngineCore

sample.install()
sample.toggle(os.environ.get("SPRINT_SAMPLE_LOGPROBS_CACHE", "1") == "1")
native_rpc = EngineCore.collective_rpc


def collective_rpc(self, method, timeout=None, args=(), kwargs=None):
    if method == "sprint_sample_logprobs_cache_stats":
        return [sample.stats()]
    return native_rpc(self, method, timeout, args, kwargs)


EngineCore.collective_rpc = collective_rpc
from fastapi import FastAPI
native_fastapi_init = FastAPI.__init__


def fastapi_init(self, *args, **kwargs):
    native_fastapi_init(self, *args, **kwargs)
    async def local_sample_stats():
        return sample.stats()
    self.add_api_route('/sprint_sample_logprobs_cache_stats', local_sample_stats, methods=['GET'])


FastAPI.__init__ = fastapi_init
if __name__ == "__main__":
    import serve_cpu_dedicated_entry
    serve_cpu_dedicated_entry.serve_dedicated_control_entry.serve_control_observed_entry.serve_pause_observed_entry.serve_kv_bandwidth_entry.serve_kv_observed_entry.serve_driver.main()
