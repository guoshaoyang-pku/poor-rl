"""Observe group tails before installing the frozen group admission entry."""
import ast
import hashlib
import json
import os
from pathlib import Path

if __name__ in ('__main__', '__mp_main__'):
    if __name__ == '__mp_main__':
        import rollout_group_tail_observer as observer
        metadata = observer.install()
        print(json.dumps(dict(group_tail=dict(
            event='spawn_child_installed', pid=os.getpid(), metadata=metadata,
            source_sha256=hashlib.sha256(Path(observer.__file__).read_bytes()).hexdigest(),
            entry_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))), flush=True)
    path = Path(__file__).with_name('train_group_flow_v5_entry.py')
    namespace = dict(__name__=__name__, __file__=str(Path(__file__)),
                     __package__=None, __builtins__=__builtins__)
    exec(compile(ast.parse(path.read_text()), str(path), 'exec'), namespace)
