"""Compose frozen deferred/cache/JSON entry with validated CPU policy-plan reuse."""
import ast
import os
import runpy
from pathlib import Path


def install_reference_route():
    original_run_path = runpy.run_path
    target = Path(__file__).with_name('train_sprint_entry.py').resolve()

    def run_path(path, *args, **kwargs):
        if Path(path).resolve() != target:
            return original_run_path(path, *args, **kwargs)
        if args or set(kwargs) != {'run_name'} or kwargs['run_name'] != '__main__':
            raise ValueError('Unexpected frozen sprint runpy invocation')
        tree = ast.parse(target.read_text())
        changed = 0
        for node in ast.walk(tree):
            if isinstance(node, ast.Constant) and node.value == 'train_reference_ahead_v4_filestore.py':
                node.value = 'train_reference_ahead_v5_filestore.py'
                changed += 1
        if changed != 1:
            raise ValueError('Frozen v4 reference route changed')
        namespace = dict(__name__='__main__', __file__=str(target),
                         __package__=None, __builtins__=__builtins__)
        exec(compile(tree, str(target), 'exec'), namespace)
        return namespace

    runpy.run_path = run_path


if __name__ in ('__main__', '__mp_main__'):
    if __name__ == '__main__' and os.environ.get('SCALE_TRAIN_CHILD') == '1':
        if os.environ.get('RLFORGE_REFERENCE_MODE') != 'ahead_v4':
            raise ValueError('Composed V5 entry requires the frozen ahead_v4 launcher route')
        install_reference_route()
    path = Path(__file__).with_name('train_deferred_cache_json_host_entry.py')
    namespace = dict(__name__=__name__, __file__=str(Path(__file__)),
                     __package__=None, __builtins__=__builtins__)
    exec(compile(ast.parse(path.read_text()), str(path), 'exec'), namespace)
