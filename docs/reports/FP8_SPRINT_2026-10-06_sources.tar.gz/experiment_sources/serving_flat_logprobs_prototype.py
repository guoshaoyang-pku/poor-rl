"""Extract decoded single-entry OpenAI logprobs with native full fields."""
import hashlib
import inspect
import os
import time

_INSTALLED = False
_ENABLED = False
_COUNTS = dict(fast=0, fallback=0, tokens=0, compute_ns=0)
_NATIVE_SHA = None


def install():
    global _INSTALLED, _NATIVE_SHA
    if _INSTALLED:
        return
    from vllm.entrypoints.openai.completion.serving import OpenAIServingCompletion
    from vllm.entrypoints.openai.completion.protocol import CompletionLogProbs
    from vllm.logprobs import FlatLogprobs, Logprob
    native = OpenAIServingCompletion._create_completion_logprobs
    _NATIVE_SHA = hashlib.sha256(inspect.getsource(native).encode()).hexdigest()

    def create(self, token_ids, top_logprobs, num_output_top_logprobs, tokenizer,
               logprob_token_ids=None, initial_text_offset=0, return_as_token_id=None):
        started = time.perf_counter_ns()
        use_placeholders = (return_as_token_id if return_as_token_id is not None
                            else self.return_tokens_as_token_ids)
        flat = type(top_logprobs) is FlatLogprobs
        as_list = type(top_logprobs) is list
        supported = (_ENABLED and (flat or as_list)
                     and type(token_ids) in (list, tuple)
                     and num_output_top_logprobs == 0 and not logprob_token_ids
                     and not use_placeholders)
        if supported:
            n = len(token_ids)
            fields = (top_logprobs.start_indices, top_logprobs.end_indices,
                      top_logprobs.token_ids, top_logprobs.logprobs,
                      top_logprobs.decoded_tokens, top_logprobs.ranks) if flat else (top_logprobs,)
            supported = all(type(field) is list and len(field) == n for field in fields)
        if supported:
            offsets, selected, words, top = [], [], [], []
            offset = initial_text_offset
            for index, token in enumerate(token_ids):
                if flat:
                    if (top_logprobs.start_indices[index] != index
                            or top_logprobs.end_indices[index] != index + 1
                            or top_logprobs.token_ids[index] != token):
                        supported = False
                        break
                    logprob = top_logprobs.logprobs[index]
                    word = top_logprobs.decoded_tokens[index]
                else:
                    item = top_logprobs[index]
                    if type(item) is not dict or len(item) != 1:
                        supported = False
                        break
                    value = item.get(token)
                    if type(value) is not Logprob:
                        supported = False
                        break
                    logprob, word = value.logprob, value.decoded_token
                if type(word) is not str or type(logprob) is not float:
                    supported = False
                    break
                value = max(logprob, -9999.0)
                offsets.append(offset)
                selected.append(value)
                words.append(word)
                top.append({word: value})
                offset += len(word)
            if supported:
                result = CompletionLogProbs(text_offset=offsets, token_logprobs=selected,
                                           tokens=words, top_logprobs=top)
                _COUNTS['fast'] += 1
                _COUNTS['tokens'] += n
                _COUNTS['compute_ns'] += time.perf_counter_ns() - started
                return result
        _COUNTS['fallback'] += 1
        result = native(self, token_ids, top_logprobs, num_output_top_logprobs, tokenizer,
                        logprob_token_ids, initial_text_offset, return_as_token_id)
        _COUNTS['compute_ns'] += time.perf_counter_ns() - started
        return result

    OpenAIServingCompletion._create_completion_logprobs = create
    _INSTALLED = True
    return stats()


def toggle(enabled):
    global _ENABLED
    _ENABLED = enabled
    return stats()


def stats():
    return dict(pid=os.getpid(), installed=_INSTALLED, enabled=_ENABLED,
                counts=dict(_COUNTS), native_sha256=_NATIVE_SHA,
                boundary='Only decoded one-entry native list/FlatLogprobs with logprobs0/no placeholder/no custom token lookup. Native full OpenAI model fields retained; all other paths native.')
