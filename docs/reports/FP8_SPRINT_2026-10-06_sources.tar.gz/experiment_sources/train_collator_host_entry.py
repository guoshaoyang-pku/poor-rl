"""Install exact collator tensorization before the frozen host-observed entry."""
import ast
import hashlib
import json
import os
from pathlib import Path


def main():
    if os.environ.get('SCALE_TRAIN_CHILD') == '1':
        import collator_tensorize_prototype as collator
        collator.install()
        print(json.dumps(dict(collator_tensorize=dict(event='installed', rank=int(os.environ.get('RANK', '0')),
              source_sha256=hashlib.sha256(Path(collator.__file__).read_bytes()).hexdigest(),
              entry_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))), flush=True)
    path = Path(__file__).with_name('train_host_observed_entry.py')
    namespace = dict(__name__='__main__', __file__=str(Path(__file__)),
                     __package__=None, __builtins__=__builtins__)
    exec(compile(ast.parse(path.read_text()), str(path), 'exec'), namespace)


if __name__ == '__main__':
    main()
