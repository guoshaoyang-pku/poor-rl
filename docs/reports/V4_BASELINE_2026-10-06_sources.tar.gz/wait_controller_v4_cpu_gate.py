"""Exercise adaptive admission against the frozen native TRL generation method."""
import ast
import asyncio
from collections import defaultdict, deque
import hashlib
import inspect
import json
import os
from pathlib import Path
import queue
import sys
import tempfile
from types import SimpleNamespace

SPRINT = Path(__file__).resolve().parent.parent / 'fp8_sprint_20261005'
sys.path.insert(0, str(SPRINT))
import rollout_group_flow_prototype as flow
import wait_controller_v4 as control


def native_source():
    path = SPRINT / 'native_pipeline_source_snapshot' / 'trl_experimental_async_grpo_async_rollout_worker.py'
    source = path.read_text()
    tree = ast.parse(source)
    method = next(n for c in tree.body if isinstance(c, ast.ClassDef) and c.name == '_AsyncRolloutLoop'
        for n in c.body if isinstance(n, ast.AsyncFunctionDef) and n.name == '_generate_loop')
    result = ''.join(source.splitlines(keepends=True)[method.lineno - 1:method.end_lineno])
    assert hashlib.sha256(result.encode()).hexdigest().startswith(flow.NATIVE_HASH_PREFIX)
    return result


def controller_checks():
    config = control.bounds(32, 128, 6144, 352, 3)
    previous = dict(request_groups=128, inventory_groups=256)
    def choose(step=3, step_s=60, wait_s=10, queue_samples=0, stale_mean=1, dropped_samples=0):
        return control.decision(config, previous, step=step, step_s=step_s, wait_s=wait_s,
            queue_samples=queue_samples, stale_mean=stale_mean, dropped_samples=dropped_samples)
    assert choose(step=2)['reason'] == 'warmup'
    supply = choose()
    assert (supply['request_groups'], supply['inventory_groups']) == (144, 288)
    assert choose(dropped_samples=256)['reason'] == 'reduce_inventory_for_freshness'
    assert choose(wait_s=0, queue_samples=4096)['reason'] == 'reduce_supply_for_backlog'
    assert choose(wait_s=4, queue_samples=2048)['reason'] == 'hold'
    state = previous
    for _ in range(100):
        state = control.decision(config, state, step=3, step_s=60, wait_s=30,
            queue_samples=0, stale_mean=0, dropped_samples=0)
    assert state['request_groups'] == config['maximum_requests']
    assert state['inventory_groups'] == config['maximum_inventory']
    for _ in range(100):
        state = control.decision(config, state, step=4, step_s=60, wait_s=0,
            queue_samples=4096, stale_mean=0, dropped_samples=0)
    assert state['request_groups'] == config['minimum_requests']
    assert state['inventory_groups'] == config['minimum_inventory']
    predicate = '(dispatched_samples % self.num_generations != 0 or (count < cap and active < limit))'
    assert eval(predicate, {}, dict(dispatched_samples=1, self=SimpleNamespace(num_generations=32),
                                   count=99, cap=2, active=99, limit=32))
    assert not eval(predicate, {}, dict(dispatched_samples=32, self=SimpleNamespace(num_generations=32),
                                       count=99, cap=2, active=99, limit=32))
    return config


def trainer_hook_checks(output):
    path = SPRINT / 'native_pipeline_source_snapshot' / 'trl_experimental_async_grpo_async_grpo_trainer.py'
    tree = ast.parse(path.read_text())
    method = next(n for c in tree.body if isinstance(c, ast.ClassDef) and c.name == 'AsyncGRPOTrainer'
        for n in c.body if isinstance(n, ast.FunctionDef) and n.name == '_log_step_metrics')
    namespace = dict(time=SimpleNamespace(perf_counter=lambda: 60.0))
    exec(compile(ast.Module(body=[method], type_ignores=[]), str(path), 'exec'), namespace)
    cls = type('AsyncGRPOTrainer', (), dict(_log_step_metrics=namespace['_log_step_metrics']))
    module_name = 'trl.experimental.async_grpo'
    saved = sys.modules.get(module_name)
    sys.modules[module_name] = SimpleNamespace(async_grpo_trainer=SimpleNamespace(AsyncGRPOTrainer=cls))
    os.environ.update(NREF_WAIT_CONTROL='1', SPRINT_GROUP_CAP='352', SCALE_OUT=str(output))
    try:
        control.install_trainer()
        def fixture(main=True):
            trainer = cls()
            trainer.accelerator = SimpleNamespace(is_main_process=main, num_processes=4)
            trainer.rollout_worker = SimpleNamespace(rollout_buffer=queue.Queue())
            trainer.args = SimpleNamespace(num_generations=32, per_device_train_batch_size=1024,
                gradient_accumulation_steps=1, max_inflight_tasks=6144, max_staleness=3)
            trainer.model_version = 3
            trainer.state = SimpleNamespace(global_step=3)
            trainer._metrics = {'train': defaultdict(list)}
            trainer._metrics['train']['sample/dropped_stale_total'] = [1.0] * 256
            trainer._metrics['train']['sample/staleness_mean'] = [2.9] * 4096
            trainer._current_train_step_time = 40
            trainer._last_step_end_time = 0
            trainer._step_forward_s = 20
            trainer._step_optimizer_s = .01
            trainer._step_microbatches = 1
            trainer._step_forward_tokens = 0
            trainer._step_trained_tokens = 1000
            trainer._step_samples = 4096
            trainer._rollout_dataset = SimpleNamespace(wait_s=10)
            trainer._trained_groups = set(range(128))
            trainer._last_groups_trained = 0
            trainer._step_seq_len_weighted = 0
            return trainer
        rank0 = fixture()
        rank0._log_step_metrics()
        first = json.loads((output / 'wait_admission.json').read_text())
        assert first['inventory_groups'] == 308 and first['request_groups'] == 192
        assert first['drop_fraction'] == 256 / (256 + 4096)
        assert rank0._metrics['train']['batch/samples_per_step'] == [4096]
        assert rank0._metrics['train']['perf/rollout_wait_s'] == [10]
        assert rank0._rollout_dataset.wait_s == 0
        assert rank0._current_train_step_time == rank0._step_forward_tokens == rank0._step_trained_tokens == 0
        rank0.state.global_step = 4
        rank0.model_version = 4
        rank0._last_step_end_time = 0
        rank0._rollout_dataset.wait_s = 20
        rank0._log_step_metrics()
        second = json.loads((output / 'wait_admission.json').read_text())
        assert second['drop_fraction'] == 0
        assert second['reason'] == 'increase_supply_for_wait'
        before = (output / 'wait_admission.json').read_bytes()
        rank1 = fixture(main=False)
        rank1._log_step_metrics()
        assert (output / 'wait_admission.json').read_bytes() == before
        rank0._metrics['train'].clear()
        rank0._metrics['train']['sample/dropped_stale_total'] = [1.0] * 128
        rank0._metrics['train']['sample/staleness_mean'] = [1.0] * 4096
        rank0.state.global_step = rank0.model_version = 5
        rank0._last_step_end_time = 0
        rank0._rollout_dataset.wait_s = 20
        rank0._log_step_metrics()
        third = json.loads((output / 'wait_admission.json').read_text())
        assert third['drop_fraction'] == 128 / (128 + 4096)
        assert third['reason'] == 'reduce_inventory_for_freshness'
        return dict(actual_native_step_metrics_exercised=True, rank0_only=True,
            step_local_drop_deltas=True, log_flush_resets_offsets=True, native_step_counters_preserved=True)
    finally:
        if saved is None:
            del sys.modules[module_name]
        else:
            sys.modules[module_name] = saved


def rollout_install_checks(source):
    namespace = dict(asyncio=asyncio, time=__import__('time'), inspect=inspect,
        __file__=str(SPRINT / 'native_pipeline_source_snapshot' / 'trl_experimental_async_grpo_async_rollout_worker.py'),
        RolloutGroup=SimpleNamespace, poor_rl_deque=deque, poor_rl_inventory=flow.inventory,
        poor_rl_observe=flow.observe)
    exec(compile(flow.transform(source, 352), flow.__file__, 'exec'), namespace)
    original = namespace['_generate_loop']
    cls = type('_AsyncRolloutLoop', (), dict(_generate_loop=original, _poor_rl_group_flow_installed=True))
    module_name = 'trl.experimental.async_grpo'
    saved = sys.modules.get(module_name)
    sys.modules[module_name] = SimpleNamespace(async_rollout_worker=SimpleNamespace(_AsyncRolloutLoop=cls))
    os.environ.update(NREF_WAIT_CONTROL='1', SPRINT_GROUP_CAP='352')
    try:
        metadata = control.install_rollout()
        assert metadata['phase'] == 'after_group_flow_install'
        assert cls._generate_loop is not original
        assert namespace['poor_rl_observe'] is flow.observe
        assert namespace['poor_rl_inventory'] is flow.inventory
        assert namespace['poor_rl_deque'] is deque
        try:
            control.install_rollout()
        except ValueError:
            pass
        else:
            raise AssertionError('Duplicate install accepted')
        return dict(install_after_flow=True, frozen_bytecode_guard=True,
                    frozen_function_namespace_unchanged=True, double_install_rejected=True)
    finally:
        if saved is None:
            del sys.modules[module_name]
        else:
            sys.modules[module_name] = saved


async def exercise(source, output):
    namespace = dict(asyncio=asyncio, time=__import__('time'), inspect=inspect,
        RolloutGroup=SimpleNamespace, poor_rl_deque=deque, poor_rl_inventory=flow.inventory,
        poor_rl_observe=lambda loop, pending, ready, count: control.observe_control(
            loop, pending, ready, count, flow.observe))
    tree = control.transform_flow(flow.transform(source, 8))
    unchanged = flow.transform(source, 8)
    outer = next(n for n in unchanged.body[0].body if isinstance(n, ast.Try)).body[0]
    refill = next(n for n in outer.body if isinstance(n, ast.While) and ast.unparse(n.test).startswith('free_slots and'))
    outer_changed = next(n for n in tree.body[0].body if isinstance(n, ast.Try)).body[0]
    refill_changed = next(n for n in outer_changed.body if isinstance(n, ast.While) and ast.unparse(n.test).startswith('free_slots and'))
    refill.test = refill_changed.test
    assert ast.dump(unchanged, include_attributes=False) == ast.dump(tree, include_attributes=False)
    exec(compile(tree, flow.__file__, 'exec'), namespace)
    stop = asyncio.Event()
    loop = SimpleNamespace(max_inflight_tasks=64, num_generations=32, model_version=10,
        _groups_to_score=asyncio.Queue(maxsize=1), _score_tasks=set(), rollout_buffer=queue.Queue(maxsize=64),
        _heartbeat_value=SimpleNamespace(value=0), _multi_environment=False, environment_factories=None,
        tools=[], _standalone_tools=[], _env_reward_types=[], _total_completion_tokens=0, metrics=[],
        dispatches=[], completed=[], consumed=[], active=0, peak_active=0)
    loop._push_metrics = loop.metrics.append
    row = dict(prompt=[dict(role='user', content='synthetic')], label=7)
    def iterator():
        group = 0
        while True:
            for _ in range(32):
                yield group, row
            group += 1
    loop._repeat_iterator = iterator
    async def generate(prompt, tool_dict, tools, group_id):
        index = sum(group == group_id for group in loop.dispatches)
        loop.dispatches.append(group_id)
        loop.active += 1
        loop.peak_active = max(loop.peak_active, loop.active)
        await asyncio.sleep(.04 if index == 31 else .006)
        loop.active -= 1
        return dict(group=group_id, index=index), [group_id, index, 5], [], 0, 0, None
    loop._generate_one = generate
    async def score(group):
        await asyncio.sleep(.015)
        assert len(group.completions) == 32 and len(group.completions_ids) == 32
        assert group.reward_kwargs['label'] == [7] * 32
        assert sorted(ids[1] for ids in group.completions_ids) == list(range(32))
        for ids in group.completions_ids:
            while loop.rollout_buffer.full():
                await asyncio.sleep(.001)
            loop.rollout_buffer.put_nowait(ids)
        loop.completed.append(group.group_id)
    async def scorer():
        while not stop.is_set():
            if len(loop._score_tasks) >= 2:
                await asyncio.wait(loop._score_tasks, return_when=asyncio.FIRST_COMPLETED)
                continue
            group = await loop._groups_to_score.get()
            if group is None:
                return
            task = asyncio.create_task(score(group))
            loop._score_tasks.add(task)
            task.add_done_callback(loop._score_tasks.discard)
    async def consume():
        while len(loop.consumed) < 64 * 32:
            try:
                loop.consumed.append(loop.rollout_buffer.get_nowait())
            except queue.Empty:
                await asyncio.sleep(.001)
            await asyncio.sleep(.0002)
        stop.set()
    async def feedback():
        for step, request_groups, inventory_groups in [(3, 1, 2), (4, 2, 4), (5, 1, 2)]:
            await asyncio.sleep(.3)
            control.atomic_state(output / 'wait_admission.json', dict(schema=1, global_step=step,
                policy_version=10, group_size=32, request_groups=request_groups,
                inventory_groups=inventory_groups, reason='synthetic_gate',
                limits=dict(request_groups=[1, 2], inventory_groups=[2, 8])))
    gen = asyncio.create_task(namespace['_generate_loop'](loop, stop))
    score_task = asyncio.create_task(scorer())
    consumer = asyncio.create_task(consume())
    feed = asyncio.create_task(feedback())
    await asyncio.wait_for(consumer, timeout=8)
    await asyncio.wait_for(gen, timeout=1)
    await feed
    score_task.cancel()
    await asyncio.gather(score_task, return_exceptions=True)
    for task in loop._score_tasks:
        task.cancel()
    await asyncio.gather(*loop._score_tasks, return_exceptions=True)
    assert loop.peak_active <= 64
    assert len(set(loop.completed)) == len(loop.completed)
    assert len(loop.dispatches) % 32 == 0
    assert loop._poor_rl_group_flow['applied_control_step'] == 5
    assert loop._poor_rl_group_flow['request_limit'] == 32
    assert loop._poor_rl_group_flow['cap_groups'] == 2
    grouped = defaultdict(list)
    for ids in loop.consumed:
        grouped[ids[0]].append(ids[1])
    assert all(sorted(indices) == list(range(32)) for indices in grouped.values())
    return dict(completed_groups=len(loop.completed), consumed_groups=len(grouped),
        peak_native_requests=loop.peak_active, final_control_step=5,
        applied=json.loads('[' + ','.join((output / 'wait_admission_applied.jsonl').read_text().splitlines()) + ']'))


def main():
    source = native_source()
    config = controller_checks()
    rollout_install = rollout_install_checks(source)
    with tempfile.TemporaryDirectory(prefix='poorrl-wait-cpu-') as temporary:
        output = Path(temporary)
        os.environ['SCALE_OUT'] = str(output)
        result = asyncio.run(exercise(source, output))
        hook = trainer_hook_checks(output)
    report = dict(pass_all=True, scope='CPU synthetic native generation replay, no torch/CUDA/HTTP imported',
        controller=config, exercise=result, trainer_hook=hook, rollout_install=rollout_install,
        native_sha256=hashlib.sha256(source.encode()).hexdigest(),
        prototype_sha256=hashlib.sha256(Path(control.__file__).read_bytes()).hexdigest(),
        unchanged_G32_scoring_staleness=True, dynamic_refill_only=True,
        throughput_or_learning_equivalence_measured=False)
    Path(__file__).with_suffix('.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
