"""Launch one bounded beta-zero arm from the recorded fastest recipe."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import urllib.request

parser = argparse.ArgumentParser()
parser.add_argument('--rollout-dp', type=int, choices=[4, 6], required=True)
parser.add_argument('--steps', type=int, default=6)
parser.add_argument('--suffix', default='static')
parser.add_argument('--eps-low', type=float, default=0.004)
parser.add_argument('--eps-high', type=float, default=0.004)
parser.add_argument('--adaptive', action='store_true')
parser.add_argument('--clip-sweep', action='store_true')
args = parser.parse_args()
root = Path('/data/shared/guoshaoyang/aiq_rl_store/noref_baseline_20261006')
frozen = root.parent / 'fp8_sprint_20261005'
previous = json.loads((frozen /
    'fp8_convsilu_bw_refv5_mb1024gas1_dp4_samplecachef32ssm352_judgev4_v1_driver_launch.json').read_text())
for name, expected in previous['source_sha256'].items():
    assert hashlib.sha256((frozen / name).read_bytes()).hexdigest() == expected, name
preflight = subprocess.check_output(['nvidia-smi',
    '--query-gpu=index,memory.used,ecc.errors.uncorrected.volatile.total',
    '--format=csv,noheader,nounits'], text=True)
for row in preflight.strip().splitlines():
    gpu, memory, ecc = map(int, row.split(','))
    assert 0 <= gpu <= 7 and memory <= 16 and ecc == 0, row
with urllib.request.urlopen('http://127.0.0.1:3134/health', timeout=8) as response:
    judge = json.load(response)
assert judge['inflight'] == 0 and judge['detached_workers'] == 0
environment = dict(previous['environment'])
for key in ['RLFORGE_REFERENCE_ENDPOINTS', 'RLFORGE_REFERENCE_MODE',
            'RLFORGE_REF_MODEL', 'SPRINT_REFERENCE_PLAN_REUSE']:
    environment.pop(key, None)
environment.update(NREF_FROZEN_ROOT=str(frozen), NREF_ROOT=str(root),
    SPRINT_STEPS=str(args.steps), SPRINT_ROLLOUT_DP=str(args.rollout_dp),
    SPRINT_TRAIN_ENTRY='train_noref_entry.py',
    SPRINT_REMOTE_ROLLOUT_GPUS='5,6' if args.rollout_dp == 6 else '',
    NREF_RPC_PORT='13449' if args.rollout_dp == 6 else '13439', NREF_SUFFIX=args.suffix, NREF_EPS_LOW=str(args.eps_low),
    NREF_EPS_HIGH=str(args.eps_high),
    NREF_WAIT_CONTROL='1' if args.adaptive else '0',
    NREF_CLIP_SWEEP='1' if args.clip_sweep else '0',
    SCALE_SUFFIX=f'_noref_dp{args.rollout_dp}_{args.suffix}')
name = f'v4_noref_dp{args.rollout_dp}_{args.suffix}'
output = root / 'e2e' / name
owner = root / (name + '.owner.json')
assert not owner.exists() and not output.exists(), name
command = ['timeout', '--signal=TERM', '--kill-after=30', '1200',
           'bash', str(root / 'run_noref_e2e.sh'), 'fp8']
with (root / (name + '.driver.log')).open('xb') as stream:
    child = subprocess.Popen(command, cwd=frozen, env=dict(os.environ, **environment),
        stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
record = dict(pid=child.pid, pgid=child.pid, owner='/root', node='360-2',
    started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    command=command, environment=environment, gpu_preflight=preflight, judge_before=judge,
    rollout_dp=args.rollout_dp, beta=0, physical_h200=4+args.rollout_dp,
    source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest()
                   for pattern in ['*.py', '*.sh'] for p in root.glob(pattern)},
    frozen_sources_verified=True, preregistered_primary=[4,6],
    comparison='GSPO and rewards retained, no KL reference; fixed G32 MB1024/rank GAS1 global4096.')
owner.write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(dict(name=name,pid=child.pid,pgid=child.pid)), flush=True)
