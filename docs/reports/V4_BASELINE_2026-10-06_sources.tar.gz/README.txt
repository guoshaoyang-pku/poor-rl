V4 beta=0 experiment support files, 2026-10-06.
Use alongside FP8_SPRINT_2026-10-06_sources.tar.gz and its public base2d9295e.
Original policy checkpoint,data,reward,tokenizer and compatible locked runtime are required and not bundled.
The launcher shell uses experiment-specific paths; this is a recorded experiment, not the canonical poor-rl launch interface.
Compare histories using collector_v4.py with --shape-audit whole_model_mfu_shape_audit.json.
Sources reflect final DP6 wrapper version; old DP4 entry hashes are separately recorded in evidence.
Clip alternatives are same-batch diagnostics, not separate optimizer arms.
MFU is a policy workload-shape estimate, not measured whole-model or whole-RL MFU.
No checkpoints, question text, sampled response text, or credentials are included.
