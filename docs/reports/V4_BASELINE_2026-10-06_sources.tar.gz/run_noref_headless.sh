#!/usr/bin/env bash
set -euo pipefail
: "${ROLE:?head or headless}" "${GPUS:?explicit GPU indices}"
ROOT=${ROOT:-/data/shared/guoshaoyang/aiq_rl_store/noref_baseline_20261006/frozen}
VENV=${VENV:-/data/home/guoshaoyang/aiq_rl/venv}
MODEL=${MODEL:-/data/shared/guoshaoyang/aiq_rl_store/models/v3_1e_ckpt100_20261003}
HEAD_IP=${HEAD_IP:-10.234.161.3}
PORT=${PORT:-8039}
RPC_PORT=${RPC_PORT:-13439}
DP_TOTAL=${DP_TOTAL:-6}
DP_LOCAL=${DP_LOCAL:-4}
MAX_SEQS=${MAX_SEQS:-2048}
MAX_CAPTURE=${MAX_CAPTURE:-2048}
NAME=${NAME:-crossnode_fp8_${ROLE}}
SERVE_ENTRY=serve_sample_logprobs_cache_entry.py

test -x "$VENV/bin/python"
test -f "$MODEL/config.json"
for file in serve_kv_observed_entry.py serve_driver.py serving_kv_prototype.py serving_sampler_prototype.py code/rlforge/fp8.py code/rlforge/fp8_serving.py; do
    test -f "$ROOT/$file"
done
MY_IP=$(ip -4 -o addr show bond4 | awk '{print $4}' | cut -d/ -f1)
test -n "$MY_IP"
export VLLM_HOST_IP=$MY_IP NCCL_SOCKET_IFNAME=bond4 GLOO_SOCKET_IFNAME=bond4
export NCCL_IB_HCA=${NCCL_IB_HCA:-^mlx5_bond_0}
export VLLM_USE_FLASHINFER_SAMPLER=0 VLLM_ALLREDUCE_USE_FLASHINFER=0 VLLM_SERVER_DEV_MODE=1
export VLLM_HTTP_TIMEOUT_KEEP_ALIVE=3600
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 OMP_NUM_THREADS=1
export CUDA_VISIBLE_DEVICES=$GPUS
export PYTHONPATH=$ROOT:$ROOT/code:${PYTHONPATH:-}
export SPRINT_BULK_DECODE=1 SPRINT_SAMPLE_LOGPROBS_CACHE=1 SPRINT_SSM_DTYPE=float32
export SPRINT_SERVE_KV=1 RLFORGE_SPRINT_KV=1
unset RLFORGE_SPRINT_SAMPLER
export TMPDIR=${TMPDIR:-/data/shared/guoshaoyang/x8dp_${ROLE}}
export VLLM_CACHE_DIR=${VLLM_CACHE_DIR:-/data/home/guoshaoyang/aiq_rl/tmp/vllm}
mkdir -p "$TMPDIR"

COMMAND=("$VENV/bin/python" "$ROOT/$SERVE_ENTRY" serve "$MODEL"
    --served-model-name "$MODEL" --dtype bfloat16 --tensor-parallel-size 1
    --quantization poor_rl_fp8 --kv-cache-dtype auto --mamba-ssm-cache-dtype float32
    --max-model-len 24576 --gpu-memory-utilization "${UTIL:-0.85}"
    --max-num-seqs "$MAX_SEQS" --max-num-batched-tokens 32768
    --max-cudagraph-capture-size "$MAX_CAPTURE" --async-scheduling --enable-prefix-caching
    --worker-extension-cls serving_sampler_prototype.StatsWorker
    --additional-config '{"gdn_prefill_backend":"triton"}'
    --weight-transfer-config '{"backend":"nccl"}'
    --data-parallel-size "$DP_TOTAL" --data-parallel-size-local "$DP_LOCAL"
    --data-parallel-address "$HEAD_IP" --data-parallel-rpc-port "$RPC_PORT")
case "$ROLE" in
    head)
        test "$MY_IP" = "$HEAD_IP"
        COMMAND+=(--host 0.0.0.0 --port "$PORT" --api-server-count "${API_SERVERS:-$DP_TOTAL}")
        ;;
    headless)
        : "${START_RANK:?first remote DP rank}"
        COMMAND+=(--headless --data-parallel-start-rank "$START_RANK")
        ;;
    *) echo 'ROLE must be head or headless' >&2; exit 2 ;;
esac
if [ "${DRY_RUN:-0}" = 1 ]; then
    printf '%q ' "${COMMAND[@]}"
    printf '\n'
    exit 0
fi
export FP8_LAUNCH_ROOT=$ROOT FP8_LAUNCH_NAME=$NAME FP8_LAUNCH_MODEL=$MODEL FP8_LAUNCH_ROLE=$ROLE
"$VENV/bin/python" - "${COMMAND[@]}" <<'PY'
import datetime
import hashlib
import json
import os
import socket
import sys
from pathlib import Path
root = Path(os.environ['FP8_LAUNCH_ROOT'])
name = os.environ['FP8_LAUNCH_NAME']
manifest = root / (name + '_launch.json')
if manifest.exists():
    raise FileExistsError(manifest)
files = [os.environ.get('SPRINT_SERVE_ENTRY','serve_kv_observed_entry.py'), 'serve_driver.py', 'serving_kv_prototype.py',
         'serving_sampler_prototype.py', 'code/rlforge/fp8.py', 'code/rlforge/fp8_serving.py']
files.extend(name for name in ['serving_pause_observer.py', 'serve_kv_bandwidth_entry.py', 'kv_bandwidth_worker.py'] if (root/name).exists())
state = dict(host=socket.gethostname(), role=os.environ['FP8_LAUNCH_ROLE'],
             started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             pid=os.getppid(), pgid=os.getpgid(os.getppid()), command=sys.argv[1:],
             model=os.environ['FP8_LAUNCH_MODEL'],
             source_sha256={p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in files},
             environment={k: os.environ.get(k) for k in ['CUDA_VISIBLE_DEVICES', 'VLLM_HOST_IP',
                 'NCCL_SOCKET_IFNAME', 'GLOO_SOCKET_IFNAME', 'NCCL_IB_HCA', 'TMPDIR',
                 'VLLM_HTTP_TIMEOUT_KEEP_ALIVE']},
             precision='FP8 PTPC GEMM, BF16 attention KV, FP32 recurrent state; native sampler',
             checkpoint_boundary='Full tensor hashes require matching crossnode_input_hashes.json',
             owner=os.environ.get('FP8_OWNER', '/root'))
manifest.write_text(json.dumps(state, indent=2))
(root / (name + '.pid')).write_text(str(state['pid']) + '\n')
(root / (name + '.pgid')).write_text(str(state['pgid']) + '\n')
print(json.dumps(state), flush=True)
PY
exec "${COMMAND[@]}"
