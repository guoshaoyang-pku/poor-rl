"""Bound the no-update v4 numerical gate on one explicitly reserved H200."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/data/shared/guoshaoyang/aiq_rl_store/noref_baseline_20261006')
gpu = os.environ.get('NREF_GATE_GPU', '5')
state = subprocess.check_output(['nvidia-smi', '-i', gpu,
    '--query-gpu=uuid,memory.used,ecc.errors.uncorrected.volatile.total',
    '--format=csv,noheader,nounits'], text=True).strip()
uuid, memory, ecc = [v.strip() for v in state.split(',')]
assert int(memory) <= 16 and int(ecc) == 0, state
python = '/data/home/guoshaoyang/aiq_rl/venv/bin/python'
environment = dict(os.environ, CUDA_VISIBLE_DEVICES=gpu, PYTHONUNBUFFERED='1',
    PYTHONPATH=str(root) + ':' + str(root/'frozen'/'code') + ':' + str(root/'frozen'),
    HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', OMP_NUM_THREADS='1',
    LOCAL_KERNELS='kernels-community/flash-attn3=/data/home/guoshaoyang/aiq_rl/flash_attn3_local',
    RLFORGE_FAST_LOGPROB='1', RLFORGE_FP8_ALIGN_COMPILE='1',
    RLFORGE_FP8_ALIGN_POINTWISE='1', RLFORGE_FP8_ALIGN_BACKWARD='1',
    RLFORGE_LOGPROB_BWD='tf32', RLFORGE_FP8_GRAPHS='0', RLFORGE_FP8_HEAD_GRAPH='0',
    VLLM_USE_FLASHINFER_SAMPLER='0', VLLM_DISABLE_COMPILE_CACHE='1',
    TMPDIR='/data/shared/guoshaoyang/aiq_rl_store/gn6',
    TORCHINDUCTOR_CACHE_DIR=str(root/'cache'/'gate_inductor'),
    TRITON_CACHE_DIR=str(root/'cache'/'gate_triton'),
    VLLM_CACHE_ROOT=str(root/'cache'/'gate_serving'),
    NCCL_SOCKET_IFNAME='bond4', GLOO_SOCKET_IFNAME='bond4', VLLM_HOST_IP='10.234.161.2')
for name in ['TMPDIR', 'TORCHINDUCTOR_CACHE_DIR', 'TRITON_CACHE_DIR', 'VLLM_CACHE_ROOT']:
    Path(environment[name]).mkdir(parents=True, exist_ok=True)
owner = root/'v4_policy_gate.owner.json'
assert not owner.exists()
record = dict(owner='/root', pid=os.getpid(), pgid=os.getpgrp(), node='360-1', gpu=int(gpu), uuid=uuid,
    preflight=state, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source_sha256=hashlib.sha256((root/'v4_policy_gate.py').read_bytes()).hexdigest(), phases=[])
owner.write_text(json.dumps(record, indent=2))
for mode in ['trainer', 'serving']:
    output=root/('v4_policy_'+mode+'.json')
    assert not output.exists()
    command=[python,str(root/'v4_policy_gate.py'),'--mode',mode,'--frozen',str(root/'frozen'),
        '--cases',str(root/'within_serving_patch0.json'),'--output',str(output)]
    if mode=='serving': command.extend(['--trainer-result',str(root/'v4_policy_trainer.json')])
    with (root/('v4_policy_'+mode+'.log')).open('x') as log:
        child=subprocess.Popen(command,cwd=root,env=environment,stdout=log,stderr=subprocess.STDOUT)
        row=dict(mode=mode,pid=child.pid,command=command)
        record['phases'].append(row);owner.write_text(json.dumps(record,indent=2))
        try: row['exit_code']=child.wait(timeout=600)
        except subprocess.TimeoutExpired:
            child.terminate()
            try:child.wait(timeout=15)
            except subprocess.TimeoutExpired: child.kill();child.wait()
            row['exit_code']=child.returncode;row['deadline']=True
        owner.write_text(json.dumps(record,indent=2))
        assert row['exit_code']==0,mode
record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
owner.write_text(json.dumps(record,indent=2))
print(json.dumps(record),flush=True)
