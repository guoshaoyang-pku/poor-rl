"""Observe GSPO lower/upper threshold alternatives on identical live batches."""
import json
from pathlib import Path
import types

import torch


def install(trainer, output):
    original = trainer._loss_metrics
    rows = []
    thresholds = [(0.004, 0.004), (0.004, 0.008), (0.008, 0.004), (0.016, 0.004)]

    def metrics(self, log_ratio, entropy, advantages, completion_mask, seq_ids, num_seq,
                seq_mean_lr, rho, low_bound, kl_seq_mean):
        result = original(log_ratio, entropy, advantages, completion_mask, seq_ids, num_seq,
                          seq_mean_lr, rho, low_bound, kl_seq_mean)
        with torch.no_grad():
            valid = completion_mask[0].float()
            counts = torch.zeros(num_seq, device=valid.device).index_add_(0, seq_ids, valid)
            adv = torch.zeros_like(counts).index_add_(0, seq_ids, advantages[0] * valid)
            adv = adv / counts.clamp_min(1)
            values = []
            for low, high in thresholds:
                below, above = rho < 1-low, rho > 1+high
                actual_low, actual_high = below & (adv < 0), above & (adv > 0)
                clipped = rho.clamp(1-low, 1+high)
                surrogate = -torch.minimum(rho * adv, clipped * adv)
                values.extend([below.float().mean(), above.float().mean(),
                    actual_low.float().mean(), actual_high.float().mean(), surrogate.mean()])
            stats = torch.stack(values).detach().cpu().tolist()
            row = dict(step=int(self.state.global_step)+1,
                       rank=int(self.accelerator.process_index), num_seq=int(num_seq),
                       scope='Same live sequence ratios/advantages; diagnostic threshold sweep, training objective unchanged',
                       settings=[])
            for index, (low, high) in enumerate(thresholds):
                v = stats[5*index:5*index+5]
                row['settings'].append(dict(eps_low=low, eps_high=high,
                    seq_low_cross_fraction=v[0], seq_high_cross_fraction=v[1],
                    actual_low_gradient_clip_fraction=v[2], actual_high_gradient_clip_fraction=v[3],
                    surrogate_loss_mean=v[4]))
            rows.append(row)
        return result

    trainer._loss_metrics = types.MethodType(metrics, trainer)

    def finish():
        path = Path(output) / ('clip_sweep_rank'+str(trainer.accelerator.process_index)+'.json')
        path.write_text(json.dumps(rows, indent=2))
        trainer._loss_metrics = original

    return finish
