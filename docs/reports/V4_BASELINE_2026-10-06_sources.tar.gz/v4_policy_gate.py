"""Same-token, no-update gate for the frozen v4 trainer and native FP8 serving."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys

import torch
from vllm.v1.sample.logits_processor import AdapterLogitsProcessor


class FixedTokenProcessor(AdapterLogitsProcessor):
    @classmethod
    def validate_params(cls, params):
        tokens = (params.extra_args or {}).get('v4_fixed_tokens')
        if tokens is not None:
            assert tokens and all(type(t) is int and t >= 0 for t in tokens)

    def is_argmax_invariant(self):
        return False

    def new_req_logits_processor(self, params):
        tokens = (params.extra_args or {}).get('v4_fixed_tokens')
        if tokens is None:
            return None

        def force(output_ids, logits):
            token = tokens[len(output_ids)]
            logits.fill_(float('-inf'))
            logits[token] = 0
            return logits
        return force


class GateWorker:
    def v4_fingerprint(self):
        return fingerprint(self.model_runner.model)


def fingerprint(model):
    digest = hashlib.sha256()
    for name, value in sorted(model.state_dict().items()):
        digest.update(name.encode())
        digest.update(value.detach().contiguous().reshape(-1).view(torch.uint8).cpu().numpy().tobytes())
    return digest.hexdigest()

def summarize(a, b):
    delta = torch.tensor(a, dtype=torch.float64) - torch.tensor(b, dtype=torch.float64)
    assert torch.isfinite(delta).all()
    absolute = delta.abs()
    return dict(signed_mean=float(delta.mean()), mean_abs=float(absolute.mean()),
                p50_abs=float(absolute.quantile(.5)), p90_abs=float(absolute.quantile(.9)),
                max_abs=float(absolute.max()))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=['trainer', 'serving'], required=True)
    parser.add_argument('--frozen', type=Path, required=True)
    parser.add_argument('--cases', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--trainer-result', type=Path)
    args = parser.parse_args()
    assert not args.output.exists()
    assert len(os.environ['CUDA_VISIBLE_DEVICES'].split(',')) == 1
    sys.path[:0] = [str(args.frozen / 'code'), str(args.frozen)]
    import torch

    torch.set_num_threads(1)
    MODEL = '/data/shared/guoshaoyang/aiq_rl_store/models/v3_1e_ckpt100_20261003'
    saved = next(c for c in json.loads(args.cases.read_text())['cases']
                 if c['case'] == 0 and c['max_tokens'] == 128)
    full = saved['token_ids']
    prompt_length = saved['prompt_tokens']
    completion = full[prompt_length:]
    sources = {str(p.relative_to(args.frozen / 'code')):
               hashlib.sha256(p.read_bytes()).hexdigest()
               for p in (args.frozen / 'code' / 'rlforge').rglob('*.py')}
    result = dict(model=MODEL, case=0, completion_tokens=len(completion),
                  token_ids_sha256=hashlib.sha256(json.dumps(full).encode()).hexdigest(),
                  checkpoint_sha256=hashlib.sha256((Path(MODEL) / 'model.safetensors').read_bytes()).hexdigest(),
                  source_sha256=sources, threshold=0.004, update_count=0,
                  scope='Frozen v4 FP8 policy forward; same checkpoint/tokens, no optimizer or policy lag; one diagnostic case')

    if args.mode == 'trainer':
        import v32_gate as gate
        from rlforge import fp8, fp8_alignment
        import branch_conv_silu_packed_backward_prototype as fusion
        gate.CK = MODEL
        model, reference = gate.load_models(with_ref=False)
        assert reference is None
        fp8.install(model)
        fp8_alignment.install(model, gdn=True)
        fusion.install_for_benchmark(model)
        model.lm_head.weight._rlforge_fp8_head = True
        assert all(p.dtype == torch.float32 for p in model.parameters())
        before = fingerprint(model)
        inputs = gate.make_inputs([(full[:prompt_length], completion)], seed=19)
        with torch.no_grad():
            lp = gate.subbatch_lp(model, inputs, 65536)
        values = lp[inputs['completion_mask'][:, 1:].bool()].float().cpu().tolist()
        assert len(values) == len(completion)
        assert before == fingerprint(model)
        result.update(trainer_logprobs=values, master_dtype='FP32', masters_unchanged=True,
                      master_sha256=before, reference_model_absent=True)
    else:
        assert args.trainer_result
        trained = json.loads(args.trainer_result.read_text())
        for key in ['token_ids_sha256', 'checkpoint_sha256', 'source_sha256']:
            assert trained[key] == result[key], key
        import serve_driver
        from vllm import LLM, SamplingParams
        options = dict(dtype='bfloat16', quantization='poor_rl_fp8', tensor_parallel_size=1,
                       gpu_memory_utilization=.45, max_model_len=8192, max_num_seqs=4,
                       max_num_batched_tokens=8192, enable_chunked_prefill=False,
                       enforce_eager=False, kv_cache_dtype='auto', mamba_ssm_cache_dtype='float32',
                       enable_prefix_caching=False, logprobs_mode='raw_logprobs', async_scheduling=False,
                       additional_config={'gdn_prefill_backend': 'triton'},
                       logits_processors=['v4_policy_gate:FixedTokenProcessor'],
                       worker_extension_cls='v4_policy_gate.GateWorker')
        engine = LLM(model=MODEL, **options)
        before = engine.collective_rpc('v4_fingerprint')
        generated = engine.generate([{'prompt_token_ids': full[:prompt_length]}],
            SamplingParams(temperature=0, max_tokens=len(completion), ignore_eos=True,
                           logprobs=1, seed=0, detokenize=False,
                           extra_args={'v4_fixed_tokens': completion}), use_tqdm=False)[0].outputs[0]
        assert list(generated.token_ids) == completion
        decode = [float(lp[token].logprob) for token, lp in zip(completion, generated.logprobs)]
        scored = engine.generate([{'prompt_token_ids': full}],
            SamplingParams(temperature=0, max_tokens=1, prompt_logprobs=1,
                           seed=0, detokenize=False), use_tqdm=False)[0]
        prefill = [float(scored.prompt_logprobs[i][full[i]].logprob)
                   for i in range(prompt_length, len(full))]
        after = engine.collective_rpc('v4_fingerprint')
        assert before == after
        differences = dict(trainer_minus_decode=summarize(trained['trainer_logprobs'], decode),
                           trainer_minus_prefill=summarize(trained['trainer_logprobs'], prefill),
                           prefill_minus_decode=summarize(prefill, decode))
        result.update(trainer_logprobs=trained['trainer_logprobs'], prefill_logprobs=prefill,
                      decode_logprobs=decode, differences=differences, serving_weights_unchanged=True,
                      serving_fingerprints=before, settings=options,
                      all_mean_gates_pass=all(abs(d['signed_mean']) < .004 for d in differences.values()),
                      all_p90_gates_pass=all(d['p90_abs'] < .004 for d in differences.values()))
    args.output.write_text(json.dumps(result, indent=2))
    print(json.dumps({k: v for k, v in result.items() if 'logprobs' not in k and k != 'source_sha256'}), flush=True)


if __name__ == '__main__':
    main()
else:
    import serve_driver
