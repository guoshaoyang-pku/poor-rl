"""Optional optimizer-step feedback for the frozen whole-group rollout scheduler."""
import ast
import hashlib
import json
import math
import os
from pathlib import Path
import time

NATIVE_HASH_PREFIX = '699c7c7bfbe2b7b0'


def enabled():
    return os.environ.get('NREF_WAIT_CONTROL', '0') == '1'


def bounds(group_size, groups_per_update, max_requests, initial_inventory, max_staleness):
    if group_size < 1 or groups_per_update < 1 or max_requests < group_size:
        raise ValueError('Invalid rollout admission geometry')
    hard_requests = max_requests // group_size
    minimum_requests = min(hard_requests, max(1, groups_per_update // 2))
    minimum_inventory = min(initial_inventory, groups_per_update)
    maximum_inventory = int(os.getenv('NREF_WAIT_MAX_GROUPS',
        str(max(initial_inventory, groups_per_update * max(1, max_staleness)))))
    if not minimum_inventory <= initial_inventory <= maximum_inventory:
        raise ValueError('Invalid inventory bounds')
    initial_requests = int(os.getenv('NREF_WAIT_INITIAL_REQUEST_GROUPS', str(hard_requests)))
    if not minimum_requests <= initial_requests <= hard_requests:
        raise ValueError('Initial request groups exceed configured native slots')
    return dict(group_size=group_size, groups_per_update=groups_per_update,
        minimum_requests=minimum_requests, maximum_requests=hard_requests,
        initial_requests=initial_requests, minimum_inventory=minimum_inventory,
        maximum_inventory=maximum_inventory, initial_inventory=initial_inventory,
        max_staleness=max_staleness)


def decision(config, previous, *, step, step_s, wait_s, queue_samples, stale_mean, dropped_samples):
    request_groups = previous.get('request_groups', config['initial_requests'])
    inventory_groups = previous.get('inventory_groups', config['initial_inventory'])
    update_samples = config['groups_per_update'] * config['group_size']
    wait_fraction = wait_s / step_s if step_s and step_s > 0 else None
    queue_updates = queue_samples / update_samples
    drop_fraction = dropped_samples / (dropped_samples + update_samples)
    reason = 'hold'
    if step <= 2 or wait_fraction is None:
        reason = 'warmup'
    elif drop_fraction > .02 or (stale_mean >= .85 * config['max_staleness'] and queue_updates >= .5):
        inventory_groups = max(config['minimum_inventory'], math.floor(inventory_groups * .875))
        reason = 'reduce_inventory_for_freshness'
    elif wait_fraction > .10 and queue_updates < .5:
        request_groups = min(config['maximum_requests'], max(request_groups + 1, math.ceil(request_groups * 1.125)))
        inventory_groups = min(config['maximum_inventory'], max(inventory_groups + 1, math.ceil(inventory_groups * 1.125)))
        reason = 'increase_supply_for_wait'
    elif wait_fraction < .02 and queue_updates > .75:
        request_groups = max(config['minimum_requests'], math.floor(request_groups * .875))
        inventory_groups = max(config['minimum_inventory'], math.floor(inventory_groups * .875))
        reason = 'reduce_supply_for_backlog'
    return dict(schema=1, global_step=int(step), request_groups=request_groups,
        inventory_groups=inventory_groups, group_size=config['group_size'], reason=reason,
        wait_fraction=wait_fraction, queue_updates=queue_updates,
        drop_fraction=drop_fraction, stale_mean=stale_mean,
        limits=dict(request_groups=[config['minimum_requests'], config['maximum_requests']],
                    inventory_groups=[config['minimum_inventory'], config['maximum_inventory']]))


def atomic_state(path, payload):
    temporary = path.with_name(path.name + '.tmp.' + str(os.getpid()))
    temporary.write_text(json.dumps(payload) + '\n')
    os.replace(temporary, path)


def transform_flow(tree):
    method = tree.body[0]
    outer = next(n for n in method.body if isinstance(n, ast.Try)).body[0]
    refills = [n for n in outer.body if isinstance(n, ast.While)
               and isinstance(n.test, ast.BoolOp) and ast.unparse(n.test).startswith('free_slots and')]
    if len(refills) != 1:
        raise ValueError('Frozen flow refill loop changed')
    refill = refills[0]
    refill.test = ast.parse(
        'free_slots and not stop_event.is_set() and '
        '(dispatched_samples % self.num_generations != 0 or '
        '(poor_rl_inventory(self, pending_groups, ready_groups) < self._poor_rl_group_flow["cap_groups"] '
        'and len(inflight_tasks) < self._poor_rl_group_flow["request_limit"]))', mode='eval').body
    return ast.fix_missing_locations(tree)


def observe_control(loop, pending, ready, dispatched, native_observe):
    state = loop._poor_rl_group_flow
    if 'request_limit' not in state:
        group_size = loop.num_generations
        configured = int(os.environ.get('NREF_WAIT_INITIAL_REQUEST_GROUPS',
            str(loop.max_inflight_tasks // group_size)))
        if configured < 1 or configured * group_size > loop.max_inflight_tasks:
            raise ValueError('Initial admission exceeds native request slots')
        state.update(request_limit=configured * group_size, applied_control_step=-1)
    now = time.monotonic()
    if now - state.get('last_control_poll', -math.inf) >= .25:
        state['last_control_poll'] = now
        path = Path(os.environ['SCALE_OUT']) / 'wait_admission.json'
        try:
            payload = json.loads(path.read_text())
        except FileNotFoundError:
            payload = None
        if payload is not None:
            if payload['schema'] != 1 or payload['group_size'] != loop.num_generations:
                raise ValueError('Rollout control schema or group size mismatch')
            step = int(payload['global_step'])
            if step > state['applied_control_step'] and payload['policy_version'] <= loop.model_version:
                requests = int(payload['request_groups'])
                cap = int(payload['inventory_groups'])
                limits = payload['limits']
                if not (1 <= requests <= loop.max_inflight_tasks // loop.num_generations
                        and limits['request_groups'][0] <= requests <= limits['request_groups'][1]
                        and limits['inventory_groups'][0] <= cap <= limits['inventory_groups'][1]):
                    raise ValueError('Rollout control outside recorded bounds')
                state.update(request_limit=requests * loop.num_generations, cap_groups=cap,
                             applied_control_step=step, control_reason=payload['reason'])
                with (path.parent / 'wait_admission_applied.jsonl').open('a') as stream:
                    stream.write(json.dumps(dict(payload, applied_epoch=time.time(),
                        child_model_version=loop.model_version, pid=os.getpid())) + '\n')
    native_observe(loop, pending, ready, dispatched)


def install_rollout():
    """Call AFTER rollout_group_flow_prototype.install() in the spawn child."""
    if not enabled():
        return dict(enabled=False)
    import rollout_group_flow_prototype as flow
    from trl.experimental.async_grpo import async_rollout_worker as native
    cls = native._AsyncRolloutLoop
    if getattr(cls, '_poor_rl_wait_control_installed', False):
        raise ValueError('Wait controller installed twice')
    if not getattr(cls, '_poor_rl_group_flow_installed', False):
        raise ValueError('Install frozen group flow before adaptive admission')
    frozen = cls._generate_loop
    namespace = frozen.__globals__
    required = ('poor_rl_inventory', 'poor_rl_deque', 'poor_rl_observe')
    if not all(key in namespace for key in required):
        raise ValueError('Frozen group flow namespace changed')
    # The transformed function is not recoverable with inspect.getsource. Recover
    # its pinned native method and compare the frozen bytecode before patching.
    source_tree = ast.parse(Path(namespace['__file__']).read_text())
    methods = [node for parent in source_tree.body if isinstance(parent, ast.ClassDef)
        and parent.name == '_AsyncRolloutLoop' for node in parent.body
        if isinstance(node, ast.AsyncFunctionDef) and node.name == '_generate_loop']
    if len(methods) != 1:
        raise ValueError('Native generation method missing')
    lines = Path(namespace['__file__']).read_text().splitlines(keepends=True)
    method = methods[0]
    source = ''.join(lines[method.lineno - 1:method.end_lineno])
    digest = hashlib.sha256(source.encode()).hexdigest()
    if not digest.startswith(NATIVE_HASH_PREFIX):
        raise ValueError('Native TRL generation source changed')
    cap = int(os.environ['SPRINT_GROUP_CAP'])
    tree = flow.transform(source, cap)
    check_namespace = dict(namespace)
    exec(compile(tree, flow.__file__, 'exec'), check_namespace)
    expected = check_namespace['_generate_loop']
    if (frozen.__code__.co_code != expected.__code__.co_code
            or frozen.__code__.co_consts != expected.__code__.co_consts
            or frozen.__code__.co_names != expected.__code__.co_names):
        raise ValueError('Unexpected modifications to frozen group scheduler')
    native_observe = namespace['poor_rl_observe']
    changed_namespace = dict(namespace, poor_rl_observe=lambda loop, pending, ready, dispatched:
        observe_control(loop, pending, ready, dispatched, native_observe))
    exec(compile(transform_flow(tree), __file__, 'exec'), changed_namespace)
    cls._generate_loop = changed_namespace['_generate_loop']
    cls._poor_rl_wait_control_installed = True
    return dict(enabled=True, phase='after_group_flow_install', native_sha256=digest,
        source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        full_group_admission=True, inflight_work_never_cancelled=True)


def install_trainer():
    """Call before constructing the trainer; only rank0 writes feedback."""
    if not enabled():
        return dict(enabled=False)
    from trl.experimental.async_grpo import async_grpo_trainer as native
    cls = native.AsyncGRPOTrainer
    if getattr(cls, '_poor_rl_wait_control_installed', False):
        raise ValueError('Trainer wait controller installed twice')
    original = cls._log_step_metrics

    def log_step(self):
        main = self.accelerator.is_main_process and self.rollout_worker is not None
        if main:
            sink = self._metrics['train']
            wait_s = self._rollout_dataset.wait_s
            drops = sink.get('sample/dropped_stale_total', [])
            stale = sink.get('sample/staleness_mean', [])
            previous_lists = getattr(self, '_poor_rl_wait_metric_offsets', {})
            def current_values(key, values):
                old, offset = previous_lists.get(key, (None, 0))
                if old is not values:
                    offset = 0
                previous_lists[key] = (values, len(values))
                return values[offset:]
            dropped_samples = sum(current_values('drops', drops))
            stale_values = current_values('stale', stale)
            stale_mean = sum(stale_values) / len(stale_values) if stale_values else 0.0
            self._poor_rl_wait_metric_offsets = previous_lists
        result = original(self)
        if not main:
            return result
        config = getattr(self, '_poor_rl_wait_config', None)
        if config is None:
            size = self.args.num_generations
            update_samples = (self.args.per_device_train_batch_size *
                self.args.gradient_accumulation_steps * self.accelerator.num_processes)
            if update_samples % size:
                raise ValueError('Optimizer update does not contain whole rollout groups')
            config = bounds(size, update_samples // size, self.args.max_inflight_tasks,
                int(os.environ['SPRINT_GROUP_CAP']), self.args.max_staleness)
            self._poor_rl_wait_config = config
        samples = self.rollout_worker.rollout_buffer.qsize()
        metrics = self._metrics['train']
        step_times = metrics.get('perf/step_s', [])
        payload = decision(config, getattr(self, '_poor_rl_wait_state', {}),
            step=self.state.global_step, step_s=step_times[-1] if step_times else None,
            wait_s=wait_s, queue_samples=samples, stale_mean=stale_mean, dropped_samples=dropped_samples)
        payload.update(policy_version=self.model_version, epoch=time.time(), pid=os.getpid(),
            queue_samples=samples, rollout_wait_s=wait_s,
            source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
        self._poor_rl_wait_state = payload
        output = Path(os.environ['SCALE_OUT'])
        atomic_state(output / 'wait_admission.json', payload)
        with (output / 'wait_admission_decisions.jsonl').open('a') as stream:
            stream.write(json.dumps(payload) + '\n')
        for key in ('request_groups', 'inventory_groups', 'wait_fraction', 'drop_fraction'):
            if payload[key] is not None:
                metrics['rollout_control/' + key].append(float(payload[key]))
        return result

    cls._log_step_metrics = log_step
    cls._poor_rl_wait_control_installed = True
    return dict(enabled=True, rank0_only=True, source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
