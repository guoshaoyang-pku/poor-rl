"""Summarize completed RL windows and a shape-scaled policy MFU estimate."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent
DEFAULT_SHAPE = ROOT.parent / 'fp8_sprint_20261005' / 'whole_model_mfu_shape_audit.json'
METRICS = [
    'reward', 'reward_std', 'frac_reward_zero_std', 'entropy', 'ratio',
    'gspo/seq_clip_low_frac', 'gspo/seq_clip_high_frac', 'gspo/log_rho_mean',
    'gspo/rho_mean', 'gspo/abs_log_rho_mean', 'gspo/abs_log_rho_p50',
    'gspo/abs_log_rho_p90', 'gspo/abs_log_rho_max', 'gspo/dyn_low_bound',
    'clip_ratio/low_mean', 'clip_ratio/high_mean', 'clip_ratio/region_mean',
    'clip_ratio/low_min', 'clip_ratio/high_max', 'sample/staleness_mean',
    'sample/staleness_max', 'sample/judged_staleness_mean',
    'sample/judged_staleness_max', 'sample/rollout_queue_size',
    'sample/time_in_queue_s', 'completions/clipped_ratio',
    'prefix_share/forward_token_frac', 'prefix_share/pad_frac',
]


def finite(value):
    return isinstance(value, (float, int)) and not isinstance(value, bool) and math.isfinite(value)


def window_rows(rows, low, high):
    selected = {}
    for row in rows:
        if not (finite(row.get('step')) and low <= row['step'] <= high
                and finite(row.get('perf/step_s')) and row['perf/step_s'] > 0
                and finite(row.get('batch/trained_tokens_per_step'))):
            continue
        step = int(row['step'])
        if step in selected:
            raise ValueError('Duplicate step with completed timing: ' + str(step))
        selected[step] = row
    return [selected[step] for step in sorted(selected)]


def exact_audit(run):
    path = run / 'drop_audit.jsonl'
    records, tail = {}, []
    if path.exists():
        for line in path.read_text().splitlines():
            row = json.loads(line)
            if row.get('type') != 'step':
                continue
            if row.get('final'):
                tail.append(dict(step=row['step'], samples=row['samples'],
                    trained_tokens=row['len']['trained']['sum'],
                    inspected_tokens=row['len']['generated']['sum'],
                    dropped_tokens=row['len']['dropped']['sum']))
                continue
            step = int(row['step'])
            if step in records:
                raise ValueError('Duplicate normal drop audit step: ' + str(step))
            records[step] = row
    return records, tail


def metric_summary(rows, key):
    values = [(row[key], row.get('batch/samples_per_step', 1)) for row in rows if finite(row.get(key))]
    if not values:
        return None
    weights = [weight if finite(weight) and weight > 0 else 1 for _, weight in values]
    average = sum(value * weight for (value, _), weight in zip(values, weights)) / sum(weights)
    return dict(sample_weighted_mean=average, min=min(value for value, _ in values),
        max=max(value for value, _ in values), per_step=[dict(step=row['step'], value=row[key])
        for row in rows if finite(row.get(key))])


def mfu_estimate(rows, shape, trainer_gpus, wall_s, compute_s):
    logical = []
    for row in rows:
        tokens = row.get('batch/forwarded_tokens_per_step')
        fraction = row.get('prefix_share/forward_token_frac')
        if not (finite(tokens) and finite(fraction) and 0 < fraction <= 1):
            return dict(estimate_available=False, reason='Missing or invalid shared-prefix token proxy')
        logical.append(tokens * fraction)
    fixture_tokens = shape['token_contract']['logical_shared_prefix_plus_branches']
    multiplier = sum(logical) / fixture_tokens
    useful = shape['useful_math_approximation']
    fp8 = useful['fp8_training_matmul_flops'] * multiplier
    bf16 = (useful['BF16_FA_training_matmul_flops']
        + useful['GDN_training_contraction_flops']
        + useful['BF16_gate_projection_training_flops']) * multiplier
    peak_fp8, peak_bf16, peak_tf32 = 1979e12, 989e12, 494.5e12
    ideal_bf16 = fp8 / peak_fp8 + bf16 / peak_bf16
    ideal_tf32 = fp8 / peak_fp8 + bf16 / peak_tf32
    return dict(estimate_available=True,
        type='workload-shape proxy, mixed-precision useful peak-equivalent; policy trainer only',
        definition='sum(useful_FLOPs_dtype/dense_peak_dtype)/(trainer_GPU_count*window_wall_s)',
        shared_prefix_token_proxy=sum(logical), fixture_tokens=fixture_tokens,
        proxy_formula='sum(batch/forwarded_tokens_per_step * prefix_share/forward_token_frac)',
        fixture_multiplier=multiplier, trainer_gpus=trainer_gpus,
        useful_fp8_flops_estimate=fp8, useful_bf16_or_tf32_flops_estimate=bf16,
        dense_peak_tflop_s=dict(FP8=1979, BF16=989, TF32=494.5),
        mixed_peak_equivalent_wall_pct=100 * ideal_bf16 / (trainer_gpus * wall_s),
        mixed_peak_equivalent_compute_pct=100 * ideal_bf16 / (trainer_gpus * compute_s) if compute_s > 0 else None,
        all_nonFP8_at_TF32_sensitivity_wall_pct=100 * ideal_tf32 / (trainer_gpus * wall_s),
        all_nonFP8_at_TF32_sensitivity_compute_pct=100 * ideal_tf32 / (trainer_gpus * compute_s) if compute_s > 0 else None,
        reference_flops_included=False, rollout_flops_included=False,
        whole_model_MFU_measured=False,
        limitations=[
            'FP8 projections/head numerator derives from actual captured shapes but is rescaled by a single logical token proxy.',
            'FA attention changes quadratically with per-sequence context; scaling by token count approximates workload shape.',
            'Mean forward_token_frac times total forwarded tokens is a proxy; per-group exact shared tokens are not logged.',
            'GDN contracts use BF16 peak in the central estimate; TF32 sensitivity reassigns every non-FP8 contraction conservatively.',
            'Norm, activation, quantization, FP32 recurrent scalar work and optimizer useful FLOPs are excluded.',
            'Right padding and activation/GDN/head recomputation are excluded from useful work.',
            'H200 SXM dense peaks are nominal; live clocks and whole RL utilization are not measured.',
        ])


def summarize(rows, audits, shape, trainer_gpus, low, high):
    selected = window_rows(rows, low, high)
    expected = list(range(low, high + 1))
    steps = [int(row['step']) for row in selected]
    if not selected:
        return dict(requested_steps=expected, steps=[], complete=False, reason='No completed timed observations')
    per_step = []
    exact_complete = all(step in audits for step in steps)
    for row in selected:
        step = int(row['step'])
        logged = row['batch/trained_tokens_per_step']
        exact = audits[step]['len']['trained']['sum'] if step in audits else None
        if exact is not None and abs(logged - exact) > max(4, abs(exact) * 2e-6):
            raise ValueError('Logged token count disagrees with exact audit at step ' + str(step))
        per_step.append(dict(step=step, trained_tokens=exact if exact is not None else logged,
            logged_trained_tokens=logged, exact_audit_tokens=exact,
            wall_s=row['perf/step_s'], fwd_bwd_s=row.get('perf/fwd_bwd_s'),
            rollout_wait_s=row.get('perf/rollout_wait_s'), weight_sync_s=row.get('perf/weight_sync_s')))
    tokens = sum(row['trained_tokens'] for row in per_step)
    wall_s = sum(row['wall_s'] for row in per_step)
    times = {}
    for key in ['perf/fwd_bwd_s', 'perf/rollout_wait_s', 'perf/weight_sync_s', 'perf/optimizer_s']:
        values = [row[key] for row in selected if finite(row.get(key))]
        times[key] = sum(values) if len(values) == len(selected) else None
    residual = None
    parts = [times[key] for key in ['perf/fwd_bwd_s', 'perf/rollout_wait_s', 'perf/weight_sync_s']]
    if all(value is not None for value in parts):
        residual = wall_s - sum(parts)
    samples = sum(row.get('batch/samples_per_step', 0) for row in selected)
    dropped_samples = sum(row.get('drop_audit/samples_dropped_total', row.get('sample/dropped_stale_total', 0)) for row in selected)
    audit_rows = [audits[step] for step in steps if step in audits]
    dropped_tokens = sum(row['len']['dropped']['sum'] for row in audit_rows) if exact_complete else None
    inspected_tokens = sum(row['len']['generated']['sum'] for row in audit_rows) if exact_complete else None
    metrics = {key: metric_summary(selected, key) for key in METRICS}
    result = dict(requested_steps=expected, steps=steps, complete=steps == expected,
        completion_tokens=tokens, wall_s=wall_s, total_trained_completion_token_s=tokens / wall_s,
        versus_v1_1972=tokens / wall_s / 1972,
        versus_strongest_bf16_53690_65646=tokens / wall_s / 53690.65646,
        median_step_s=statistics.median(row['wall_s'] for row in per_step),
        token_source='Exact normal drop_audit len.trained.sum' if exact_complete else 'Logged batch/trained_tokens_per_step; exact audit incomplete or absent',
        token_counts_all_exact=exact_complete,
        time_s=times, residual_step_s=residual,
        time_fractions={key: value / wall_s if value is not None else None for key, value in times.items()},
        per_step=per_step, metrics=metrics,
        drop=dict(trained_samples=samples, dropped_samples=dropped_samples,
            sample_drop_fraction=dropped_samples / (samples + dropped_samples) if samples + dropped_samples else None,
            normal_dropped_tokens=dropped_tokens, normal_inspected_tokens=inspected_tokens,
            token_drop_fraction=dropped_tokens / inspected_tokens if inspected_tokens else None,
            final_tail_excluded=True),
        clip_semantics=dict(
            sequence_low='Fraction of all sequences with exp(mean completion logprob difference)<lower bound; ignores advantage sign.',
            sequence_high='Fraction of all sequences with exp(mean completion logprob difference)>1+epsilon_high; ignores advantage sign.',
            token_low='Token ratio<1-epsilon_low AND advantage<0; token count per microbatch, then log step averaging.',
            token_high='Token ratio>1+epsilon_high AND advantage>0; token count per microbatch, then log step averaging.',
            reported_window_average='Sample-weighted mean of already reduced per-step diagnostics; raw sequence/token counts unavailable.',
            reward_std='Sample-weighted mean of reported per-step within-group reward std; not a pooled or across-step std.',
            quantiles='Sample-weighted means of per-step log-rho quantiles; not quantiles of pooled samples.'))
    compute_s = times['perf/fwd_bwd_s'] or 0
    result['policy_MFU_estimate'] = mfu_estimate(selected, shape, trainer_gpus, wall_s, compute_s)
    return result


def collect(run, shape_path=DEFAULT_SHAPE, trainer_gpus=4, primary=(4, 6), secondary=(2, 6)):
    run = Path(run)
    history_path = run / 'log_history.json'
    rows = json.loads(history_path.read_text())
    if not isinstance(rows, list):
        raise ValueError('log_history must contain a JSON array')
    manifest = json.loads((run / 'run.json').read_text()) if (run / 'run.json').exists() else {}
    shape_path = Path(shape_path)
    shape = json.loads(shape_path.read_text())
    audits, tail = exact_audit(run)
    hyperparameters = manifest.get('hyperparams', {})
    lower, upper = hyperparameters.get('eps_low'), hyperparameters.get('eps_high')
    sources = [history_path, shape_path]
    sources.extend(path for path in [run / 'run.json', run / 'drop_audit.jsonl'] if path.exists())
    report = dict(run=str(run.resolve()), metric='sum(actual trained completion tokens)/sum(perf/step_s)',
        source_sha256={str(path.resolve()): hashlib.sha256(path.read_bytes()).hexdigest() for path in sources},
        manifest=dict(series=manifest.get('series'), gpu_layout=manifest.get('gpu_layout'),
            kl_beta=hyperparameters.get('kl_beta'), reference_removed=manifest.get('reference_removed'),
            expected_samples_per_step=manifest.get('expected_samples_per_step'),
            actual_microbatch_per_rank=hyperparameters.get('actual_microbatch_per_rank'),
            gas=hyperparameters.get('gas'), group_size=hyperparameters.get('ngen'),
            eps_low=lower, eps_high=upper,
            static_lower_ratio_bound=1 - lower if finite(lower) else None,
            static_upper_ratio_bound=1 + upper if finite(upper) else None),
        primary=summarize(rows, audits, shape, trainer_gpus, *primary),
        secondary=summarize(rows, audits, shape, trainer_gpus, *secondary),
        final_untrained_tail=tail,
        boundary='Short completed timing windows; changing beta removes a KL term. No train/rollout numerical or learned-policy equivalence claim.')
    path = run / 'wait_admission_decisions.jsonl'
    if path.exists():
        report['adaptive_decisions'] = [json.loads(line) for line in path.read_text().splitlines()]
        report['source_sha256'][str(path.resolve())] = hashlib.sha256(path.read_bytes()).hexdigest()
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('run', type=Path)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--shape-audit', type=Path, default=DEFAULT_SHAPE)
    parser.add_argument('--trainer-gpus', type=int, default=4)
    parser.add_argument('--primary', type=int, nargs=2, default=[4, 6])
    parser.add_argument('--secondary', type=int, nargs=2, default=[2, 6])
    args = parser.parse_args()
    if args.trainer_gpus <= 0:
        raise ValueError('trainer-gpus must be positive')
    result = collect(args.run, args.shape_audit, args.trainer_gpus, args.primary, args.secondary)
    rendered = json.dumps(result, indent=2, allow_nan=False) + '\n'
    if args.output:
        args.output.write_text(rendered)
    else:
        print(rendered, end='')


if __name__ == '__main__':
    main()
