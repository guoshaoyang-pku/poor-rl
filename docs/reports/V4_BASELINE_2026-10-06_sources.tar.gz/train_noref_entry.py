"""Run the frozen exact-count recipe with a verified beta-zero objective."""
import ast
import hashlib
import json
import os
from pathlib import Path
import runpy
import subprocess

ENTRY = str(Path(__file__).resolve())

if __name__ in ('__main__', '__mp_main__'):
    import collator_exact_counts_prototype as counts
    counts.install()
    if __name__ == '__mp_main__':
        import rollout_group_flow_prototype as flow
        print(json.dumps(dict(noref_group_flow=flow.install())), flush=True)
        if os.environ.get('NREF_WAIT_CONTROL') == '1':
            from wait_controller_v4 import install_rollout
            print(json.dumps(dict(noref_wait_rollout=install_rollout())), flush=True)
    elif os.environ.get('SCALE_TRAIN_CHILD') != '1':
        native_popen = subprocess.Popen

        def popen(command, *args, **kwargs):
            if kwargs.get('env', {}).get('SCALE_TRAIN_CHILD') == '1':
                command = [command[0], ENTRY, *command[2:]]
            return native_popen(command, *args, **kwargs)

        subprocess.Popen = popen
    if os.environ.get('SCALE_TRAIN_CHILD') == '1':
        if os.environ.get('NREF_WAIT_CONTROL') == '1':
            from wait_controller_v4 import install_trainer
            print(json.dumps(dict(noref_wait_trainer=install_trainer())), flush=True)
        from trl.experimental.async_grpo import AsyncGRPOTrainer
        original_train = AsyncGRPOTrainer.train

        def train(self, *args, **kwargs):
            assert self._kl_beta == 0 and self._ref_model is None
            rank = int(os.environ.get('RANK', '0'))
            record = dict(beta=self._kl_beta, reference_model_absent=True,
                          rank=rank, pid=os.getpid(),
                          entry_sha256=hashlib.sha256(Path(ENTRY).read_bytes()).hexdigest())
            (Path(os.environ['SCALE_OUT']) / f'noref_rank{rank}.json').write_text(
                json.dumps(record, indent=2))
            print(json.dumps(dict(noref_verified=record)), flush=True)
            from multiprocessing import spawn
            native_prepare = spawn.get_preparation_data

            def prepare(name):
                data = native_prepare(name)
                if name == 'grpo-rollout-worker-child':
                    data.pop('init_main_from_name', None)
                    data['init_main_from_path'] = ENTRY
                return data

            spawn.get_preparation_data = prepare
            finish = None
            if os.environ.get('NREF_CLIP_SWEEP') == '1':
                from v4_clip_sweep import install
                finish = install(self, os.environ['SCALE_OUT'])
            try:
                return original_train(self, *args, **kwargs)
            finally:
                if finish:
                    finish()

        AsyncGRPOTrainer.train = train
    path = Path(os.environ['NREF_FROZEN_ROOT']) / 'train_deferred_cache_json_host_entry.py'
    namespace = dict(__name__=__name__, __file__=str(path),
                     __package__=None, __builtins__=__builtins__)
    exec(compile(ast.parse(path.read_text()), str(path), 'exec'), namespace)
